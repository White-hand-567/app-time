import React, { useState } from 'react';
import {
  Target,
  Trophy,
  Sparkles,
  CheckCircle2,
  Flame,
  Calendar,
  Clock,
  RotateCcw,
  Trash2,
  BookOpen,
  Coffee,
  RefreshCw,
  Check,
  Lock,
  Plus,
} from 'lucide-react';
import {
  GoalItem,
  ScheduleTask,
  AIMemoryItem,
  LockedFixedBlock,
  DailyMinimumHabit,
  AIGoalRoadmapResponse,
  AIGoalDailyStep,
  formatDaysOfWeekBadge,
  getTodayStr,
  addDaysStr,
} from '../types';

interface GoalsStreakViewProps {
  goals: GoalItem[];
  tasks: ScheduleTask[];
  memories: AIMemoryItem[];
  lockedBlocks: LockedFixedBlock[];
  dailyHabits: DailyMinimumHabit[];
  onSaveGoalWithRoadmap: (
    goal: Omit<GoalItem, 'id' | 'userId' | 'createdAt' | 'updatedAt'>,
    dailySteps: AIGoalDailyStep[]
  ) => void;
  onAddDailyHabit: (title: string, startTime: string, endTime: string) => void;
  onDeleteDailyHabit: (habitId: string) => void;
  onIncrementGoalDay: (goalId: string) => void;
  onMarkGoalAchieved: (goalId: string) => void;
  onReopenGoal: (goalId: string) => void;
  onDeleteGoal: (goalId: string) => void;
}

export const GoalsStreakView: React.FC<GoalsStreakViewProps> = ({
  goals,
  tasks,
  memories,
  lockedBlocks,
  dailyHabits,
  onSaveGoalWithRoadmap,
  onAddDailyHabit,
  onDeleteDailyHabit,
  onIncrementGoalDay,
  onMarkGoalAchieved,
  onReopenGoal,
  onDeleteGoal,
}) => {
  const [activeTab, setActiveTab] = useState<'roadmap_ai' | 'active' | 'achieved'>('roadmap_ai');

  const [goalTitleInput, setGoalTitleInput] = useState(
    'Ôn tập Cấu trúc dữ liệu & Lập trình Android'
  );
  const [roadmapText, setRoadmapText] = useState(
    `Bài 1: Mảng 1 chiều và Chuỗi ký tự
Bài 2: Danh sách liên kết đơn & đôi
Bài 3: Ngăn xếp (Stack) và Hàng đợi (Queue)
Bài 4: Đệ quy và Cây nhị phân tìm kiếm
Bài 5: Đồ thị cơ bản (BFS & DFS)
Bài 6: Thiết kế giao diện Android Material 3
Bài 7: Quản lý trạng thái & Kết nối Firebase Cloud`
  );

  // Quick Add Daily Habit in Goals & Streak view
  const [habitTitle, setHabitTitle] = useState('');
  const [habitStart, setHabitStart] = useState('16:30');
  const [habitEnd, setHabitEnd] = useState('17:30');

  const [startDate, setStartDate] = useState(getTodayStr());
  const [isGeneratingRoadmap, setIsGeneratingRoadmap] = useState(false);
  const [roadmapError, setRoadmapError] = useState<string | null>(null);
  const [roadmapPreview, setRoadmapPreview] = useState<AIGoalRoadmapResponse | null>(null);

  const activeGoals = goals.filter((g) => !g.isAchieved);
  const achievedGoals = goals.filter((g) => g.isAchieved);

  const maxCurrentStreak = dailyHabits.reduce((max, h) => Math.max(max, h.currentStreak), 0);
  const maxBestStreak = dailyHabits.reduce((max, h) => Math.max(max, h.bestStreak), 0);

  const handleGenerateGoalRoadmap = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!roadmapText.trim()) return;

    setIsGeneratingRoadmap(true);
    setRoadmapError(null);
    setRoadmapPreview(null);

    try {
      const response = await fetch('/api/gemini/goal-roadmap', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          goalTitleInput: goalTitleInput.trim(),
          roadmapText: roadmapText.trim(),
          lockedBlocks,
          dailyHabits,
          startDate,
          existingTasks: tasks,
          activeMemories: memories.filter((m) => m.isActive),
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Lỗi khi gọi AI phân bổ lộ trình.');
      }

      setRoadmapPreview(data);
    } catch (err: unknown) {
      setRoadmapError(
        err instanceof Error ? err.message : 'Không thể kết nối tới máy chủ Gemini.'
      );
    } finally {
      setIsGeneratingRoadmap(false);
    }
  };

  const handleConfirmRoadmapAndCreateGoal = () => {
    if (!roadmapPreview) return;

    const totalDays = Math.max(
      1,
      roadmapPreview.totalDays || roadmapPreview.dailyPlan.length || 7
    );
    const targetDate = addDaysStr(startDate, totalDays);

    onSaveGoalWithRoadmap(
      {
        title: (roadmapPreview.goalTitle || goalTitleInput).slice(0, 200),
        description: roadmapPreview.goalDescription.slice(0, 1500),
        targetDate,
        dailyActionTitle: `Học theo lộ trình AI phân bổ (${roadmapPreview.dailyTargetMinutes || 90} phút/ngày)`,
        dailyTargetMinutes: roadmapPreview.dailyTargetMinutes || 90,
        totalTargetDays: totalDays,
        completedDays: 0,
        progressPercent: 0,
        isAchieved: false,
        achievedDate: '',
      },
      roadmapPreview.dailyPlan
    );

    setRoadmapPreview(null);
    setActiveTab('active');
  };

  const handleQuickAddHabit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!habitTitle.trim()) return;
    onAddDailyHabit(habitTitle.trim(), habitStart, habitEnd);
    setHabitTitle('');
  };

  return (
    <div className="space-y-5">
      {/* Top KPI Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4">
          <span className="text-xs text-slate-500 dark:text-slate-400">Mục tiêu đang chạy</span>
          <p className="text-2xl font-bold font-mono tabular-nums text-slate-900 dark:text-white mt-1">
            {activeGoals.length}
          </p>
        </div>
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4">
          <span className="text-xs text-slate-500 dark:text-slate-400">Mục tiêu đã đạt</span>
          <p className="text-2xl font-bold font-mono tabular-nums text-emerald-600 dark:text-emerald-400 mt-1">
            {achievedGoals.length}
          </p>
        </div>
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4">
          <span className="text-xs text-slate-500 dark:text-slate-400">Chuỗi Việc Hàng Ngày</span>
          <p className="text-2xl font-bold font-mono tabular-nums text-amber-500 mt-1 flex items-center gap-1.5">
            <Flame className="w-5 h-5" />
            {maxCurrentStreak} ngày
          </p>
        </div>
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4">
          <span className="text-xs text-slate-500 dark:text-slate-400">Kỷ lục Streak dài nhất</span>
          <p className="text-2xl font-bold font-mono tabular-nums text-indigo-600 dark:text-indigo-400 mt-1">
            {maxBestStreak} ngày
          </p>
        </div>
      </div>

      {/* Quick Daily Habits Manager (Add or Delete Only) */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
            <Flame className="w-4 h-4 text-amber-500" />
            Việc Hàng Ngày / Việc Tối Thiểu (Chỉ Thêm hoặc Xóa — Tự động lặp lại mỗi ngày)
          </h3>
        </div>

        <form onSubmit={handleQuickAddHabit} className="grid grid-cols-1 sm:grid-cols-12 gap-2">
          <input
            type="text"
            required
            value={habitTitle}
            onChange={(e) => setHabitTitle(e.target.value)}
            placeholder="Nhập tên việc hàng ngày (VD: Học 30 từ vựng / Chạy bộ)..."
            className="sm:col-span-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-xs text-slate-900 dark:text-slate-100"
          />
          <input
            type="time"
            required
            value={habitStart}
            onChange={(e) => setHabitStart(e.target.value)}
            className="sm:col-span-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 px-2.5 py-2 text-xs font-mono tabular-nums text-slate-900 dark:text-slate-100"
          />
          <input
            type="time"
            required
            value={habitEnd}
            onChange={(e) => setHabitEnd(e.target.value)}
            className="sm:col-span-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 px-2.5 py-2 text-xs font-mono tabular-nums text-slate-900 dark:text-slate-100"
          />
          <button
            type="submit"
            className="sm:col-span-2 min-h-[38px] px-3 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold flex items-center justify-center gap-1"
          >
            <Plus className="w-4 h-4" />
            Thêm
          </button>
        </form>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {dailyHabits.map((h) => (
            <div
              key={h.id}
              className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2 text-xs"
            >
              <div className="min-w-0">
                <p className="font-semibold text-slate-900 dark:text-slate-100 truncate">
                  {h.title}
                </p>
                <p className="text-[11px] font-mono tabular-nums text-amber-600 dark:text-amber-400">
                  {h.startTime} – {h.endTime} · Streak {h.currentStreak} ngày
                </p>
              </div>
              <button
                type="button"
                onClick={() => onDeleteDailyHabit(h.id)}
                className="min-h-[34px] px-2.5 py-1 rounded-lg text-xs font-semibold text-rose-600 hover:bg-rose-500/10 flex items-center gap-1 shrink-0"
              >
                <Trash2 className="w-3.5 h-3.5" />
                Xóa
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Navigation Switch */}
      <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-200/70 dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
        <button
          type="button"
          onClick={() => setActiveTab('roadmap_ai')}
          className={`min-h-[40px] flex-1 sm:flex-initial px-4 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 flex items-center justify-center gap-1.5 ${
            activeTab === 'roadmap_ai'
              ? 'bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 shadow-xs'
              : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5" />
          Đưa Mục Tiêu & Lộ Trình (AI Tự Phân Bố)
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('active')}
          className={`min-h-[40px] flex-1 sm:flex-initial px-4 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 flex items-center justify-center gap-1.5 ${
            activeTab === 'active'
              ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          <Target className="w-3.5 h-3.5" />
          Tiến độ Mục tiêu ({activeGoals.length})
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('achieved')}
          className={`min-h-[40px] flex-1 sm:flex-initial px-4 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 flex items-center justify-center gap-1.5 ${
            activeTab === 'achieved'
              ? 'bg-white dark:bg-slate-800 text-emerald-600 dark:text-emerald-400 shadow-xs'
              : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          <Trophy className="w-3.5 h-3.5" />
          Đã đạt được ({achievedGoals.length})
        </button>
      </div>

      {/* TAB 1: PASTE GOAL + ROADMAP -> AI AUTO DISTRIBUTES AROUND LOCKED BLOCKS */}
      {activeTab === 'roadmap_ai' && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 space-y-5">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-indigo-500" />
              Đưa Mục Tiêu & Lộ Trình — AI Tự Phân Bố Thời Gian Tới Khi Hoàn Thành
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Bạn chỉ cần đưa mục tiêu và lộ trình của mình. Hệ thống tự động né toàn bộ {lockedBlocks.length} Việc chết cố định (thời khóa biểu học ở trường, đi học thêm) và {dailyHabits.length} Việc hàng ngày để sắp xếp đủ kiểu cho tới khi hoàn thành.
            </p>
          </div>

          {/* Summary of Locked Fixed Blocks */}
          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-2">
            <span className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5 text-indigo-500" />
              Các Việc Chết đang khóa cố định qua mọi tuần & tháng (AI tự động né 100%):
            </span>
            <div className="flex flex-wrap gap-1.5">
              {lockedBlocks.map((b) => (
                <span
                  key={b.id}
                  className="px-2.5 py-1 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-[11px] font-mono text-slate-700 dark:text-slate-300"
                >
                  🔒 {b.title} ({b.startTime}–{b.endTime} · {formatDaysOfWeekBadge(b.daysOfWeek)})
                </span>
              ))}
            </div>
          </div>

          <form onSubmit={handleGenerateGoalRoadmap} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                1. Mục tiêu của bạn:
              </label>
              <input
                type="text"
                required
                value={goalTitleInput}
                onChange={(e) => setGoalTitleInput(e.target.value)}
                placeholder="Nhập mục tiêu cần đạt..."
                className="w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 px-3.5 py-2.5 text-sm text-slate-900 dark:text-slate-100"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                2. Lộ trình bài học / các bước thực hiện của bạn:
              </label>
              <textarea
                rows={6}
                required
                value={roadmapText}
                onChange={(e) => setRoadmapText(e.target.value)}
                placeholder="Dán danh sách bài học hoặc các bước trong lộ trình..."
                className="w-full rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-3.5 text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Ngày bắt đầu:
                </label>
                <input
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-xs font-mono tabular-nums text-slate-900 dark:text-slate-100"
                />
              </div>

              <button
                type="submit"
                disabled={isGeneratingRoadmap}
                className="min-h-[44px] px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white text-xs font-semibold flex items-center justify-center gap-2 shadow-sm transition-colors"
              >
                {isGeneratingRoadmap ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    AI đang tự phân bố thời gian...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    AI Tự Phân Bố Thời Gian Để Hoàn Thành
                  </>
                )}
              </button>
            </div>
          </form>

          {roadmapError && (
            <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-xs text-rose-600 dark:text-rose-400">
              {roadmapError}
            </div>
          )}

          {roadmapPreview && (
            <div className="space-y-4 pt-4 border-t border-slate-100 dark:border-slate-800">
              <div className="p-4 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 space-y-1.5">
                <div className="flex items-center justify-between gap-2">
                  <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                    {roadmapPreview.goalTitle}
                  </h4>
                  <span className="text-xs font-mono tabular-nums font-bold text-indigo-600 dark:text-indigo-400">
                    {roadmapPreview.dailyPlan.length} ca · ~{roadmapPreview.dailyTargetMinutes} phút/ngày
                  </span>
                </div>
                <p className="text-xs text-slate-700 dark:text-slate-300">
                  {roadmapPreview.strategyNote}
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {roadmapPreview.dailyPlan.map((step, idx) => (
                  <div
                    key={idx}
                    className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-2"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs font-mono tabular-nums font-bold text-indigo-600 dark:text-indigo-400">
                        Ngày {step.dayNumber} ({step.date})
                      </span>
                      <span className="text-xs font-mono tabular-nums font-semibold text-emerald-600 dark:text-emerald-400">
                        {step.startTime} – {step.endTime}
                      </span>
                    </div>

                    <p className="text-sm font-bold text-slate-900 dark:text-slate-100">
                      {step.title}
                    </p>
                    <p className="text-xs text-slate-600 dark:text-slate-300">{step.notes}</p>

                    <div className="pt-2 border-t border-slate-200/60 dark:border-slate-800/80 flex items-center gap-1.5 text-[11px] text-teal-600 dark:text-teal-400 font-medium">
                      <Coffee className="w-3.5 h-3.5 shrink-0" />
                      <span>Khung nghỉ cuối ngày: {step.freeTimeSummary}</span>
                    </div>
                  </div>
                ))}
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setRoadmapPreview(null)}
                  className="min-h-[44px] px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400"
                >
                  Hủy bản nháp
                </button>
                <button
                  type="button"
                  onClick={handleConfirmRoadmapAndCreateGoal}
                  className="min-h-[44px] px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-2 shadow-sm"
                >
                  <Check className="w-4 h-4" />
                  Xác nhận Lưu Mục Tiêu & Xếp Vào Lịch
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 2: ACTIVE GOALS PROGRESS TRACKING */}
      {activeTab === 'active' && (
        <div className="space-y-3.5">
          {activeGoals.map((goal) => {
            const linkedTasks = tasks.filter((t) => t.goalId === goal.id);
            return (
              <div
                key={goal.id}
                className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 space-y-4"
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h4 className="text-base font-bold text-slate-900 dark:text-slate-100">
                      {goal.title}
                    </h4>
                    <p className="text-xs text-slate-600 dark:text-slate-300 mt-1">
                      {goal.description}
                    </p>
                    <div className="flex flex-wrap items-center gap-2 mt-2 text-xs text-slate-500 dark:text-slate-400">
                      <span className="inline-flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5 text-indigo-500" />
                        Đích đến: <strong className="font-mono tabular-nums">{goal.targetDate}</strong>
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className="inline-flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5 text-emerald-500" />
                        Thời lượng: <strong className="font-mono tabular-nums">{goal.dailyTargetMinutes} phút/ngày</strong>
                      </span>
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <span className="text-xl font-bold font-mono tabular-nums text-indigo-600 dark:text-indigo-400">
                      {goal.progressPercent}%
                    </span>
                    <span className="block text-[11px] font-mono tabular-nums text-slate-500">
                      {goal.completedDays}/{goal.totalTargetDays} ngày
                    </span>
                  </div>
                </div>

                <div className="w-full h-2.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-indigo-600 dark:bg-indigo-500 rounded-full transition-all duration-300"
                    style={{ width: `${Math.min(100, goal.progressPercent)}%` }}
                  />
                </div>

                {linkedTasks.length > 0 && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {linkedTasks.map((lt) => (
                      <div
                        key={lt.id}
                        className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200/70 dark:border-slate-800 text-xs flex items-center justify-between gap-2"
                      >
                        <span
                          className={`truncate ${
                            lt.completed
                              ? 'line-through text-slate-400'
                              : 'text-slate-800 dark:text-slate-200 font-medium'
                          }`}
                        >
                          {lt.title}
                        </span>
                        <span className="font-mono tabular-nums text-[11px] text-indigo-600 dark:text-indigo-400 shrink-0">
                          {lt.date.slice(5)} ({lt.startTime})
                        </span>
                      </div>
                    ))}
                  </div>
                )}

                <div className="flex items-center justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => onIncrementGoalDay(goal.id)}
                    className="min-h-[40px] px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center gap-1.5"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    Điểm danh (+1 ngày)
                  </button>
                  <button
                    type="button"
                    onClick={() => onMarkGoalAchieved(goal.id)}
                    className="min-h-[40px] px-3 py-2 rounded-xl bg-emerald-600/10 text-emerald-600 dark:text-emerald-400 text-xs font-semibold flex items-center gap-1.5"
                  >
                    <Trophy className="w-4 h-4" />
                    Hoàn thành
                  </button>
                  <button
                    type="button"
                    onClick={() => onDeleteGoal(goal.id)}
                    className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl text-rose-500 hover:bg-rose-500/10"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* TAB 3: ACHIEVED GOALS ARCHIVE */}
      {activeTab === 'achieved' && (
        <div className="space-y-3.5">
          {achievedGoals.map((goal) => (
            <div
              key={goal.id}
              className="bg-white dark:bg-slate-900 rounded-2xl border border-emerald-500/30 p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2 text-xs text-emerald-600 dark:text-emerald-400 font-semibold">
                  <Trophy className="w-4 h-4" />
                  <span>Đã hoàn thành ngày {goal.achievedDate || goal.targetDate}</span>
                </div>
                <h4 className="text-base font-bold text-slate-900 dark:text-slate-100">
                  {goal.title}
                </h4>
                <p className="text-xs text-slate-600 dark:text-slate-400">{goal.description}</p>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => onReopenGoal(goal.id)}
                  className="min-h-[40px] px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-medium text-slate-600 dark:text-slate-300 flex items-center gap-1.5"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  Mở lại
                </button>
                <button
                  type="button"
                  onClick={() => onDeleteGoal(goal.id)}
                  className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl text-rose-500 hover:bg-rose-500/10"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
