import React, { useState, useEffect } from 'react';
import {
  Brain,
  Sparkles,
  AlertTriangle,
  Plus,
  Trash2,
  Edit3,
  Check,
  X,
  ArrowRight,
  Clock,
  BookmarkCheck,
  RefreshCw,
} from 'lucide-react';
import {
  AIMemoryItem,
  AIMemoryCategory,
  MEMORY_CATEGORY_LABELS,
  ScheduleTask,
  GoalItem,
  AIPlanResponse,
  AIRescheduleResponse,
  ProposedTaskDraft,
  addDaysStr,
} from '../types';

interface AISchedulerViewProps {
  tasks: ScheduleTask[];
  goals: GoalItem[];
  memories: AIMemoryItem[];
  selectedDate: string;
  preselectedIncidentTask: ScheduleTask | null;
  onClearPreselectedIncident: () => void;
  onSaveMemory: (content: string, category: AIMemoryCategory, existingId?: string) => void;
  onToggleMemory: (memoryId: string) => void;
  onDeleteMemory: (memoryId: string) => void;
  onApplyProposedTasks: (drafts: ProposedTaskDraft[]) => void;
  onApplyRescheduleAdjustments: (adjustments: AIRescheduleResponse['adjustments']) => void;
}

export const AISchedulerView: React.FC<AISchedulerViewProps> = ({
  tasks,
  goals,
  memories,
  selectedDate,
  preselectedIncidentTask,
  onClearPreselectedIncident,
  onSaveMemory,
  onToggleMemory,
  onDeleteMemory,
  onApplyProposedTasks,
  onApplyRescheduleAdjustments,
}) => {
  const [activeMode, setActiveMode] = useState<'planner' | 'incident' | 'memory'>('planner');

  // Memory Vault Form States
  const [newMemoryText, setNewMemoryText] = useState('');
  const [newMemoryCategory, setNewMemoryCategory] = useState<AIMemoryCategory>('commute');
  const [editingMemoryId, setEditingMemoryId] = useState<string | null>(null);
  const [editingMemoryText, setEditingMemoryText] = useState('');
  const [editingMemoryCategory, setEditingMemoryCategory] = useState<AIMemoryCategory>('commute');

  // Smart Planner States
  const [planPrompt, setPlanPrompt] = useState(
    'Sắp xếp lịch học trên trường từ 07:30 đến 11:00, buổi chiều ôn IELTS và làm dự án Android, buổi tối chạy bộ.'
  );
  const [isPlanning, setIsPlanning] = useState(false);
  const [planError, setPlanError] = useState<string | null>(null);
  const [planResult, setPlanResult] = useState<AIPlanResponse | null>(null);
  const [selectedDraftIndexes, setSelectedDraftIndexes] = useState<number[]>([]);

  // Incident Rescheduler States
  const [incidentReason, setIncidentReason] = useState('');
  const [affectedTaskIds, setAffectedTaskIds] = useState<string[]>([]);
  const [isRescheduling, setIsRescheduling] = useState(false);
  const [rescheduleError, setRescheduleError] = useState<string | null>(null);
  const [rescheduleResult, setRescheduleResult] = useState<AIRescheduleResponse | null>(null);

  useEffect(() => {
    if (preselectedIncidentTask) {
      setActiveMode('incident');
      setAffectedTaskIds([preselectedIncidentTask.id]);
      setIncidentReason(
        `Chưa kịp hoàn thành "${preselectedIncidentTask.title}" (${preselectedIncidentTask.startTime}-${preselectedIncidentTask.endTime}) do có việc đột xuất phát sinh.`
      );
    }
  }, [preselectedIncidentTask]);

  const activeMemories = memories.filter((m) => m.isActive);
  const incompleteTasksToday = tasks.filter(
    (t) => t.date === selectedDate && !t.completed
  );

  const handleAddMemorySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMemoryText.trim()) return;
    onSaveMemory(newMemoryText.trim(), newMemoryCategory);
    setNewMemoryText('');
  };

  const handleStartEditMemory = (mem: AIMemoryItem) => {
    setEditingMemoryId(mem.id);
    setEditingMemoryText(mem.content);
    setEditingMemoryCategory(mem.category);
  };

  const handleSaveEditMemory = (id: string) => {
    if (!editingMemoryText.trim()) return;
    onSaveMemory(editingMemoryText.trim(), editingMemoryCategory, id);
    setEditingMemoryId(null);
  };

  const handleRunSmartPlan = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!planPrompt.trim()) return;
    setIsPlanning(true);
    setPlanError(null);
    setPlanResult(null);

    try {
      const response = await fetch('/api/gemini/plan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userPrompt: planPrompt.trim(),
          targetDate: selectedDate,
          existingTasks: tasks.filter((t) => t.date === selectedDate),
          activeMemories,
          activeGoals: goals.filter((g) => !g.isAchieved),
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Lỗi khi gọi Gemini AI.');
      }

      setPlanResult(data);
      setSelectedDraftIndexes(
        Array.isArray(data.proposedTasks) ? data.proposedTasks.map((_: unknown, idx: number) => idx) : []
      );
    } catch (err: unknown) {
      setPlanError(err instanceof Error ? err.message : 'Không thể kết nối tới máy chủ Gemini.');
    } finally {
      setIsPlanning(false);
    }
  };

  const handleConfirmApplyPlan = () => {
    if (!planResult) return;
    const chosen = planResult.proposedTasks.filter((_, idx) =>
      selectedDraftIndexes.includes(idx)
    );
    if (chosen.length === 0) return;
    onApplyProposedTasks(chosen);
    setPlanResult(null);
  };

  const handleRunReschedule = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!incidentReason.trim()) return;
    setIsRescheduling(true);
    setRescheduleError(null);
    setRescheduleResult(null);

    const nextDate = addDaysStr(selectedDate, 1);
    const relevantTasks = tasks.filter(
      (t) => (t.date === selectedDate || t.date === nextDate) && !t.completed
    );

    try {
      const response = await fetch('/api/gemini/reschedule', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          incidentReason: incidentReason.trim(),
          affectedTaskIds,
          currentDate: selectedDate,
          nextDate,
          tasks: relevantTasks,
          activeMemories,
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Lỗi khi điều chỉnh lịch trình với Gemini.');
      }

      setRescheduleResult(data);
    } catch (err: unknown) {
      setRescheduleError(
        err instanceof Error ? err.message : 'Không thể kết nối tới Gemini Rescheduler.'
      );
    } finally {
      setIsRescheduling(false);
    }
  };

  const handleConfirmReschedule = () => {
    if (!rescheduleResult) return;
    onApplyRescheduleAdjustments(rescheduleResult.adjustments);
    setRescheduleResult(null);
    onClearPreselectedIncident();
  };

  return (
    <div className="space-y-5">
      {/* Top Mode Selector */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-1 p-1 bg-slate-200/70 dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
          <button
            type="button"
            onClick={() => setActiveMode('planner')}
            className={`min-h-[40px] flex-1 sm:flex-initial px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 flex items-center justify-center gap-1.5 ${
              activeMode === 'planner'
                ? 'bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 shadow-xs'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            Lập lịch thông minh
          </button>
          <button
            type="button"
            onClick={() => setActiveMode('incident')}
            className={`min-h-[40px] flex-1 sm:flex-initial px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 flex items-center justify-center gap-1.5 ${
              activeMode === 'incident'
                ? 'bg-white dark:bg-slate-800 text-amber-600 dark:text-amber-400 shadow-xs'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            Báo sự cố & Dời lịch
          </button>
          <button
            type="button"
            onClick={() => setActiveMode('memory')}
            className={`min-h-[40px] flex-1 sm:flex-initial px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 flex items-center justify-center gap-1.5 ${
              activeMode === 'memory'
                ? 'bg-white dark:bg-slate-800 text-emerald-600 dark:text-emerald-400 shadow-xs'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            <Brain className="w-3.5 h-3.5" />
            Bộ nhớ Quy tắc ({activeMemories.length}/{memories.length})
          </button>
        </div>
      </div>

      {/* Persistent AI Context Memory Banner (Always visible summary with quick manage trigger) */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h3 className="text-xs font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
              <Brain className="w-4 h-4 text-emerald-500" />
              Bộ nhớ Ngữ cảnh & Quy tắc Cố định đang tự động nạp cho Gemini ({activeMemories.length} quy tắc bật)
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Bạn không cần gõ lại các thông tin này mỗi lần lập lịch hay báo sự cố.
            </p>
          </div>
          {activeMode !== 'memory' && (
            <button
              type="button"
              onClick={() => setActiveMode('memory')}
              className="min-h-[38px] px-3 py-1.5 rounded-xl text-xs font-semibold text-emerald-600 dark:text-emerald-400 bg-emerald-500/10 hover:bg-emerald-500/20 transition-colors whitespace-nowrap shrink-0"
            >
              Sửa / Thêm quy tắc
            </button>
          )}
        </div>

        {activeMemories.length > 0 && activeMode !== 'memory' && (
          <div className="mt-3 space-y-1.5 pt-2.5 border-t border-slate-100 dark:border-slate-800">
            {activeMemories.map((mem) => (
              <div
                key={mem.id}
                className="flex items-center justify-between gap-2 text-xs text-slate-700 dark:text-slate-300"
              >
                <span className="truncate">
                  <strong className="text-emerald-600 dark:text-emerald-400 font-medium">
                    {MEMORY_CATEGORY_LABELS[mem.category]}:
                  </strong>{' '}
                  {mem.content}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* MODE 3: AI MEMORY VAULT MANAGER */}
      {activeMode === 'memory' && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 space-y-5">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
              Quản lý Bộ nhớ Ngữ cảnh & Quy tắc Cá nhân
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Lưu lại thời gian đi học, khung giờ nghỉ ngơi hoặc ràng buộc cố định. Bạn có thể bật/tắt tạm thời, chỉnh sửa hoặc xóa bất cứ lúc nào khi không còn cần thiết.
            </p>
          </div>

          {/* Add new memory form */}
          <form onSubmit={handleAddMemorySubmit} className="space-y-3 p-4 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
            <label className="block text-xs font-semibold text-slate-800 dark:text-slate-200">
              Thêm thông tin cố định mới để Gemini luôn ghi nhớ:
            </label>
            <div className="flex flex-col sm:flex-row gap-2.5">
              <select
                value={newMemoryCategory}
                onChange={(e) => setNewMemoryCategory(e.target.value as AIMemoryCategory)}
                className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-3 py-2.5 text-xs text-slate-900 dark:text-slate-100 sm:w-44 shrink-0"
              >
                <option value="commute">Di chuyển cố định</option>
                <option value="routine">Giờ sinh hoạt</option>
                <option value="energy">Nhịp năng lượng</option>
                <option value="constraint">Ràng buộc lịch</option>
              </select>
              <input
                type="text"
                required
                maxLength={500}
                value={newMemoryText}
                onChange={(e) => setNewMemoryText(e.target.value)}
                placeholder="Ví dụ: Đi học tốn 20 phút tới trường, Tối thứ 4 học tiếng Anh..."
                className="flex-1 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-3.5 py-2.5 text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:border-indigo-500"
              />
              <button
                type="submit"
                className="min-h-[44px] px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0"
              >
                <Plus className="w-4 h-4" />
                Lưu ghi nhớ
              </button>
            </div>

            {/* Quick sample templates */}
            <div className="flex flex-wrap items-center gap-1.5 pt-1">
              <span className="text-[11px] text-slate-400">Mẫu nhanh:</span>
              {[
                { text: 'Đi học tốn 20 phút di chuyển tới trường', cat: 'commute' as AIMemoryCategory },
                { text: 'Ăn tối và nghỉ ngơi từ 18:30 đến 19:30', cat: 'routine' as AIMemoryCategory },
                { text: 'Không xếp việc học nặng sau 22:15', cat: 'constraint' as AIMemoryCategory },
              ].map((sample, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => {
                    setNewMemoryText(sample.text);
                    setNewMemoryCategory(sample.cat);
                  }}
                  className="text-[11px] px-2.5 py-1 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:border-emerald-500/50 transition-colors"
                >
                  + {sample.text}
                </button>
              ))}
            </div>
          </form>

          {/* List of saved memories */}
          <div className="space-y-2.5">
            {memories.length === 0 ? (
              <p className="text-xs text-slate-400 py-6 text-center">
                Chưa có quy tắc nào được lưu trong Bộ nhớ AI.
              </p>
            ) : (
              memories.map((mem) => (
                <div
                  key={mem.id}
                  className={`p-3.5 rounded-2xl border transition-colors ${
                    mem.isActive
                      ? 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800'
                      : 'bg-slate-50/70 dark:bg-slate-950/40 border-slate-200/50 dark:border-slate-800/50 opacity-60'
                  }`}
                >
                  {editingMemoryId === mem.id ? (
                    <div className="space-y-2.5">
                      <div className="flex flex-col sm:flex-row gap-2">
                        <select
                          value={editingMemoryCategory}
                          onChange={(e) => setEditingMemoryCategory(e.target.value as AIMemoryCategory)}
                          className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-xs text-slate-900 dark:text-slate-100"
                        >
                          <option value="commute">Di chuyển cố định</option>
                          <option value="routine">Giờ sinh hoạt</option>
                          <option value="energy">Nhịp năng lượng</option>
                          <option value="constraint">Ràng buộc lịch</option>
                        </select>
                        <input
                          type="text"
                          value={editingMemoryText}
                          onChange={(e) => setEditingMemoryText(e.target.value)}
                          className="flex-1 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-xs text-slate-900 dark:text-slate-100"
                        />
                      </div>
                      <div className="flex items-center justify-end gap-2">
                        <button
                          type="button"
                          onClick={() => setEditingMemoryId(null)}
                          className="min-h-[36px] px-3 py-1 rounded-lg text-xs text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
                        >
                          Hủy
                        </button>
                        <button
                          type="button"
                          onClick={() => handleSaveEditMemory(mem.id)}
                          className="min-h-[36px] px-3.5 py-1 rounded-lg bg-emerald-600 text-white text-xs font-semibold flex items-center gap-1"
                        >
                          <Check className="w-3.5 h-3.5" />
                          Cập nhật
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-start justify-between gap-3">
                      <label className="flex items-start gap-3 cursor-pointer flex-1 min-w-0">
                        <input
                          type="checkbox"
                          checked={mem.isActive}
                          onChange={() => onToggleMemory(mem.id)}
                          className="mt-1 w-4 h-4 accent-emerald-600 rounded shrink-0"
                        />
                        <div className="min-w-0">
                          <span className="text-[11px] font-semibold text-emerald-600 dark:text-emerald-400">
                            {MEMORY_CATEGORY_LABELS[mem.category]}
                            {!mem.isActive && ' (Đang tạm tắt)'}
                          </span>
                          <p className="text-sm font-medium text-slate-900 dark:text-slate-100 mt-0.5">
                            {mem.content}
                          </p>
                        </div>
                      </label>

                      <div className="flex items-center gap-1 shrink-0">
                        <button
                          type="button"
                          onClick={() => handleStartEditMemory(mem)}
                          aria-label="Sửa quy tắc"
                          className="min-h-[38px] min-w-[38px] flex items-center justify-center rounded-xl text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => onDeleteMemory(mem.id)}
                          aria-label="Xóa quy tắc"
                          className="min-h-[38px] min-w-[38px] flex items-center justify-center rounded-xl text-rose-500 hover:bg-rose-500/10"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* MODE 1: SMART PLANNER */}
      {activeMode === 'planner' && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 space-y-4">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-indigo-500" />
              Lập kế hoạch tự động cùng Gemini AI (Ngày {selectedDate})
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Chỉ cần gõ ngắn gọn những việc cần làm. Gemini sẽ tự động đối chiếu với {activeMemories.length} quy tắc trong Bộ nhớ của bạn (như thời gian đi học 20 phút, giờ nghỉ trưa) để chia khung giờ chuẩn xác.
            </p>
          </div>

          <form onSubmit={handleRunSmartPlan} className="space-y-3">
            <textarea
              rows={3}
              value={planPrompt}
              onChange={(e) => setPlanPrompt(e.target.value)}
              placeholder="Ví dụ: Sáng nay đi học từ 07:30 đến 11:00, chiều làm bài tập nhóm 2 tiếng và chạy bộ..."
              className="w-full rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-3.5 text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:border-indigo-500"
            />
            <div className="flex items-center justify-between gap-3">
              <span className="text-xs text-slate-500 dark:text-slate-400">
                Mô hình: <strong className="font-mono">gemini-3.8-flash</strong>
              </span>
              <button
                type="submit"
                disabled={isPlanning}
                className="min-h-[44px] px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white text-xs font-semibold flex items-center gap-2 shadow-sm transition-colors"
              >
                {isPlanning ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    Gemini đang tính toán lịch...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    Tạo đề xuất lịch trình
                  </>
                )}
              </button>
            </div>
          </form>

          {planError && (
            <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-xs text-rose-600 dark:text-rose-400">
              {planError}
            </div>
          )}

          {planResult && (
            <div className="space-y-4 pt-4 border-t border-slate-100 dark:border-slate-800">
              <div className="p-3.5 rounded-xl bg-indigo-500/10 border border-indigo-500/20 space-y-2">
                <p className="text-xs font-medium text-slate-800 dark:text-slate-200">
                  {planResult.summary}
                </p>
                {planResult.appliedMemoryNotes?.length > 0 && (
                  <div className="text-[11px] text-indigo-600 dark:text-indigo-300">
                    <strong>Đã áp dụng từ Bộ nhớ của bạn:</strong>{' '}
                    {planResult.appliedMemoryNotes.join(' · ')}
                  </div>
                )}
              </div>

              {/* Extracted New Memories Suggestion */}
              {planResult.extractedNewMemories?.length > 0 && (
                <div className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 space-y-2">
                  <p className="text-xs font-bold text-emerald-700 dark:text-emerald-300 flex items-center gap-1.5">
                    <BookmarkCheck className="w-4 h-4" />
                    Gemini phát hiện thông tin lịch trình mới có thể lưu vào Bộ nhớ để lần sau không cần nhập lại:
                  </p>
                  <div className="space-y-1.5">
                    {planResult.extractedNewMemories.map((item, i) => (
                      <div key={i} className="flex items-center justify-between gap-2 text-xs">
                        <span className="text-slate-800 dark:text-slate-200">{item.content}</span>
                        <button
                          type="button"
                          onClick={() => onSaveMemory(item.content, item.category || 'routine')}
                          className="min-h-[34px] px-3 py-1 rounded-lg bg-emerald-600 text-white text-xs font-semibold shrink-0"
                        >
                          + Lưu vào Bộ nhớ
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Proposed Tasks Checklist */}
              <div className="space-y-2">
                <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100">
                  Danh sách khung giờ đề xuất (Chọn các mục bạn muốn thêm vào lịch):
                </h4>
                {planResult.proposedTasks.map((draft, idx) => {
                  const checked = selectedDraftIndexes.includes(idx);
                  return (
                    <label
                      key={idx}
                      className={`p-3.5 rounded-xl border flex items-start gap-3 cursor-pointer transition-colors ${
                        checked
                          ? 'bg-slate-50 dark:bg-slate-950 border-indigo-500/50'
                          : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 opacity-60'
                      }`}
                    >
                      <input
                        type="checkbox"
                        checked={checked}
                        onChange={() =>
                          setSelectedDraftIndexes((prev) =>
                            prev.includes(idx) ? prev.filter((i) => i !== idx) : [...prev, idx]
                          )
                        }
                        className="mt-1 w-4 h-4 accent-indigo-600 rounded shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-2">
                          <span className="font-mono tabular-nums text-xs font-bold text-indigo-600 dark:text-indigo-400">
                            {draft.date} · {draft.startTime} – {draft.endTime}
                          </span>
                          {draft.isMinimumDaily && (
                            <span className="text-[11px] text-amber-600 dark:text-amber-400 font-medium">
                              Việc tối thiểu hằng ngày
                            </span>
                          )}
                        </div>
                        <p className="text-sm font-semibold text-slate-900 dark:text-slate-100 mt-0.5">
                          {draft.title}
                        </p>
                        {draft.notes && (
                          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                            {draft.notes}
                          </p>
                        )}
                      </div>
                    </label>
                  );
                })}
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setPlanResult(null)}
                  className="min-h-[44px] px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400"
                >
                  Hủy đề xuất
                </button>
                <button
                  type="button"
                  onClick={handleConfirmApplyPlan}
                  className="min-h-[44px] px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow-sm"
                >
                  <Check className="w-4 h-4" />
                  Xác nhận thêm {selectedDraftIndexes.length} việc vào lịch
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* MODE 2: INCIDENT RESCHEDULER */}
      {activeMode === 'incident' && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 space-y-4">
          <div className="flex items-start justify-between gap-2">
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-500" />
                Báo cáo Sự cố & Điều chỉnh Lịch trình Tiếp theo
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Khi không kịp hoàn thành kế hoạch, hãy báo cho Gemini. Hệ thống sẽ đề xuất dời giờ, rút gọn hoặc bù vào ngày mai mà vẫn giữ chuỗi Streak và tôn trọng Bộ nhớ Ngữ cảnh của bạn.
              </p>
            </div>
          </div>

          {/* Select affected tasks */}
          {incompleteTasksToday.length > 0 && (
            <div className="space-y-2">
              <span className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                Chọn các công việc chưa hoàn thành bị ảnh hưởng trong ngày ({selectedDate}):
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {incompleteTasksToday.map((t) => {
                  const isSel = affectedTaskIds.includes(t.id);
                  return (
                    <button
                      key={t.id}
                      type="button"
                      onClick={() =>
                        setAffectedTaskIds((prev) =>
                          prev.includes(t.id) ? prev.filter((id) => id !== t.id) : [...prev, t.id]
                        )
                      }
                      className={`p-2.5 rounded-xl border text-left transition-colors flex items-center justify-between gap-2 ${
                        isSel
                          ? 'bg-amber-500/10 border-amber-500/50 text-slate-900 dark:text-white'
                          : 'bg-slate-50 dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      <div className="min-w-0">
                        <span className="font-mono tabular-nums text-[11px] text-amber-600 dark:text-amber-400 font-semibold">
                          {t.startTime} - {t.endTime}
                        </span>
                        <p className="text-xs font-semibold truncate">{t.title}</p>
                      </div>
                      <input
                        type="checkbox"
                        checked={isSel}
                        readOnly
                        className="w-4 h-4 accent-amber-500 rounded shrink-0"
                      />
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Quick incident reason templates */}
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="text-[11px] text-slate-400">Tình huống nhanh:</span>
            {[
              'Phát sinh việc đột xuất trên trường trễ 1 tiếng',
              'Cơ thể mệt mỏi cần nghỉ ngơi sớm tối nay, dời việc nặng sang mai',
              'Kẹt xe về muộn 30 phút, chỉ đủ thời gian làm việc tối thiểu giữ Streak',
            ].map((tpl, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setIncidentReason(tpl)}
                className="text-[11px] px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-amber-500/15 transition-colors"
              >
                {tpl}
              </button>
            ))}
          </div>

          <form onSubmit={handleRunReschedule} className="space-y-3">
            <textarea
              rows={3}
              required
              value={incidentReason}
              onChange={(e) => setIncidentReason(e.target.value)}
              placeholder="Mô tả ngắn gọn sự cố (ví dụ: Họp nhóm kéo dài tới 16:30 nên bị lỡ khung giờ luyện code)..."
              className="w-full rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-3.5 text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:border-amber-500"
            />
            <div className="flex items-center justify-end">
              <button
                type="submit"
                disabled={isRescheduling}
                className="min-h-[44px] px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-slate-950 text-xs font-bold flex items-center gap-2 shadow-sm transition-colors"
              >
                {isRescheduling ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    Gemini đang tái cấu trúc lịch trình...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    Đề xuất lịch trình điều chỉnh
                  </>
                )}
              </button>
            </div>
          </form>

          {rescheduleError && (
            <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-xs text-rose-600 dark:text-rose-400">
              {rescheduleError}
            </div>
          )}

          {/* Before / After Comparison & Confirmation */}
          {rescheduleResult && (
            <div className="space-y-4 pt-4 border-t border-slate-100 dark:border-slate-800">
              <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/30 space-y-1.5">
                <p className="text-xs font-medium text-slate-900 dark:text-slate-100">
                  {rescheduleResult.empathyAndAnalysis}
                </p>
                {rescheduleResult.appliedMemoryNotes?.length > 0 && (
                  <p className="text-[11px] text-amber-700 dark:text-amber-300">
                    <strong>Đã đối chiếu Bộ nhớ:</strong> {rescheduleResult.appliedMemoryNotes.join(' · ')}
                  </p>
                )}
              </div>

              {rescheduleResult.extractedNewMemories?.length > 0 && (
                <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 space-y-1.5">
                  <p className="text-xs font-semibold text-emerald-700 dark:text-emerald-300">
                    Gợi ý lưu thêm vào Bộ nhớ Ngữ cảnh cho lần sau:
                  </p>
                  {rescheduleResult.extractedNewMemories.map((m, i) => (
                    <div key={i} className="flex items-center justify-between gap-2 text-xs">
                      <span>{m.content}</span>
                      <button
                        type="button"
                        onClick={() => onSaveMemory(m.content, m.category || 'constraint')}
                        className="px-2.5 py-1 rounded-lg bg-emerald-600 text-white text-xs font-semibold"
                      >
                        + Lưu
                      </button>
                    </div>
                  ))}
                </div>
              )}

              <div className="space-y-2.5">
                <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100">
                  Bảng đối chiếu Lịch trình Trước & Sau điều chỉnh:
                </h4>
                {rescheduleResult.adjustments.map((adj, idx) => (
                  <div
                    key={idx}
                    className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-2"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-sm font-bold text-slate-900 dark:text-slate-100">
                        {adj.title}
                      </span>
                      <span className="text-xs font-medium text-amber-600 dark:text-amber-400">
                        {adj.actionType === 'move'
                          ? 'Dời khung giờ'
                          : adj.actionType === 'shorten'
                          ? 'Rút gọn giữ Streak'
                          : 'Bù sang ngày tiếp theo'}
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center gap-2 text-xs font-mono tabular-nums">
                      <span className="line-through text-slate-400 flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5" />
                        {adj.oldDate} ({adj.oldStartTime}-{adj.oldEndTime})
                      </span>
                      <ArrowRight className="w-3.5 h-3.5 text-amber-500" />
                      <span className="font-bold text-emerald-600 dark:text-emerald-400">
                        {adj.newDate} ({adj.newStartTime}-{adj.newEndTime})
                      </span>
                    </div>

                    <p className="text-xs text-slate-600 dark:text-slate-300">
                      <strong>Lý do:</strong> {adj.reason}
                    </p>
                  </div>
                ))}
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setRescheduleResult(null)}
                  className="min-h-[44px] px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 flex items-center gap-1"
                >
                  <X className="w-4 h-4" />
                  Giữ nguyên lịch cũ
                </button>
                <button
                  type="button"
                  onClick={handleConfirmReschedule}
                  className="min-h-[44px] px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow-sm"
                >
                  <Check className="w-4 h-4" />
                  Xác nhận áp dụng lịch mới
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
