import React, { useState, useMemo } from 'react';
import {
  CheckCircle2,
  Circle,
  ChevronLeft,
  ChevronRight,
  Trash2,
  Plus,
  Sparkles,
  Lock,
  LayoutList,
  BarChartHorizontal,
  PieChart as PieChartIcon,
  Columns,
  Flame,
  Calendar,
  Brain,
  RefreshCw,
  Globe,
  ExternalLink,
  X,
  Zap,
  AlertCircle,
} from 'lucide-react';
import {
  ScheduleTask,
  ScheduleViewMode,
  ScheduleDisplayFormat,
  TaskCategory,
  CATEGORY_LABELS,
  GoalItem,
  AIMemoryItem,
  AIMemoryCategory,
  LockedFixedBlock,
  DailyMinimumHabit,
  AIGoalDailyStep,
  AIFeedbackAdjustResponse,
  SchoolPortalSyncConfig,
  AISchoolWebSyncResponse,
  WEEKDAY_LABELS,
  formatDaysOfWeekBadge,
  getWeekdayFromDateStr,
  getTodayStr,
  addDaysStr,
} from '../types';
import {
  parseClassTimetableFromBenCatExcel,
} from '../data/thptBenCatExcelParser';

interface ScheduleViewProps {
  tasks: ScheduleTask[];
  goals: GoalItem[];
  memories: AIMemoryItem[];
  lockedBlocks: LockedFixedBlock[];
  dailyHabits: DailyMinimumHabit[];
  schoolSyncConfig: SchoolPortalSyncConfig;
  selectedDate: string;
  onSelectDate: (date: string) => void;
  viewMode: ScheduleViewMode;
  onChangeViewMode: (mode: ScheduleViewMode) => void;
  onToggleTask: (taskId: string) => void;
  onDeleteTask: (taskId: string) => void;
  onReportIncident: (task: ScheduleTask) => void;
  onAddDailyHabit: (title: string, startTime: string, endTime: string) => void;
  onDeleteDailyHabit: (habitId: string) => void;
  onToggleDailyHabitForDate: (habitId: string, dateStr: string) => void;
  onAddLockedBlock: (
    title: string,
    daysOfWeek: number[],
    startTime: string,
    endTime: string
  ) => void;
  onDeleteLockedBlock: (blockId: string) => void;
  onUpdateSchoolSyncConfig: (config: SchoolPortalSyncConfig) => void;
  onApplySchoolWebSync: (
    syncResult: AISchoolWebSyncResponse,
    updatedConfig: SchoolPortalSyncConfig
  ) => void;
  onSaveGoalWithRoadmap: (
    goalData: Omit<GoalItem, 'id' | 'userId' | 'createdAt' | 'updatedAt'>,
    dailySteps: AIGoalDailyStep[]
  ) => void;
  onSaveMemory: (content: string, category: AIMemoryCategory) => void;
  onApplyFeedbackAdjustedTasks: (
    targetDate: string,
    updatedDayTasks: AIFeedbackAdjustResponse['updatedDayTasks']
  ) => void;
  onApplyGanttTemplate: (
    templateType: 'deep_focus' | 'exam_sprint' | 'weekend_full',
    targetDate: string
  ) => void;
  onCompactDaySchedule: (targetDate: string) => void;
}

type CoreActionTab = 'goal_roadmap' | 'daily_habit' | 'locked_fixed' | 'ai_feedback' | null;
type GanttScaleMode = 'intraday' | 'multiday';

function timeToMinutes(t: string): number {
  const [h, m] = t.split(':').map(Number);
  return (h || 0) * 60 + (m || 0);
}

export const ScheduleView: React.FC<ScheduleViewProps> = ({
  tasks,
  goals,
  memories,
  lockedBlocks,
  dailyHabits,
  schoolSyncConfig,
  selectedDate,
  onSelectDate,
  viewMode,
  onChangeViewMode,
  onToggleTask,
  onDeleteTask,
  onReportIncident,
  onAddDailyHabit,
  onDeleteDailyHabit,
  onToggleDailyHabitForDate,
  onAddLockedBlock,
  onDeleteLockedBlock,
  onUpdateSchoolSyncConfig,
  onApplySchoolWebSync,
  onSaveGoalWithRoadmap,
  onSaveMemory,
  onApplyFeedbackAdjustedTasks,
  onApplyGanttTemplate,
  onCompactDaySchedule,
}) => {
  const [displayFormat, setDisplayFormat] = useState<ScheduleDisplayFormat>('gantt');
  const [ganttScale, setGanttScale] = useState<GanttScaleMode>('intraday');
  const [filterCategory, setFilterCategory] = useState<TaskCategory | 'all'>('all');
  const [showTemplates, setShowTemplates] = useState(false);

  // Collapsed by default so the schedule & Gantt chart are front and center!
  const [activeCoreAction, setActiveCoreAction] = useState<CoreActionTab>(null);
  const [lockedSubTab, setLockedSubTab] = useState<'school' | 'manual'>('school');

  // 1. Goal & Roadmap state
  const [quickGoalTitle, setQuickGoalTitle] = useState('');
  const [quickRoadmapText, setQuickRoadmapText] = useState('');
  const [isGeneratingRoadmap, setIsGeneratingRoadmap] = useState(false);

  // 2. Daily Habit state
  const [habitTitle, setHabitTitle] = useState('');
  const [habitStart, setHabitStart] = useState('16:30');
  const [habitEnd, setHabitEnd] = useState('17:15');

  // 3. Locked Block state
  const [lockTitle, setLockTitle] = useState('');
  const [lockStart, setLockStart] = useState('17:30');
  const [lockEnd, setLockEnd] = useState('19:00');
  const [lockPreset, setLockPreset] = useState<'weekdays' | 'everyday' | 'custom'>('weekdays');
  const [lockCustomDays, setLockCustomDays] = useState<number[]>([1, 3, 5]);
  const [isSyncingSchool, setIsSyncingSchool] = useState(false);

  // 4. AI Feedback state
  const [feedbackText, setFeedbackText] = useState('');
  const [isSubmittingFeedback, setIsSubmittingFeedback] = useState(false);

  const toggleCoreAction = (tab: Exclude<CoreActionTab, null>) => {
    setActiveCoreAction((prev) => (prev === tab ? null : tab));
  };

  // 7-day strip around selectedDate
  const weekDays = useMemo(() => {
    const dayNames = ['CN', 'T2', 'T3', 'T4', 'T5', 'T6', 'T7'];
    return Array.from({ length: 7 }, (_, idx) => {
      const dStr = addDaysStr(selectedDate, idx - 3);
      const wd = getWeekdayFromDateStr(dStr);
      const [, , d] = dStr.split('-').map(Number);
      const hasItems =
        tasks.some((t) => t.date === dStr) ||
        lockedBlocks.some((b) => b.daysOfWeek.includes(wd));
      return {
        dateStr: dStr,
        dayName: dayNames[wd],
        dayNum: d,
        hasItems,
      };
    });
  }, [selectedDate, tasks, lockedBlocks]);

  // Dates in current viewMode
  const activeDates = useMemo(() => {
    if (viewMode === 'day') return [selectedDate];
    if (viewMode === 'multiday') {
      return [selectedDate, addDaysStr(selectedDate, 1), addDaysStr(selectedDate, 2)];
    }
    if (viewMode === 'week') {
      return Array.from({ length: 7 }, (_, i) => addDaysStr(selectedDate, i));
    }
    return Array.from({ length: 14 }, (_, i) => addDaysStr(selectedDate, i));
  }, [selectedDate, viewMode]);

  // Merge Locked Blocks + Daily Habits + Goal Tasks for selectedDate (or activeDates)
  const unifiedDayItems = useMemo(() => {
    const list: {
      id: string;
      type: 'locked' | 'habit' | 'task';
      title: string;
      subtitle: string;
      date: string;
      startTime: string;
      endTime: string;
      completed: boolean;
      category: TaskCategory;
      rawTask?: ScheduleTask;
      habitId?: string;
      lockId?: string;
    }[] = [];

    for (const dStr of activeDates) {
      const wd = getWeekdayFromDateStr(dStr);

      // 1. Locked blocks
      lockedBlocks
        .filter((b) => b.daysOfWeek.includes(wd))
        .forEach((b) => {
          if (filterCategory === 'all' || filterCategory === 'commute') {
            list.push({
              id: `lock_${b.id}_${dStr}`,
              type: 'locked',
              title: b.title,
              subtitle: formatDaysOfWeekBadge(b.daysOfWeek),
              date: dStr,
              startTime: b.startTime,
              endTime: b.endTime,
              completed: false,
              category: 'commute',
              lockId: b.id,
            });
          }
        });

      // 2. Daily habits
      dailyHabits.forEach((h) => {
        if (filterCategory === 'all' || filterCategory === 'health') {
          const isDone = h.completedDates.includes(dStr);
          list.push({
            id: `habit_${h.id}_${dStr}`,
            type: 'habit',
            title: h.title,
            subtitle: `Streak ${h.currentStreak} ngày`,
            date: dStr,
            startTime: h.startTime,
            endTime: h.endTime,
            completed: isDone,
            category: 'health',
            habitId: h.id,
          });
        }
      });

      // 3. Explicit tasks
      tasks
        .filter((t) => t.date === dStr && (filterCategory === 'all' || t.category === filterCategory))
        .forEach((t) => {
          list.push({
            id: t.id,
            type: 'task',
            title: t.title,
            subtitle: t.notes || CATEGORY_LABELS[t.category],
            date: dStr,
            startTime: t.startTime,
            endTime: t.endTime,
            completed: t.completed,
            category: t.category,
            rawTask: t,
          });
        });
    }

    return list.sort((a, b) => {
      if (a.date !== b.date) return a.date.localeCompare(b.date);
      return a.startTime.localeCompare(b.startTime);
    });
  }, [activeDates, lockedBlocks, dailyHabits, tasks, filterCategory]);

  // Day summary stats for selectedDate
  const daySummary = useMemo(() => {
    const wd = getWeekdayFromDateStr(selectedDate);
    const dayLocks = lockedBlocks.filter((b) => b.daysOfWeek.includes(wd));
    const dayTasks = tasks.filter((t) => t.date === selectedDate);

    const lockedMins = dayLocks.reduce(
      (acc, b) => acc + Math.max(30, timeToMinutes(b.endTime) - timeToMinutes(b.startTime)),
      0
    );
    const goalMins = dayTasks.reduce(
      (acc, t) => acc + Math.max(30, timeToMinutes(t.endTime) - timeToMinutes(t.startTime)),
      0
    );
    const habitMins = dailyHabits.reduce(
      (acc, h) => acc + Math.max(20, timeToMinutes(h.endTime) - timeToMinutes(h.startTime)),
      0
    );
    const freeMins = Math.max(0, 16 * 60 - lockedMins - goalMins - habitMins - 150);

    return {
      lockedHours: (lockedMins / 60).toFixed(1),
      goalHours: ((goalMins + habitMins) / 60).toFixed(1),
      freeHours: (freeMins / 60).toFixed(1),
    };
  }, [selectedDate, lockedBlocks, tasks, dailyHabits]);

  // Action 1: AI Auto-distribute Goal + Roadmap
  const handleQuickRoadmapSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickRoadmapText.trim()) return;

    setIsGeneratingRoadmap(true);
    try {
      const title = quickGoalTitle.trim() || 'Lộ trình học tập cá nhân';
      let steps: AIGoalDailyStep[] = [];

      try {
        const res = await fetch('/api/gemini/goal-roadmap', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            rawRoadmapText: `${title}: ${quickRoadmapText}`,
            startDate: selectedDate,
            existingTasks: tasks,
            lockedBlocks,
            dailyHabits,
            activeMemories: memories.filter((m) => m.isActive),
          }),
        });
        if (res.ok) {
          const data = await res.json();
          if (Array.isArray(data.dailyPlan) && data.dailyPlan.length > 0) {
            steps = data.dailyPlan;
          }
        }
      } catch {
        // Fallback deterministic parser
      }

      if (steps.length === 0) {
        const parts = quickRoadmapText
          .split(/\n|;|•|-/)
          .map((s) => s.trim())
          .filter(Boolean);
        steps = parts.map((part, idx) => ({
          dayNumber: idx + 1,
          date: addDaysStr(selectedDate, idx),
          title: part.replace(/^(ngày\s*\d+\s*[:.-]?\s*)/i, '').trim() || `Bài ${idx + 1}`,
          notes: 'Lộ trình mục tiêu',
          startTime: '19:15',
          endTime: '21:15',
          freeTimeSummary: 'Khung giờ tối',
          isMinimumDaily: false,
        }));
      }

      onSaveGoalWithRoadmap(
        {
          title,
          description: quickRoadmapText.trim(),
          targetDate: addDaysStr(selectedDate, Math.max(1, steps.length)),
          dailyActionTitle: 'Học theo khung giờ trống AI phân bổ',
          dailyTargetMinutes: 120,
          totalTargetDays: Math.max(1, steps.length),
          completedDays: 0,
          progressPercent: 0,
          isAchieved: false,
          achievedDate: '',
        },
        steps
      );

      setQuickGoalTitle('');
      setQuickRoadmapText('');
      setActiveCoreAction(null);
    } finally {
      setIsGeneratingRoadmap(false);
    }
  };

  // Action 2: Add Daily Habit
  const handleAddHabitSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!habitTitle.trim()) return;
    onAddDailyHabit(habitTitle.trim(), habitStart, habitEnd);
    setHabitTitle('');
  };

  // Action 3A: Add Manual Locked Block
  const handleAddLockSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!lockTitle.trim()) return;
    const days =
      lockPreset === 'weekdays'
        ? [1, 2, 3, 4, 5]
        : lockPreset === 'everyday'
        ? [0, 1, 2, 3, 4, 5, 6]
        : lockCustomDays;
    onAddLockedBlock(lockTitle.trim(), days, lockStart, lockEnd);
    setLockTitle('');
  };

  // Action 3B: Sync School Timetable by Class
  const handleSelectAndSyncClass = async (targetClassName: string) => {
    setIsSyncingSchool(true);
    try {
      const parsed = parseClassTimetableFromBenCatExcel(targetClassName);
      const syncResult: AISchoolWebSyncResponse = {
        schoolNameOrPageTitle: 'THPT Bến Cát · File Excel TKB Tuần 9',
        detectedClassName: parsed.resolvedClassName,
        availableClassesOnPortal: parsed.availableClasses,
        activeVersionId: 'excel_main_tkblop_w9',
        activeVersionLabel: 'TKB Tuần 9 (Áp dụng 02/11/2026)',
        diffFromOldVersion: parsed.diffFromOldVersion,
        changeSummary: parsed.changeSummary,
        detectedChanges: parsed.diffFromOldVersion,
        classTimetable: parsed.classTimetable,
        extractedLockedBlocks: parsed.extractedLockedBlocks.map((b) => ({
          title: b.title,
          daysOfWeek: b.daysOfWeek,
          startTime: b.startTime,
          endTime: b.endTime,
        })),
      };

      const nextConfig: SchoolPortalSyncConfig = {
        ...schoolSyncConfig,
        selectedClassName: parsed.resolvedClassName,
        availableClasses: parsed.availableClasses,
        lastSyncedAt: 'Vừa đồng bộ',
        lastChangeSummary: parsed.changeSummary,
        classTimetable: parsed.classTimetable,
      };

      onApplySchoolWebSync(syncResult, nextConfig);
    } finally {
      setIsSyncingSchool(false);
    }
  };

  // Action 4: Submit AI Feedback
  const handleFeedbackSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!feedbackText.trim()) return;
    setIsSubmittingFeedback(true);
    try {
      const dayTasks = tasks.filter((t) => t.date === selectedDate);
      try {
        const res = await fetch('/api/gemini/feedback-adjust', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            userFeedback: feedbackText.trim(),
            targetDate: selectedDate,
            dayTasks,
            lockedBlocks,
            dailyHabits,
            activeMemories: memories.filter((m) => m.isActive),
          }),
        });
        if (res.ok) {
          const data: AIFeedbackAdjustResponse = await res.json();
          if (data.learnedHabitRule) {
            onSaveMemory(data.learnedHabitRule, data.learnedCategory || 'constraint');
          }
          if (Array.isArray(data.updatedDayTasks) && data.updatedDayTasks.length > 0) {
            onApplyFeedbackAdjustedTasks(selectedDate, data.updatedDayTasks);
          }
          setFeedbackText('');
          setActiveCoreAction(null);
          return;
        }
      } catch {
        // Fallback local save
      }

      onSaveMemory(feedbackText.trim(), 'constraint');
      setFeedbackText('');
      setActiveCoreAction(null);
    } finally {
      setIsSubmittingFeedback(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* 1. COMPACT 4-BUTTON ACTION BAR (COLLAPSED BY DEFAULT) */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-3 border border-slate-200/80 dark:border-slate-800 shadow-xs">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-2">
          <button
            type="button"
            onClick={() => toggleCoreAction('goal_roadmap')}
            className={`flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-left transition-all border ${
              activeCoreAction === 'goal_roadmap'
                ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                : 'bg-slate-50 dark:bg-slate-800/60 text-slate-800 dark:text-slate-200 border-slate-200/70 dark:border-slate-700/70 hover:border-indigo-400'
            }`}
          >
            <Sparkles className={`w-4 h-4 shrink-0 ${activeCoreAction === 'goal_roadmap' ? 'text-white' : 'text-indigo-500'}`} />
            <div className="min-w-0">
              <div className="text-xs font-bold truncate">+ Mục tiêu & Lộ trình</div>
              <div className={`text-[10px] truncate ${activeCoreAction === 'goal_roadmap' ? 'text-indigo-100' : 'text-slate-400'}`}>
                AI tự xếp vào giờ trống
              </div>
            </div>
          </button>

          <button
            type="button"
            onClick={() => toggleCoreAction('daily_habit')}
            className={`flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-left transition-all border ${
              activeCoreAction === 'daily_habit'
                ? 'bg-amber-500 text-white border-amber-500 shadow-xs'
                : 'bg-slate-50 dark:bg-slate-800/60 text-slate-800 dark:text-slate-200 border-slate-200/70 dark:border-slate-700/70 hover:border-amber-400'
            }`}
          >
            <Flame className={`w-4 h-4 shrink-0 ${activeCoreAction === 'daily_habit' ? 'text-white' : 'text-amber-500'}`} />
            <div className="min-w-0">
              <div className="text-xs font-bold truncate">Việc hàng ngày ({dailyHabits.length})</div>
              <div className={`text-[10px] truncate ${activeCoreAction === 'daily_habit' ? 'text-amber-100' : 'text-slate-400'}`}>
                Thêm / xóa nhanh
              </div>
            </div>
          </button>

          <button
            type="button"
            onClick={() => toggleCoreAction('locked_fixed')}
            className={`flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-left transition-all border ${
              activeCoreAction === 'locked_fixed'
                ? 'bg-slate-800 dark:bg-slate-700 text-white border-slate-800 shadow-xs'
                : 'bg-slate-50 dark:bg-slate-800/60 text-slate-800 dark:text-slate-200 border-slate-200/70 dark:border-slate-700/70 hover:border-slate-400'
            }`}
          >
            <Lock className={`w-4 h-4 shrink-0 ${activeCoreAction === 'locked_fixed' ? 'text-emerald-300' : 'text-emerald-500'}`} />
            <div className="min-w-0">
              <div className="text-xs font-bold truncate">
                TKB Lớp {schoolSyncConfig.selectedClassName} & Giờ chết
              </div>
              <div className={`text-[10px] truncate ${activeCoreAction === 'locked_fixed' ? 'text-slate-300' : 'text-slate-400'}`}>
                {lockedBlocks.length} khung giờ cố định
              </div>
            </div>
          </button>

          <button
            type="button"
            onClick={() => toggleCoreAction('ai_feedback')}
            className={`flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-left transition-all border ${
              activeCoreAction === 'ai_feedback'
                ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                : 'bg-slate-50 dark:bg-slate-800/60 text-slate-800 dark:text-slate-200 border-slate-200/70 dark:border-slate-700/70 hover:border-emerald-400'
            }`}
          >
            <Brain className={`w-4 h-4 shrink-0 ${activeCoreAction === 'ai_feedback' ? 'text-white' : 'text-emerald-500'}`} />
            <div className="min-w-0">
              <div className="text-xs font-bold truncate">Góp ý AI ({memories.length})</div>
              <div className={`text-[10px] truncate ${activeCoreAction === 'ai_feedback' ? 'text-emerald-100' : 'text-slate-400'}`}>
                Đệm việc vặt ±20p tự động
              </div>
            </div>
          </button>
        </div>

        {/* EXPANDABLE DRAWER */}
        {activeCoreAction && (
          <div className="mt-3 pt-3 border-t border-slate-200/80 dark:border-slate-800">
            {/* Drawer 1: Goal & Roadmap */}
            {activeCoreAction === 'goal_roadmap' && (
              <form onSubmit={handleQuickRoadmapSubmit} className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-800 dark:text-slate-100">
                    Nhập mục tiêu & danh sách bài học (AI tự né TKB Lớp {schoolSyncConfig.selectedClassName})
                  </span>
                  <button
                    type="button"
                    onClick={() => setActiveCoreAction(null)}
                    className="text-xs text-slate-400 hover:text-slate-600 flex items-center gap-1"
                  >
                    Đóng <X className="w-3.5 h-3.5" />
                  </button>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  <input
                    type="text"
                    value={quickGoalTitle}
                    onChange={(e) => setQuickGoalTitle(e.target.value)}
                    placeholder="Tên mục tiêu (VD: Ôn thi Toán 9+)"
                    className="px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
                  />
                  <input
                    type="text"
                    value={quickRoadmapText}
                    onChange={(e) => setQuickRoadmapText(e.target.value)}
                    placeholder="Dán lộ trình: Bài 1 Hàm số; Bài 2 Cực trị; Bài 3 Tích phân..."
                    className="sm:col-span-2 px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
                    required
                  />
                </div>
                <div className="flex justify-end">
                  <button
                    type="submit"
                    disabled={isGeneratingRoadmap}
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-xs font-semibold"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    {isGeneratingRoadmap ? 'AI đang chia lịch...' : 'Tự động xếp vào khung giờ trống'}
                  </button>
                </div>
              </form>
            )}

            {/* Drawer 2: Daily Habits */}
            {activeCoreAction === 'daily_habit' && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-800 dark:text-slate-100">
                    Việc hàng ngày tối thiểu (Chỉ thêm hoặc xóa)
                  </span>
                  <button
                    type="button"
                    onClick={() => setActiveCoreAction(null)}
                    className="text-xs text-slate-400 hover:text-slate-600 flex items-center gap-1"
                  >
                    Đóng <X className="w-3.5 h-3.5" />
                  </button>
                </div>

                <form onSubmit={handleAddHabitSubmit} className="flex flex-wrap gap-2">
                  <input
                    type="text"
                    value={habitTitle}
                    onChange={(e) => setHabitTitle(e.target.value)}
                    placeholder="Tên việc hàng ngày (VD: Học 30 từ vựng Anki)..."
                    className="flex-1 min-w-[200px] px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
                    required
                  />
                  <input
                    type="time"
                    value={habitStart}
                    onChange={(e) => setHabitStart(e.target.value)}
                    className="px-2.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
                  />
                  <input
                    type="time"
                    value={habitEnd}
                    onChange={(e) => setHabitEnd(e.target.value)}
                    className="px-2.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
                  />
                  <button
                    type="submit"
                    className="inline-flex items-center gap-1 px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-white text-xs font-semibold"
                  >
                    <Plus className="w-3.5 h-3.5" /> Thêm
                  </button>
                </form>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {dailyHabits.map((h) => {
                    const isDone = h.completedDates.includes(selectedDate);
                    return (
                      <div
                        key={h.id}
                        className="flex items-center justify-between px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/70 dark:border-slate-700 text-xs"
                      >
                        <button
                          type="button"
                          onClick={() => onToggleDailyHabitForDate(h.id, selectedDate)}
                          className="flex items-center gap-2 text-left min-w-0 flex-1"
                        >
                          {isDone ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                          ) : (
                            <Circle className="w-4 h-4 text-slate-400 shrink-0" />
                          )}
                          <span className={`truncate font-medium ${isDone ? 'line-through text-slate-400' : 'text-slate-800 dark:text-slate-200'}`}>
                            {h.title} ({h.startTime}–{h.endTime})
                          </span>
                        </button>
                        <button
                          type="button"
                          onClick={() => onDeleteDailyHabit(h.id)}
                          className="p-1 text-slate-400 hover:text-rose-500"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Drawer 3: School Timetable & Locked Fixed Blocks */}
            {activeCoreAction === 'locked_fixed' && (
              <div className="space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl">
                    <button
                      type="button"
                      onClick={() => setLockedSubTab('school')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                        lockedSubTab === 'school'
                          ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-2xs'
                          : 'text-slate-500'
                      }`}
                    >
                      TKB Trường THPT Bến Cát (47 lớp)
                    </button>
                    <button
                      type="button"
                      onClick={() => setLockedSubTab('manual')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                        lockedSubTab === 'manual'
                          ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-2xs'
                          : 'text-slate-500'
                      }`}
                    >
                      Giờ cố định & Học thêm ({lockedBlocks.length})
                    </button>
                  </div>
                  <button
                    type="button"
                    onClick={() => setActiveCoreAction(null)}
                    className="text-xs text-slate-400 hover:text-slate-600 flex items-center gap-1"
                  >
                    Đóng <X className="w-3.5 h-3.5" />
                  </button>
                </div>

                {lockedSubTab === 'school' ? (
                  <div className="space-y-3">
                    <div className="flex flex-wrap items-center justify-between gap-2 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-700">
                      <div className="flex flex-wrap items-center gap-2">
                        <Globe className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                        <span className="text-xs font-bold text-slate-800 dark:text-slate-100">
                          Lớp:
                        </span>
                        <select
                          value={schoolSyncConfig.selectedClassName}
                          onChange={(e) => handleSelectAndSyncClass(e.target.value)}
                          className="px-2.5 py-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-xs font-bold text-emerald-700 dark:text-emerald-300"
                        >
                          {(schoolSyncConfig.availableClasses || ['12C1', '12C2', '11C1', '10C1']).map((cls) => (
                            <option key={cls} value={cls}>
                              Lớp {cls}
                            </option>
                          ))}
                        </select>
                        <span className="text-[11px] text-slate-500">
                          {schoolSyncConfig.activeVersionLabel || 'File Excel TKB Tuần 9'}
                        </span>
                      </div>

                      <div className="flex items-center gap-2">
                        <a
                          href="https://docs.google.com/spreadsheets/d/1I5S5BRIEqUyatU9BDKLHE-ZQWvjatKtr/edit"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-[11px] font-medium text-slate-600 dark:text-slate-300 hover:text-indigo-600"
                        >
                          Mở Excel trường <ExternalLink className="w-3 h-3" />
                        </a>
                        <button
                          type="button"
                          onClick={() => handleSelectAndSyncClass(schoolSyncConfig.selectedClassName)}
                          disabled={isSyncingSchool}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold"
                        >
                          <RefreshCw className={`w-3.5 h-3.5 ${isSyncingSchool ? 'animate-spin' : ''}`} />
                          Đồng bộ lại
                        </button>
                      </div>
                    </div>

                    {/* Clean 6-day Class Timetable Grid */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                      {schoolSyncConfig.classTimetable.map((day) => (
                        <div
                          key={day.dayOfWeek}
                          className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200/70 dark:border-slate-800 text-xs space-y-1"
                        >
                          <div className="font-bold text-slate-800 dark:text-slate-200">
                            {day.dayLabel}
                          </div>
                          <div className="text-[11px] text-slate-600 dark:text-slate-300 leading-relaxed">
                            {day.morningSummary}
                          </div>
                          <div className="text-[11px] text-indigo-600 dark:text-indigo-400">
                            {day.afternoonSummary}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <form onSubmit={handleAddLockSubmit} className="grid grid-cols-1 sm:grid-cols-5 gap-2">
                      <input
                        type="text"
                        value={lockTitle}
                        onChange={(e) => setLockTitle(e.target.value)}
                        placeholder="VD: Học thêm Toán ca tối"
                        className="sm:col-span-2 px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
                        required
                      />
                      <div className="flex items-center gap-1">
                        <input
                          type="time"
                          value={lockStart}
                          onChange={(e) => setLockStart(e.target.value)}
                          className="w-full px-2 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
                        />
                        <span className="text-slate-400">-</span>
                        <input
                          type="time"
                          value={lockEnd}
                          onChange={(e) => setLockEnd(e.target.value)}
                          className="w-full px-2 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
                        />
                      </div>
                      <select
                        value={lockPreset}
                        onChange={(e) => setLockPreset(e.target.value as 'weekdays' | 'everyday' | 'custom')}
                        className="px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-800 dark:text-slate-200"
                      >
                        <option value="weekdays">T2 – T6</option>
                        <option value="everyday">Mỗi ngày</option>
                        <option value="custom">Chọn thứ...</option>
                      </select>
                      <button
                        type="submit"
                        className="px-4 py-2 rounded-xl bg-slate-800 dark:bg-indigo-600 text-white text-xs font-semibold"
                      >
                        + Khóa giờ
                      </button>
                    </form>

                    {lockPreset === 'custom' && (
                      <div className="flex items-center gap-1.5">
                        {WEEKDAY_LABELS.map((w) => {
                          const active = lockCustomDays.includes(w.day);
                          return (
                            <button
                              key={w.day}
                              type="button"
                              onClick={() =>
                                setLockCustomDays((prev) =>
                                  prev.includes(w.day) ? prev.filter((d) => d !== w.day) : [...prev, w.day]
                                )
                              }
                              className={`px-2.5 py-1 rounded-lg text-xs font-semibold ${
                                active
                                  ? 'bg-indigo-600 text-white'
                                  : 'bg-slate-100 dark:bg-slate-800 text-slate-500'
                              }`}
                            >
                              {w.short}
                            </button>
                          );
                        })}
                      </div>
                    )}

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {lockedBlocks.map((b) => (
                        <div
                          key={b.id}
                          className="flex items-center justify-between px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/70 dark:border-slate-700 text-xs"
                        >
                          <div className="min-w-0 flex-1">
                            <div className="font-semibold text-slate-800 dark:text-slate-200 truncate">
                              {b.title}
                            </div>
                            <div className="text-[11px] text-slate-500 tabular-nums">
                              {b.startTime} – {b.endTime} · {formatDaysOfWeekBadge(b.daysOfWeek)}
                            </div>
                          </div>
                          <button
                            type="button"
                            onClick={() => onDeleteLockedBlock(b.id)}
                            className="p-1 text-slate-400 hover:text-rose-500"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Drawer 4: AI Feedback & Memories */}
            {activeCoreAction === 'ai_feedback' && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-800 dark:text-slate-100">
                    Nêu ý kiến để AI điều chỉnh lịch & ghi nhớ thói quen cá nhân
                  </span>
                  <button
                    type="button"
                    onClick={() => setActiveCoreAction(null)}
                    className="text-xs text-slate-400 hover:text-slate-600 flex items-center gap-1"
                  >
                    Đóng <X className="w-3.5 h-3.5" />
                  </button>
                </div>

                <form onSubmit={handleFeedbackSubmit} className="flex gap-2">
                  <input
                    type="text"
                    value={feedbackText}
                    onChange={(e) => setFeedbackText(e.target.value)}
                    placeholder="VD: Đừng xếp bài học trước 19h15 tối vì mình ăn tối muộn..."
                    className="flex-1 px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
                    required
                  />
                  <button
                    type="submit"
                    disabled={isSubmittingFeedback}
                    className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold shrink-0"
                  >
                    {isSubmittingFeedback ? 'Đang xử lý...' : 'Gửi & Dạy AI'}
                  </button>
                </form>

                {memories.length > 0 && (
                  <div className="flex flex-wrap gap-1.5">
                    {memories.map((m) => (
                      <span
                        key={m.id}
                        className="px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-[11px] text-slate-600 dark:text-slate-300"
                      >
                        {m.content}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>

      {/* 2. DATE NAVIGATION & VIEW SWITCHER */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-3.5 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => onSelectDate(addDaysStr(selectedDate, -1))}
              className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-400"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => onSelectDate(getTodayStr())}
              className="px-2.5 py-1 text-xs font-semibold rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400"
            >
              Hôm nay
            </button>
            <button
              type="button"
              onClick={() => onSelectDate(addDaysStr(selectedDate, 1))}
              className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-400"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
            <span className="text-xs font-bold text-slate-800 dark:text-slate-200 ml-1 tabular-nums">
              {selectedDate}
            </span>
          </div>

          {/* Concise KPI Summary */}
          <div className="hidden md:flex items-center gap-4 text-xs">
            <span className="text-slate-500">
              Giờ trường: <strong className="text-slate-800 dark:text-slate-200 tabular-nums">{daySummary.lockedHours}h</strong>
            </span>
            <span className="text-slate-500">
              Mục tiêu: <strong className="text-indigo-600 dark:text-indigo-400 tabular-nums">{daySummary.goalHours}h</strong>
            </span>
            <span className="text-slate-500">
              Rảnh: <strong className="text-emerald-600 dark:text-emerald-400 tabular-nums">{daySummary.freeHours}h</strong>
            </span>
          </div>

          {/* Range & Display Format Switchers */}
          <div className="flex items-center gap-2">
            <div className="flex bg-slate-100 dark:bg-slate-800 p-0.5 rounded-xl">
              {(
                [
                  { id: 'day', label: 'Ngày' },
                  { id: 'multiday', label: '3 Ngày' },
                  { id: 'week', label: 'Tuần' },
                ] as { id: ScheduleViewMode; label: string }[]
              ).map((m) => (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => onChangeViewMode(m.id)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all ${
                    viewMode === m.id
                      ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-2xs'
                      : 'text-slate-500'
                  }`}
                >
                  {m.label}
                </button>
              ))}
            </div>

            <div className="flex bg-slate-100 dark:bg-slate-800 p-0.5 rounded-xl">
              {(
                [
                  { id: 'gantt', label: 'Gantt', icon: BarChartHorizontal },
                  { id: 'list', label: 'Danh sách', icon: LayoutList },
                  { id: 'donut', label: 'Tỷ trọng', icon: PieChartIcon },
                  { id: 'kanban', label: 'Bảng', icon: Columns },
                ] as { id: ScheduleDisplayFormat; label: string; icon: React.ComponentType<{ className?: string }> }[]
              ).map((fmt) => {
                const Icon = fmt.icon;
                return (
                  <button
                    key={fmt.id}
                    type="button"
                    onClick={() => setDisplayFormat(fmt.id)}
                    className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold transition-all ${
                      displayFormat === fmt.id
                        ? 'bg-indigo-600 text-white shadow-2xs'
                        : 'text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">{fmt.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* 7-Day Strip */}
        <div className="grid grid-cols-7 gap-1.5">
          {weekDays.map((item) => {
            const isSelected = item.dateStr === selectedDate;
            const isToday = item.dateStr === getTodayStr();
            return (
              <button
                key={item.dateStr}
                type="button"
                onClick={() => onSelectDate(item.dateStr)}
                className={`flex flex-col items-center py-2 rounded-xl transition-all border ${
                  isSelected
                    ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                    : isToday
                    ? 'bg-indigo-50/70 dark:bg-indigo-950/30 text-indigo-600 dark:text-indigo-400 border-indigo-200 dark:border-indigo-800/60'
                    : 'bg-slate-50/70 dark:bg-slate-800/40 text-slate-600 dark:text-slate-400 border-transparent hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <span className={`text-[10px] font-medium ${isSelected ? 'text-indigo-100' : 'text-slate-400'}`}>
                  {item.dayName}
                </span>
                <span className="text-sm font-bold tabular-nums mt-0.5">{item.dayNum}</span>
                <div className="h-1 mt-1">
                  {item.hasItems && (
                    <span className={`block w-1 h-1 rounded-full ${isSelected ? 'bg-white' : 'bg-indigo-500'}`} />
                  )}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* 3. GANTT CHART / VISUALIZATION */}
      {displayFormat === 'gantt' && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <BarChartHorizontal className="w-4 h-4 text-indigo-500" />
              Sơ đồ Gantt ({selectedDate})
            </h3>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => onCompactDaySchedule(selectedDate)}
                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-medium bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-100"
              >
                <Zap className="w-3.5 h-3.5" /> Tối ưu giờ trống
              </button>

              <button
                type="button"
                onClick={() => setShowTemplates((prev) => !prev)}
                className="px-2.5 py-1 rounded-lg text-xs font-medium bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300"
              >
                {showTemplates ? 'Ẩn mẫu Gantt' : 'Mẫu Gantt nhanh'}
              </button>

              <div className="flex bg-slate-100 dark:bg-slate-800 p-0.5 rounded-xl">
                <button
                  type="button"
                  onClick={() => setGanttScale('intraday')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-semibold ${
                    ganttScale === 'intraday'
                      ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-2xs'
                      : 'text-slate-500'
                  }`}
                >
                  Trong ngày
                </button>
                <button
                  type="button"
                  onClick={() => setGanttScale('multiday')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-semibold ${
                    ganttScale === 'multiday'
                      ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-2xs'
                      : 'text-slate-500'
                  }`}
                >
                  5 ngày
                </button>
              </div>
            </div>
          </div>

          {/* Collapsible Quick Gantt Templates */}
          {showTemplates && (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/70 dark:border-slate-800">
              {[
                {
                  id: 'deep_focus' as const,
                  title: 'Học sâu Cân bằng',
                  desc: '2 ca chiều + 1 ca tối, trừ hao sẵn giờ nghỉ trưa và ăn tối.',
                },
                {
                  id: 'exam_sprint' as const,
                  title: 'Nước rút Ôn thi',
                  desc: 'Gom 2 ca dài chiều & tối để giải đề chuyên sâu.',
                },
                {
                  id: 'weekend_full' as const,
                  title: 'Cuối tuần Toàn thời gian',
                  desc: '3 ca Sáng – Chiều – Tối cho ngày nghỉ không học ở trường.',
                },
              ].map((tpl) => (
                <div
                  key={tpl.id}
                  className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-700 flex flex-col justify-between gap-2"
                >
                  <div>
                    <div className="text-xs font-bold text-slate-800 dark:text-slate-100">{tpl.title}</div>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">{tpl.desc}</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      onApplyGanttTemplate(tpl.id, selectedDate);
                      setShowTemplates(false);
                    }}
                    className="w-full py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold"
                  >
                    Áp dụng mẫu
                  </button>
                </div>
              ))}
            </div>
          )}

          {ganttScale === 'intraday' ? (
            <div className="overflow-x-auto">
              <div className="min-w-[600px]">
                <div className="grid grid-cols-[190px_1fr] border-b border-slate-200 dark:border-slate-800 pb-2 mb-2">
                  <div className="text-[11px] font-semibold text-slate-400 uppercase">Hoạt động</div>
                  <div className="grid grid-cols-17 text-[10px] font-medium text-slate-400 tabular-nums">
                    {Array.from({ length: 17 }, (_, i) => i + 6).map((h) => (
                      <div key={h} className="text-center">
                        {String(h).padStart(2, '0')}h
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-1.5">
                  {unifiedDayItems
                    .filter((item) => item.date === selectedDate)
                    .map((item) => {
                      const minHour = 6;
                      const spanMins = 17 * 60;
                      const sMins = Math.max(0, timeToMinutes(item.startTime) - minHour * 60);
                      const eMins = Math.min(spanMins, timeToMinutes(item.endTime) - minHour * 60);
                      const leftPct = Math.max(0, Math.min(95, (sMins / spanMins) * 100));
                      const widthPct = Math.max(5, Math.min(100 - leftPct, ((eMins - sMins) / spanMins) * 100));

                      const barColor =
                        item.type === 'locked'
                          ? 'bg-slate-600 dark:bg-slate-700'
                          : item.type === 'habit'
                          ? 'bg-amber-500'
                          : 'bg-indigo-600';

                      return (
                        <div
                          key={item.id}
                          className="grid grid-cols-[190px_1fr] items-center gap-2 py-1 border-b border-slate-100 dark:border-slate-800/50 last:border-none"
                        >
                          <div className="flex items-center gap-1.5 pr-2 truncate">
                            {item.type === 'locked' ? (
                              <Lock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                            ) : (
                              <button
                                type="button"
                                onClick={() =>
                                  item.type === 'habit' && item.habitId
                                    ? onToggleDailyHabitForDate(item.habitId, item.date)
                                    : item.rawTask && onToggleTask(item.rawTask.id)
                                }
                                className="text-slate-400 hover:text-indigo-600 shrink-0"
                              >
                                {item.completed ? (
                                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                                ) : (
                                  <Circle className="w-3.5 h-3.5" />
                                )}
                              </button>
                            )}
                            <span
                              className={`text-xs font-medium truncate ${
                                item.completed
                                  ? 'line-through text-slate-400'
                                  : 'text-slate-800 dark:text-slate-200'
                              }`}
                              title={item.title}
                            >
                              {item.title}
                            </span>
                          </div>

                          <div className="relative h-7 bg-slate-100/70 dark:bg-slate-800/50 rounded-lg overflow-hidden">
                            <div
                              style={{ left: `${leftPct}%`, width: `${widthPct}%` }}
                              className={`absolute top-1 bottom-1 rounded-md ${barColor} ${
                                item.completed ? 'opacity-45' : 'opacity-95'
                              } flex items-center px-2 text-[10px] font-semibold text-white whitespace-nowrap overflow-hidden tabular-nums`}
                            >
                              {item.startTime}–{item.endTime}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                </div>
              </div>
            </div>
          ) : (
            /* 5-day roadmap view */
            <div className="overflow-x-auto">
              <div className="min-w-[540px] space-y-1.5">
                {(() => {
                  const fiveDays = Array.from({ length: 5 }, (_, i) => addDaysStr(selectedDate, i));
                  return (
                    <>
                      <div className="grid grid-cols-[190px_repeat(5,1fr)] gap-1.5 pb-2 border-b border-slate-200 dark:border-slate-800">
                        <div className="text-[11px] font-semibold text-slate-400 uppercase">Bài học / Mục tiêu</div>
                        {fiveDays.map((d) => (
                          <div key={d} className="text-center text-xs font-bold text-slate-700 dark:text-slate-300 tabular-nums">
                            {d.slice(8, 10)}/{d.slice(5, 7)}
                          </div>
                        ))}
                      </div>
                      {fiveDays.flatMap((d) =>
                        tasks
                          .filter((t) => t.date === d)
                          .map((t) => (
                            <div
                              key={t.id}
                              className="grid grid-cols-[190px_repeat(5,1fr)] gap-1.5 items-center py-1 border-b border-slate-100 dark:border-slate-800/40"
                            >
                              <div className="text-xs font-medium text-slate-800 dark:text-slate-200 truncate pr-2">
                                {t.title}
                              </div>
                              {fiveDays.map((col) => (
                                <div key={col} className="h-6 rounded-md bg-slate-50 dark:bg-slate-800/30 flex items-center justify-center">
                                  {col === t.date && (
                                    <div className="w-full h-5 mx-0.5 rounded bg-indigo-600 text-white text-[10px] font-semibold flex items-center justify-center tabular-nums">
                                      {t.startTime}
                                    </div>
                                  )}
                                </div>
                              ))}
                            </div>
                          ))
                      )}
                    </>
                  );
                })()}
              </div>
            </div>
          )}
        </div>
      )}

      {/* DONUT / PROPORTION VIEW */}
      {displayFormat === 'donut' && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-3">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white">
            Tỷ trọng thời gian trong ngày ({selectedDate})
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/60 dark:border-slate-700">
              <span className="text-xs text-slate-500">Học chính khóa / Cố định</span>
              <p className="text-xl font-bold text-slate-800 dark:text-white tabular-nums mt-1">
                {daySummary.lockedHours} giờ
              </p>
            </div>
            <div className="p-3.5 rounded-xl bg-indigo-50/50 dark:bg-indigo-950/30 border border-indigo-200/60 dark:border-indigo-800/60">
              <span className="text-xs text-indigo-600 dark:text-indigo-400">Lộ trình Mục tiêu & Thói quen</span>
              <p className="text-xl font-bold text-indigo-600 dark:text-indigo-400 tabular-nums mt-1">
                {daySummary.goalHours} giờ
              </p>
            </div>
            <div className="p-3.5 rounded-xl bg-emerald-50/50 dark:bg-emerald-950/30 border border-emerald-200/60 dark:border-emerald-800/60">
              <span className="text-xs text-emerald-600 dark:text-emerald-400">Thời gian rảnh còn lại</span>
              <p className="text-xl font-bold text-emerald-600 dark:text-emerald-400 tabular-nums mt-1">
                {daySummary.freeHours} giờ
              </p>
            </div>
          </div>
        </div>
      )}

      {/* KANBAN VIEW */}
      {displayFormat === 'kanban' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {[
            {
              title: 'Cần làm',
              items: unifiedDayItems.filter((i) => i.type !== 'locked' && !i.completed),
            },
            {
              title: 'Lịch cố định trên trường',
              items: unifiedDayItems.filter((i) => i.type === 'locked'),
            },
            {
              title: 'Đã xong',
              items: unifiedDayItems.filter((i) => i.completed),
            },
          ].map((col, idx) => (
            <div
              key={idx}
              className="bg-white dark:bg-slate-900 rounded-2xl p-3.5 border border-slate-200/80 dark:border-slate-800 space-y-2"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-700 dark:text-slate-200">{col.title}</span>
                <span className="text-xs font-bold text-slate-400 tabular-nums">{col.items.length}</span>
              </div>
              <div className="space-y-2">
                {col.items.map((item) => (
                  <div
                    key={item.id}
                    className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/60 dark:border-slate-700/60 flex items-start justify-between gap-2"
                  >
                    <div className="min-w-0">
                      <div className="text-xs font-semibold text-slate-800 dark:text-slate-100 truncate">
                        {item.title}
                      </div>
                      <div className="text-[11px] text-slate-500 tabular-nums mt-0.5">
                        {item.startTime} – {item.endTime}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* 4. CLEAN SCHEDULE LIST */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Calendar className="w-4 h-4 text-indigo-500" />
            Danh sách hoạt động ({unifiedDayItems.length})
          </h3>

          <div className="flex items-center gap-1 overflow-x-auto">
            <button
              type="button"
              onClick={() => setFilterCategory('all')}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold ${
                filterCategory === 'all'
                  ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900'
                  : 'text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              Tất cả
            </button>
            {(Object.keys(CATEGORY_LABELS) as TaskCategory[]).map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setFilterCategory(cat)}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold ${
                  filterCategory === cat
                    ? 'bg-indigo-600 text-white'
                    : 'text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                {CATEGORY_LABELS[cat]}
              </button>
            ))}
          </div>
        </div>

        {unifiedDayItems.length === 0 ? (
          <div className="text-center py-8 text-xs text-slate-400">
            Chưa có hoạt động nào trong ngày này.
          </div>
        ) : (
          <div className="divide-y divide-slate-100 dark:divide-slate-800/60">
            {unifiedDayItems.map((item) => (
              <div
                key={item.id}
                className={`py-2.5 flex items-center justify-between gap-3 ${
                  item.completed ? 'opacity-60' : ''
                }`}
              >
                <div className="flex items-center gap-3 min-w-0 flex-1">
                  {item.type === 'locked' ? (
                    <Lock className="w-4 h-4 text-slate-400 shrink-0" />
                  ) : (
                    <button
                      type="button"
                      onClick={() =>
                        item.type === 'habit' && item.habitId
                          ? onToggleDailyHabitForDate(item.habitId, item.date)
                          : item.rawTask && onToggleTask(item.rawTask.id)
                      }
                      className="shrink-0 text-slate-400 hover:text-indigo-600"
                    >
                      {item.completed ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                      ) : (
                        <Circle className="w-4 h-4" />
                      )}
                    </button>
                  )}

                  <div className="w-24 shrink-0 text-xs font-semibold text-slate-600 dark:text-slate-300 tabular-nums">
                    {item.startTime} – {item.endTime}
                  </div>

                  <div className="min-w-0 flex-1">
                    <div className="text-xs font-semibold text-slate-900 dark:text-white truncate">
                      {item.title}
                    </div>
                    {item.subtitle && (
                      <div className="text-[11px] text-slate-400 dark:text-slate-500 truncate">
                        {item.subtitle}
                      </div>
                    )}
                  </div>
                </div>

                {item.type === 'task' && item.rawTask && (
                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      type="button"
                      onClick={() => onReportIncident(item.rawTask!)}
                      className="p-1.5 text-slate-400 hover:text-amber-500 rounded-lg"
                      title="Dời lịch thông minh"
                    >
                      <AlertCircle className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => onDeleteTask(item.rawTask!.id)}
                      className="p-1.5 text-slate-400 hover:text-rose-500 rounded-lg"
                      title="Xóa"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
