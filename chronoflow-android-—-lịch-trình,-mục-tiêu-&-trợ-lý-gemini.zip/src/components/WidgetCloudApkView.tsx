import React, { useState, useEffect } from 'react';
import {
  Smartphone,
  Cloud,
  HardDrive,
  Bell,
  Download,
  Upload,
  CheckCircle2,
  Circle,
  Flame,
  AlertTriangle,
  Maximize2,
  Minimize2,
  RefreshCw,
  LogOut,
  Trash2,
  Target,
} from 'lucide-react';
import { User } from 'firebase/auth';
import {
  ScheduleTask,
  GoalItem,
  AIMemoryItem,
  WidgetSize,
  DriveBackupFile,
  getTodayStr,
} from '../types';
import {
  listDriveBackups,
  uploadBackupToDrive,
  downloadBackupFromDrive,
  deleteBackupFromDrive,
  ChronoFlowBackupPayload,
} from '../services/driveService';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface WidgetCloudApkViewProps {
  user: User | null;
  accessToken: string | null;
  tasks: ScheduleTask[];
  goals: GoalItem[];
  memories: AIMemoryItem[];
  pinnedWidgetSize: WidgetSize;
  notificationsEnabled: boolean;
  lastDriveBackupAt: string;
  onChangeWidgetSize: (size: WidgetSize) => void;
  onToggleNotifications: () => void;
  onTestPushNotification: () => void;
  onToggleTask: (taskId: string) => void;
  onReportIncident: (task: ScheduleTask) => void;
  onGoogleLogin: () => Promise<void>;
  onGoogleLogout: () => Promise<void>;
  onRestoreBackupData: (payload: ChronoFlowBackupPayload) => Promise<void>;
  onRecordDriveBackupTime: (timestampStr: string) => void;
}

export const WidgetCloudApkView: React.FC<WidgetCloudApkViewProps> = ({
  user,
  accessToken,
  tasks,
  goals,
  memories,
  pinnedWidgetSize,
  notificationsEnabled,
  lastDriveBackupAt,
  onChangeWidgetSize,
  onToggleNotifications,
  onTestPushNotification,
  onToggleTask,
  onReportIncident,
  onGoogleLogin,
  onGoogleLogout,
  onRestoreBackupData,
  onRecordDriveBackupTime,
}) => {
  const { isInstallable, isInstalled, install } = usePWAInstall();
  const [isLauncherMode, setIsLauncherMode] = useState(false);

  // Google Drive states
  const [driveFiles, setDriveFiles] = useState<DriveBackupFile[]>([]);
  const [isLoadingDrive, setIsLoadingDrive] = useState(false);
  const [driveStatusMsg, setDriveStatusMsg] = useState<string | null>(null);
  const [driveErrorMsg, setDriveErrorMsg] = useState<string | null>(null);

  // Mandatory Confirmation Dialog state for destructive / mutating Drive operations
  const [confirmDialog, setConfirmDialog] = useState<{
    title: string;
    description: string;
    confirmLabel: string;
    onConfirm: () => Promise<void>;
  } | null>(null);

  const today = getTodayStr();
  const todayTasks = tasks
    .filter((t) => t.date === today)
    .sort((a, b) => a.startTime.localeCompare(b.startTime));
  const minDailyToday = todayTasks.filter((t) => t.isMinimumDaily);
  const maxStreak = tasks.reduce((m, t) => Math.max(m, t.currentStreak), 0);
  const activeGoals = goals.filter((g) => !g.isAchieved);

  const fetchDriveFileList = async (token: string) => {
    setIsLoadingDrive(true);
    setDriveErrorMsg(null);
    try {
      const files = await listDriveBackups(token);
      setDriveFiles(files);
    } catch (err: unknown) {
      setDriveErrorMsg(err instanceof Error ? err.message : 'Không thể tải danh sách file từ Google Drive.');
    } finally {
      setIsLoadingDrive(false);
    }
  };

  useEffect(() => {
    if (accessToken) {
      fetchDriveFileList(accessToken);
    } else {
      setDriveFiles([]);
    }
  }, [accessToken]);

  const buildBackupPayload = (): ChronoFlowBackupPayload => ({
    appVersion: '1.0.0-android-apk',
    exportedAt: new Date().toISOString(),
    tasks,
    goals,
    memories,
    settings: {
      pinnedWidgetSize,
      notificationsEnabled,
      lastDriveBackupAt: new Date().toISOString(),
    },
  });

  // Trigger Drive Upload (New or Overwrite with explicit confirmation)
  const handleBackupToDriveRequest = (existingFile?: DriveBackupFile) => {
    if (!accessToken) return;

    if (existingFile) {
      setConfirmDialog({
        title: 'Xác nhận ghi đè tệp sao lưu trên Google Drive?',
        description: `Bạn sắp cập nhật và ghi đè nội dung tệp "${existingFile.name}" trên Google Drive bằng dữ liệu hiện tại (${tasks.length} lịch trình, ${goals.length} mục tiêu, ${memories.length} quy tắc AI).`,
        confirmLabel: 'Xác nhận ghi đè',
        onConfirm: async () => {
          setIsLoadingDrive(true);
          setDriveErrorMsg(null);
          try {
            const uploaded = await uploadBackupToDrive(
              accessToken,
              buildBackupPayload(),
              existingFile.id
            );
            const nowStr = new Date().toLocaleString('vi-VN');
            onRecordDriveBackupTime(nowStr);
            setDriveStatusMsg(`Đã cập nhật bản sao lưu "${uploaded.name}" trên Google Drive.`);
            await fetchDriveFileList(accessToken);
          } catch (err: unknown) {
            setDriveErrorMsg(err instanceof Error ? err.message : 'Lỗi khi cập nhật Google Drive.');
          } finally {
            setIsLoadingDrive(false);
          }
        },
      });
    } else {
      setConfirmDialog({
        title: 'Tạo bản sao lưu mới trên Google Drive?',
        description: `Ứng dụng sẽ tạo một tệp sao lưu JSON mới trên Google Drive cá nhân của bạn chứa ${tasks.length} công việc, ${goals.length} mục tiêu và ${memories.length} bộ nhớ quy tắc Gemini.`,
        confirmLabel: 'Tạo bản sao lưu',
        onConfirm: async () => {
          setIsLoadingDrive(true);
          setDriveErrorMsg(null);
          try {
            const uploaded = await uploadBackupToDrive(accessToken, buildBackupPayload());
            const nowStr = new Date().toLocaleString('vi-VN');
            onRecordDriveBackupTime(nowStr);
            setDriveStatusMsg(`Đã sao lưu thành công tệp "${uploaded.name}" lên Google Drive!`);
            await fetchDriveFileList(accessToken);
          } catch (err: unknown) {
            setDriveErrorMsg(err instanceof Error ? err.message : 'Sao lưu Google Drive thất bại.');
          } finally {
            setIsLoadingDrive(false);
          }
        },
      });
    }
  };

  const handleRestoreFromDriveRequest = (file: DriveBackupFile) => {
    if (!accessToken) return;
    setConfirmDialog({
      title: 'Khôi phục dữ liệu từ bản sao lưu Google Drive?',
      description: `Dữ liệu lịch trình, mục tiêu và bộ nhớ AI hiện tại sẽ được cập nhật từ tệp "${file.name}". Bạn có chắc chắn muốn tiếp tục?`,
      confirmLabel: 'Xác nhận khôi phục',
      onConfirm: async () => {
        setIsLoadingDrive(true);
        setDriveErrorMsg(null);
        try {
          const payload = await downloadBackupFromDrive(accessToken, file.id);
          await onRestoreBackupData(payload);
          setDriveStatusMsg(`Đã khôi phục dữ liệu thành công từ "${file.name}"!`);
        } catch (err: unknown) {
          setDriveErrorMsg(err instanceof Error ? err.message : 'Khôi phục dữ liệu thất bại.');
        } finally {
          setIsLoadingDrive(false);
        }
      },
    });
  };

  const handleDeleteDriveFileRequest = (file: DriveBackupFile) => {
    if (!accessToken) return;
    setConfirmDialog({
      title: 'Xóa tệp sao lưu khỏi Google Drive?',
      description: `Bạn có chắc chắn muốn xóa vĩnh viễn tệp "${file.name}" khỏi Google Drive của mình? Hành động này không thể hoàn tác.`,
      confirmLabel: 'Xóa tệp sao lưu',
      onConfirm: async () => {
        setIsLoadingDrive(true);
        setDriveErrorMsg(null);
        try {
          await deleteBackupFromDrive(accessToken, file.id);
          setDriveStatusMsg(`Đã xóa tệp "${file.name}" khỏi Google Drive.`);
          await fetchDriveFileList(accessToken);
        } catch (err: unknown) {
          setDriveErrorMsg(err instanceof Error ? err.message : 'Không thể xóa tệp trên Google Drive.');
        } finally {
          setIsLoadingDrive(false);
        }
      },
    });
  };

  const [copiedUrl, setCopiedUrl] = useState(false);
  const sharedAppUrl = 'https://ais-pre-xin6pjlwh7p3kub7b6qw2g-16945603543.asia-southeast1.run.app';

  const handleCopyAppUrl = () => {
    navigator.clipboard.writeText(sharedAppUrl);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 3000);
  };

  // Export Android APK Capacitor/TWA Builder Bundle
  const handleDownloadAndroidApkBundle = () => {
    const bundleContent = {
      appId: 'vn.chronoflow.personal.apk',
      appName: 'ChronoFlow',
      webDir: 'dist',
      server: {
        url: sharedAppUrl,
        cleartext: false,
      },
      android: {
        allowMixedContent: false,
        captureInput: true,
        webContentsDebuggingEnabled: false,
        backgroundColor: '#0B0F17',
      },
      instructions_vi: [
        'CÁCH 1 (Cài trực tiếp trên điện thoại Android): Mở link ' + sharedAppUrl + ' bằng trình duyệt Chrome trên điện thoại Android -> Nhấn Menu 3 chấm góc phải -> Chọn "Cài đặt ứng dụng" (Install App / Add to Home screen). Máy sẽ tự động cài đặt thành ứng dụng WebAPK độc lập.',
        'CÁCH 2 (Xuất file .apk độc lập qua PWABuilder): Mở https://www.pwabuilder.com , dán link ' + sharedAppUrl + ' -> Nhấn Start -> Chọn Package for stores -> Android -> Download APK.',
      ],
    };

    const blob = new Blob([JSON.stringify(bundleContent, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'chronoflow-android-apk-config.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  // Export iCalendar (.ics) for Android Calendar / Google Calendar
  const handleExportICS = () => {
    const lines = [
      'BEGIN:VCALENDAR',
      'VERSION:2.0',
      'PRODID:-//ChronoFlow//Schedule Export//VI',
      'CALSCALE:GREGORIAN',
      'METHOD:PUBLISH',
    ];

    tasks.forEach((t) => {
      const dateCompact = t.date.replace(/-/g, '');
      const startCompact = t.startTime.replace(':', '') + '00';
      const endCompact = t.endTime.replace(':', '') + '00';
      lines.push(
        'BEGIN:VEVENT',
        `UID:${t.id}@chronoflow.app`,
        `DTSTART:${dateCompact}T${startCompact}`,
        `DTEND:${dateCompact}T${endCompact}`,
        `SUMMARY:${t.title}`,
        `DESCRIPTION:${(t.notes || '').replace(/\n/g, ' ')}`,
        'END:VEVENT'
      );
    });

    lines.push('END:VCALENDAR');
    const blob = new Blob([lines.join('\r\n')], { type: 'text/calendar;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ChronoFlow_LichTrinh_${today}.ics`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Export Excel (.csv)
  const handleExportCSV = () => {
    const header = ['Ngày', 'Bắt đầu', 'Kết thúc', 'Công việc / Bài học', 'Hạng mục', 'Trạng thái', 'Ghi chú'];
    const rows = tasks
      .slice()
      .sort((a, b) => (a.date !== b.date ? a.date.localeCompare(b.date) : a.startTime.localeCompare(b.startTime)))
      .map((t) => [
        t.date,
        t.startTime,
        t.endTime,
        `"${t.title.replace(/"/g, '""')}"`,
        t.category,
        t.completed ? 'Đã xong' : 'Chưa xong',
        `"${(t.notes || '').replace(/"/g, '""')}"`,
      ]);
    const csvContent = '\uFEFF' + [header.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ChronoFlow_LichTrinh_${today}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Export local JSON backup
  const handleExportLocalJson = () => {
    const payload = buildBackupPayload();
    const blob = new Blob([JSON.stringify(payload, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ChronoFlow_Backup_${today}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const renderWidgetPreview = (size: WidgetSize) => {
    if (size === '2x2') {
      return (
        <div className="w-full max-w-[240px] mx-auto aspect-square rounded-3xl bg-slate-900 text-white p-4 border border-slate-700/80 shadow-xl flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-300">Streak Hôm Nay</span>
            <span className="inline-flex items-center gap-1 font-mono tabular-nums text-xs font-bold text-amber-400">
              <Flame className="w-4 h-4" />
              {maxStreak}d
            </span>
          </div>

          <div className="space-y-1.5 my-2">
            {minDailyToday.slice(0, 2).map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => onToggleTask(t.id)}
                className="w-full flex items-center gap-2 text-left text-xs py-1 px-2 rounded-xl bg-slate-800/90 hover:bg-slate-800"
              >
                {t.completed ? (
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                ) : (
                  <Circle className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                )}
                <span className={`truncate ${t.completed ? 'line-through text-slate-500' : 'text-slate-100'}`}>
                  {t.title}
                </span>
              </button>
            ))}
          </div>

          <div className="text-[11px] font-mono tabular-nums text-slate-400 flex items-center justify-between pt-1 border-t border-slate-800">
            <span>Việc tối thiểu</span>
            <span className="text-emerald-400 font-bold">
              {minDailyToday.filter((t) => t.completed).length}/{minDailyToday.length}
            </span>
          </div>
        </div>
      );
    }

    if (size === '4x2') {
      return (
        <div className="w-full max-w-md mx-auto rounded-3xl bg-slate-900 text-white p-4 border border-slate-700/80 shadow-xl space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-xs font-bold text-indigo-400">ChronoFlow · Lịch hôm nay</span>
              <p className="text-xs text-slate-400 font-mono tabular-nums">
                {today} · Hoàn thành {todayTasks.filter((t) => t.completed).length}/{todayTasks.length}
              </p>
            </div>
            <span className="inline-flex items-center gap-1 font-mono tabular-nums text-xs font-bold text-amber-400">
              <Flame className="w-4 h-4" />
              Chuỗi {maxStreak} ngày
            </span>
          </div>

          <div className="space-y-2">
            {todayTasks.slice(0, 3).map((t) => (
              <div
                key={t.id}
                className="flex items-center justify-between gap-2 p-2.5 rounded-2xl bg-slate-800/80"
              >
                <button
                  type="button"
                  onClick={() => onToggleTask(t.id)}
                  className="flex items-center gap-2.5 text-left min-w-0 flex-1"
                >
                  {t.completed ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  ) : (
                    <Circle className="w-4 h-4 text-slate-400 shrink-0" />
                  )}
                  <div className="min-w-0">
                    <span className="block text-[11px] font-mono tabular-nums text-indigo-400">
                      {t.startTime} - {t.endTime}
                    </span>
                    <span className={`block text-xs font-semibold truncate ${t.completed ? 'line-through text-slate-500' : 'text-white'}`}>
                      {t.title}
                    </span>
                  </div>
                </button>
                {!t.completed && (
                  <button
                    type="button"
                    onClick={() => onReportIncident(t)}
                    className="px-2.5 py-1 rounded-xl bg-amber-500/20 text-amber-300 text-[11px] font-semibold shrink-0 flex items-center gap-1"
                  >
                    <AlertTriangle className="w-3 h-3" />
                    Báo trễ
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      );
    }

    // 4x4 Full Android Widget
    return (
      <div className="w-full max-w-lg mx-auto rounded-3xl bg-slate-900 text-white p-5 border border-slate-700/80 shadow-xl space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div>
            <h4 className="text-sm font-bold text-white">ChronoFlow Command Widget (4x4)</h4>
            <p className="text-xs text-slate-400 font-mono tabular-nums">
              Ngày {today} · {memories.filter((m) => m.isActive).length} quy tắc AI đang bật
            </p>
          </div>
          <div className="text-right">
            <span className="inline-flex items-center gap-1 font-mono tabular-nums text-sm font-bold text-amber-400">
              <Flame className="w-4 h-4" />
              {maxStreak} ngày
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div className="space-y-2">
            <span className="text-xs font-semibold text-slate-400 block">
              Công việc trong ngày ({todayTasks.filter((t) => t.completed).length}/{todayTasks.length})
            </span>
            {todayTasks.slice(0, 4).map((t) => (
              <div
                key={t.id}
                className="p-2.5 rounded-2xl bg-slate-800/80 flex items-center justify-between gap-2"
              >
                <button
                  type="button"
                  onClick={() => onToggleTask(t.id)}
                  className="flex items-center gap-2 text-left min-w-0 flex-1"
                >
                  {t.completed ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  ) : (
                    <Circle className="w-4 h-4 text-slate-400 shrink-0" />
                  )}
                  <div className="min-w-0">
                    <span className="block text-[10px] font-mono tabular-nums text-indigo-400">
                      {t.startTime}
                    </span>
                    <span className={`block text-xs font-medium truncate ${t.completed ? 'line-through text-slate-500' : 'text-white'}`}>
                      {t.title}
                    </span>
                  </div>
                </button>
                {!t.completed && (
                  <button
                    type="button"
                    onClick={() => onReportIncident(t)}
                    title="Báo sự cố cho Gemini"
                    className="p-1.5 rounded-lg bg-amber-500/20 text-amber-300 shrink-0"
                  >
                    <AlertTriangle className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            ))}
          </div>

          <div className="space-y-2">
            <span className="text-xs font-semibold text-slate-400 block">
              Tiến độ Mục tiêu ({activeGoals.length})
            </span>
            {activeGoals.slice(0, 3).map((g) => (
              <div key={g.id} className="p-2.5 rounded-2xl bg-slate-800/80 space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-medium text-slate-200 truncate">{g.title}</span>
                  <span className="font-mono tabular-nums text-emerald-400 font-bold">
                    {g.progressPercent}%
                  </span>
                </div>
                <div className="w-full h-1.5 bg-slate-700 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-emerald-400 rounded-full"
                    style={{ width: `${g.progressPercent}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-5">
      {/* TOP SECTION: EXPORT APK & SCHEDULE FILES */}
      <section className="bg-white dark:bg-slate-900 rounded-2xl border-2 border-indigo-500/30 dark:border-indigo-500/40 p-5 space-y-4 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100 dark:border-slate-800">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Download className="w-4 h-4 text-indigo-500" />
              Xuất Ứng Dụng Android APK & Xuất File Lịch Trình
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Cài đặt trực tiếp lên điện thoại Android, đóng gói file <code className="font-mono">.apk</code> độc lập hoặc tải lịch trình về máy
            </p>
          </div>
          {!isInstalled && isInstallable && (
            <button
              type="button"
              onClick={install}
              className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold flex items-center gap-1.5 shrink-0"
            >
              <Smartphone className="w-4 h-4" />
              Cài đặt App ngay
            </button>
          )}
        </div>

        {/* Step-by-step APK Export Box */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700 space-y-2.5">
            <div className="text-xs font-bold text-slate-800 dark:text-slate-100">
              1. Xuất file .APK cài đặt trên điện thoại Android
            </div>
            <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-relaxed">
              • <strong>Cách 1 (WebAPK trực tiếp):</strong> Mở link bên dưới bằng Chrome trên Android → Chọn Menu 3 chấm → <strong>Cài đặt ứng dụng</strong>.<br />
              • <strong>Cách 2 (Tạo file .apk rời):</strong> Sao chép link ứng dụng và dán vào <strong>PWABuilder.com</strong> để tải file <code className="font-mono">.apk</code>.
            </p>
            <div className="flex items-center gap-1.5">
              <input
                type="text"
                readOnly
                value={sharedAppUrl}
                className="flex-1 px-2.5 py-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-[11px] font-mono text-slate-600 dark:text-slate-300"
              />
              <button
                type="button"
                onClick={handleCopyAppUrl}
                className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold shrink-0"
              >
                {copiedUrl ? 'Đã chép link!' : 'Chép link'}
              </button>
            </div>
            <div className="flex flex-wrap items-center gap-2 pt-1">
              <a
                href={`https://www.pwabuilder.com/reportcard?site=${encodeURIComponent(sharedAppUrl)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold inline-flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                Mở PWABuilder tải file .APK
              </a>
              <button
                type="button"
                onClick={handleDownloadAndroidApkBundle}
                className="px-3 py-1.5 rounded-lg bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 text-slate-800 dark:text-slate-100 text-xs font-semibold inline-flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                Tải cấu hình APK (.json)
              </button>
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700 flex flex-col justify-between space-y-2.5">
            <div>
              <div className="text-xs font-bold text-slate-800 dark:text-slate-100">
                2. Xuất dữ liệu Lịch trình & Mục tiêu ra file
              </div>
              <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-relaxed mt-1">
                Tải toàn bộ lịch học, mục tiêu và thói quen của bạn dưới dạng Lịch điện thoại (<code className="font-mono">.ics</code>), bảng tính Excel (<code className="font-mono">.csv</code>) hoặc bản sao lưu đầy đủ (<code className="font-mono">.json</code>).
              </p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1">
              <button
                type="button"
                onClick={handleExportICS}
                className="px-3 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold flex items-center justify-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                Xuất Lịch (.ics)
              </button>
              <button
                type="button"
                onClick={handleExportCSV}
                className="px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold flex items-center justify-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                Xuất Excel (.csv)
              </button>
              <button
                type="button"
                onClick={handleExportLocalJson}
                className="px-3 py-2 rounded-xl bg-slate-800 dark:bg-slate-700 hover:bg-slate-700 text-white text-xs font-semibold flex items-center justify-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                Sao lưu (.json)
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Section 1: Android Home Screen Widget Preview & Launcher Mode */}
      <section className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
              <Smartphone className="w-4 h-4 text-indigo-500" />
              Widget Tiện ích Màn hình chính Android (2x2, 4x2, 4x4)
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Tương tác trực tiếp trên Widget để đánh dấu xong việc tối thiểu hoặc báo sự cố nhanh cho Gemini
            </p>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl">
              {(['2x2', '4x2', '4x4'] as WidgetSize[]).map((sz) => (
                <button
                  key={sz}
                  type="button"
                  onClick={() => onChangeWidgetSize(sz)}
                  className={`min-h-[36px] px-3 py-1 rounded-lg text-xs font-mono font-bold transition-colors ${
                    pinnedWidgetSize === sz
                      ? 'bg-indigo-600 text-white'
                      : 'text-slate-600 dark:text-slate-400'
                  }`}
                >
                  {sz}
                </button>
              ))}
            </div>

            <button
              type="button"
              onClick={() => setIsLauncherMode(true)}
              className="min-h-[40px] px-3.5 py-1.5 rounded-xl bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap shrink-0"
            >
              <Maximize2 className="w-3.5 h-3.5" />
              Ghim toàn màn hình
            </button>
          </div>
        </div>

        <div className="p-6 rounded-2xl bg-gradient-to-br from-slate-950 via-slate-900 to-indigo-950 border border-slate-800">
          {renderWidgetPreview(pinnedWidgetSize)}
        </div>
      </section>

      {/* Section 2: Multi-Device Account Sync (Firebase) & Google Drive Cloud Backup */}
      <section className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100 dark:border-slate-800">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
              <Cloud className="w-4 h-4 text-emerald-500" />
              Đồng bộ Đa thiết bị (Firebase) & Sao lưu Đám mây (Google Drive)
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Đăng nhập tài khoản cá nhân để đồng bộ tức thời giữa nhiều thiết bị và lưu trữ bản sao lưu an toàn trên Google Drive
            </p>
          </div>

          {user ? (
            <div className="flex items-center gap-3">
              <div className="text-right">
                <p className="text-xs font-bold text-slate-900 dark:text-slate-100">
                  {user.displayName || user.email}
                </p>
                <p className="text-[11px] text-emerald-600 dark:text-emerald-400">
                  Đã kết nối Firebase Cloud
                </p>
              </div>
              <button
                type="button"
                onClick={onGoogleLogout}
                className="min-h-[40px] px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-1.5"
              >
                <LogOut className="w-3.5 h-3.5" />
                Đăng xuất
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={onGoogleLogin}
              className="gsi-material-button min-h-[44px] px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs font-semibold flex items-center gap-2.5 shadow-xs hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors"
            >
              <svg className="w-4 h-4 shrink-0" viewBox="0 0 48 48">
                <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z" />
                <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z" />
                <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z" />
                <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z" />
              </svg>
              <span>Sign in with Google (Đồng bộ & Sao lưu Drive)</span>
            </button>
          )}
        </div>

        {/* Google Drive Backup Controls */}
        <div className="space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="text-xs text-slate-600 dark:text-slate-300">
              <span className="font-semibold flex items-center gap-1.5">
                <HardDrive className="w-4 h-4 text-indigo-500" />
                Sao lưu đám mây Google Drive:
              </span>
              <span className="text-slate-500 dark:text-slate-400">
                Lần sao lưu gần nhất: {lastDriveBackupAt || 'Chưa có bản sao lưu'}
              </span>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {accessToken ? (
                <>
                  <button
                    type="button"
                    disabled={isLoadingDrive}
                    onClick={() => handleBackupToDriveRequest()}
                    className="min-h-[40px] px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs font-semibold flex items-center gap-1.5"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    Sao lưu mới lên Google Drive
                  </button>
                  <button
                    type="button"
                    disabled={isLoadingDrive}
                    onClick={() => fetchDriveFileList(accessToken)}
                    className="min-h-[40px] px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-medium text-slate-600 dark:text-slate-300 flex items-center gap-1"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isLoadingDrive ? 'animate-spin' : ''}`} />
                    Làm mới
                  </button>
                </>
              ) : (
                <button
                  type="button"
                  onClick={onGoogleLogin}
                  className="min-h-[40px] px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold"
                >
                  Kết nối quyền truy cập Google Drive
                </button>
              )}

              <button
                type="button"
                onClick={handleExportLocalJson}
                className="min-h-[40px] px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-medium text-slate-700 dark:text-slate-300 flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                Tải file JSON về máy
              </button>
            </div>
          </div>

          {driveStatusMsg && (
            <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-xs text-emerald-700 dark:text-emerald-300">
              {driveStatusMsg}
            </div>
          )}

          {driveErrorMsg && (
            <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-xs text-rose-600 dark:text-rose-400">
              {driveErrorMsg}
            </div>
          )}

          {accessToken && driveFiles.length > 0 && (
            <div className="space-y-2 pt-2">
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200 block">
                Các tệp sao lưu ChronoFlow trên Google Drive của bạn:
              </span>
              {driveFiles.map((file) => (
                <div
                  key={file.id}
                  className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                >
                  <div>
                    <p className="text-xs font-semibold text-slate-900 dark:text-slate-100">
                      {file.name}
                    </p>
                    <p className="text-[11px] font-mono tabular-nums text-slate-500">
                      Cập nhật: {new Date(file.modifiedTime).toLocaleString('vi-VN')}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => handleBackupToDriveRequest(file)}
                      className="min-h-[36px] px-3 py-1 rounded-lg bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 text-xs font-semibold"
                    >
                      Ghi đè bản mới
                    </button>
                    <button
                      type="button"
                      onClick={() => handleRestoreFromDriveRequest(file)}
                      className="min-h-[36px] px-3 py-1 rounded-lg bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 text-xs font-semibold"
                    >
                      Khôi phục
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDeleteDriveFileRequest(file)}
                      className="min-h-[36px] p-1.5 rounded-lg text-rose-500 hover:bg-rose-500/10"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Section 3: Push Notifications & Android APK Packaging Hub */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <section className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 space-y-3">
          <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <Bell className="w-4 h-4 text-amber-500" />
            Thông báo Đẩy (Push Notification) & Nhắc việc
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Tự động gửi thông báo đẩy trên điện thoại Android kèm âm thanh nhắc nhở trước giờ bắt đầu công việc quan trọng.
          </p>
          <div className="flex items-center justify-between pt-2">
            <button
              type="button"
              onClick={onToggleNotifications}
              className={`min-h-[42px] px-4 py-2 rounded-xl text-xs font-semibold transition-colors ${
                notificationsEnabled
                  ? 'bg-emerald-600 text-white'
                  : 'bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
              }`}
            >
              {notificationsEnabled ? 'Đang bật Thông báo đẩy' : 'Kích hoạt Thông báo đẩy'}
            </button>
            <button
              type="button"
              onClick={onTestPushNotification}
              className="min-h-[42px] px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              Gửi thông báo thử
            </button>
          </div>
        </section>

        <section className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 space-y-3">
          <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <Smartphone className="w-4 h-4 text-indigo-500" />
            Cài đặt & Xuất gói Android APK Cá nhân
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Cài đặt trực tiếp lên màn hình chính Android (chế độ WebAPK độc lập không thanh trình duyệt) hoặc tải cấu hình đóng gói file <code className="font-mono">.apk</code>.
          </p>
          <div className="flex flex-wrap items-center gap-2 pt-2">
            {!isInstalled && isInstallable && (
              <button
                type="button"
                onClick={install}
                className="min-h-[42px] px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                Cài đặt App lên Android ngay
              </button>
            )}
            <button
              type="button"
              onClick={handleDownloadAndroidApkBundle}
              className="min-h-[42px] px-4 py-2 rounded-xl bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 text-xs font-semibold flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              Tải cấu hình đóng gói APK
            </button>
          </div>
        </section>
      </div>

      {/* Fullscreen Launcher Widget Mode Modal */}
      {isLauncherMode && (
        <div className="fixed inset-0 z-50 bg-slate-950 text-white p-6 flex flex-col justify-between overflow-y-auto">
          <div className="flex items-center justify-between max-w-lg mx-auto w-full">
            <span className="text-xs font-mono text-slate-400">
              Chế độ Màn hình chính Android · {today}
            </span>
            <button
              type="button"
              onClick={() => setIsLauncherMode(false)}
              className="min-h-[40px] px-3.5 py-1.5 rounded-xl bg-slate-800 text-xs font-semibold flex items-center gap-1.5"
            >
              <Minimize2 className="w-3.5 h-3.5" />
              Thoát chế độ Ghim
            </button>
          </div>

          <div className="my-auto py-6 w-full">
            {renderWidgetPreview(pinnedWidgetSize)}
          </div>

          <div className="text-center text-xs text-slate-500 max-w-md mx-auto">
            Chạm vào từng nhiệm vụ trên Widget để hoàn thành hoặc nhấn biểu tượng cảnh báo để báo Gemini điều chỉnh lịch.
          </div>
        </div>
      )}

      {/* Mandatory Confirmation Modal for Google Drive Mutations */}
      {confirmDialog && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-5 space-y-4 shadow-2xl">
            <h4 className="text-base font-bold text-slate-900 dark:text-slate-100">
              {confirmDialog.title}
            </h4>
            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              {confirmDialog.description}
            </p>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setConfirmDialog(null)}
                className="min-h-[42px] px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                Hủy
              </button>
              <button
                type="button"
                onClick={async () => {
                  const action = confirmDialog.onConfirm;
                  setConfirmDialog(null);
                  await action();
                }}
                className="min-h-[42px] px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold"
              >
                {confirmDialog.confirmLabel}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
