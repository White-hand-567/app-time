/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  Calendar,
  Target,
  Sparkles,
  BarChart3,
  Smartphone,
  Moon,
  Sun,
  Bell,
  Download,
} from 'lucide-react';
import { User } from 'firebase/auth';
import {
  collection,
  doc,
  onSnapshot,
  query,
  where,
  setDoc,
  updateDoc,
  deleteDoc,
  serverTimestamp,
} from 'firebase/firestore';
import {
  db,
  initAuth,
  googleSignIn,
  logout,
  handleFirestoreError,
  OperationType,
} from './firebase';
import {
  ScheduleTask,
  ScheduleViewMode,
  GoalItem,
  AIMemoryItem,
  AIMemoryCategory,
  LockedFixedBlock,
  DailyMinimumHabit,
  WidgetSize,
  ProposedTaskDraft,
  AIGoalDailyStep,
  AIRescheduleResponse,
  AIFeedbackAdjustResponse,
  SchoolPortalSyncConfig,
  AISchoolWebSyncResponse,
  formatDaysOfWeekBadge,
  getWeekdayFromDateStr,
  getTodayStr,
  addDaysStr,
  getDefaultTasks,
  getDefaultGoals,
  getDefaultMemories,
  getDefaultLockedBlocks,
  getDefaultDailyHabits,
  getDefaultSchoolSyncConfig,
} from './types';
import { ScheduleView } from './components/ScheduleView';
import { GoalsStreakView } from './components/GoalsStreakView';
import { AISchedulerView } from './components/AISchedulerView';
import { AnalyticsView } from './components/AnalyticsView';
import { WidgetCloudApkView } from './components/WidgetCloudApkView';
import { ChronoFlowBackupPayload } from './services/driveService';
import { usePWAInstall } from './hooks/usePWAInstall';

type NavTab = 'schedule' | 'goals' | 'ai' | 'analytics' | 'widget_cloud';

const STORAGE_KEYS = {
  TASKS: 'chronoflow_tasks_v6',
  GOALS: 'chronoflow_goals_v6',
  MEMORIES: 'chronoflow_memories_v6',
  LOCKED_BLOCKS: 'chronoflow_locked_blocks_v6',
  DAILY_HABITS: 'chronoflow_daily_habits_v6',
  SCHOOL_SYNC: 'chronoflow_school_sync_v6',
  THEME: 'chronoflow_theme_v1',
  WIDGET: 'chronoflow_widget_v1',
  NOTIF: 'chronoflow_notif_v1',
  DRIVE_BACKUP: 'chronoflow_drive_backup_v1',
};

function toMins(t: string): number {
  const [h, m] = t.split(':').map(Number);
  return (h || 0) * 60 + (m || 0);
}

function toTimeStr(mins: number): string {
  const clamped = Math.max(0, Math.min(1439, Math.round(mins)));
  return `${String(Math.floor(clamped / 60)).padStart(2, '0')}:${String(clamped % 60).padStart(2, '0')}`;
}

/**
 * Tự động xếp các ca học của Lộ trình Mục tiêu vào các khoảng trống ngoài:
 * 1. "Việc chết" (LockedFixedBlock)
 * 2. "Việc hàng ngày" (DailyMinimumHabit)
 * 3. "Đệm sinh hoạt & việc lặt vặt linh hoạt" (11:15-13:00 cho đi học về/ăn trưa, 18:05-19:15 cho ăn tối/tắm rửa, và 15 phút đệm chuyển tiếp giữa các ca)
 */
function packGoalTasksAroundLockedAndHabits(
  dateStr: string,
  dayGoalTasks: ScheduleTask[],
  lockedBlocks: LockedFixedBlock[],
  dailyHabits: DailyMinimumHabit[]
): ScheduleTask[] {
  if (dayGoalTasks.length === 0) return [];

  const wd = getWeekdayFromDateStr(dateStr);
  const busyIntervals: { start: number; end: number }[] = [
    ...lockedBlocks
      .filter((b) => b.daysOfWeek.includes(wd))
      .map((b) => ({ start: toMins(b.startTime), end: toMins(b.endTime) })),
    ...dailyHabits.map((h) => ({ start: toMins(h.startTime), end: toMins(h.endTime) })),
    // Automatic flexible buffers for meals, commute & micro-chores so user doesn't have to report them
    { start: toMins('11:15'), end: toMins('13:00') },
    { start: toMins('18:05'), end: toMins('19:15') },
  ].sort((a, b) => a.start - b.start);

  const mergedBusy: { start: number; end: number }[] = [];
  for (const iv of busyIntervals) {
    if (mergedBusy.length === 0) {
      mergedBusy.push({ ...iv });
    } else {
      const last = mergedBusy[mergedBusy.length - 1];
      if (iv.start <= last.end) {
        last.end = Math.max(last.end, iv.end);
      } else {
        mergedBusy.push({ ...iv });
      }
    }
  }

  let cursor = 8 * 60 + 15; // Start at 08:15 (leaves morning wake-up/washing/breakfast buffer automatically)
  const sorted = [...dayGoalTasks].sort((a, b) => a.startTime.localeCompare(b.startTime));

  return sorted.map((task) => {
    const duration = Math.max(30, toMins(task.endTime) - toMins(task.startTime));

    let placed = false;
    while (!placed) {
      const conflict = mergedBusy.find((b) => cursor < b.end && cursor + duration > b.start);
      if (conflict) {
        cursor = conflict.end;
      } else {
        placed = true;
      }
    }

    const startStr = toTimeStr(cursor);
    const endStr = toTimeStr(cursor + duration);
    // Add 15-minute flexible micro-chore cushion between consecutive sessions
    cursor += duration + 15;

    return {
      ...task,
      startTime: startStr,
      endTime: endStr,
    };
  });
}

export default function App() {
  const [activeTab, setActiveTab] = useState<NavTab>('schedule');
  const [selectedDate, setSelectedDate] = useState<string>(getTodayStr());
  const [viewMode, setViewMode] = useState<ScheduleViewMode>('day');

  // Theme state
  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.THEME);
    return saved === 'light' ? 'light' : 'dark';
  });

  // Auth & Cloud Sync states
  const [user, setUser] = useState<User | null>(null);
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [isAuthReady, setIsAuthReady] = useState(false);

  // Core data stores
  const [tasks, setTasks] = useState<ScheduleTask[]>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.TASKS);
      return raw ? JSON.parse(raw) : getDefaultTasks();
    } catch {
      return getDefaultTasks();
    }
  });

  const [goals, setGoals] = useState<GoalItem[]>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.GOALS);
      return raw ? JSON.parse(raw) : getDefaultGoals();
    } catch {
      return getDefaultGoals();
    }
  });

  const [memories, setMemories] = useState<AIMemoryItem[]>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.MEMORIES);
      return raw ? JSON.parse(raw) : getDefaultMemories();
    } catch {
      return getDefaultMemories();
    }
  });

  // VIỆC 3: VIỆC CHẾT (Khóa chết thời khóa biểu lặp lại qua tuần sau & tháng sau)
  const [lockedBlocks, setLockedBlocks] = useState<LockedFixedBlock[]>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.LOCKED_BLOCKS);
      return raw ? JSON.parse(raw) : getDefaultLockedBlocks();
    } catch {
      return getDefaultLockedBlocks();
    }
  });

  // VIỆC 2: VIỆC HÀNG NGÀY / TỐI THIỂU (Chỉ Thêm hoặc Xóa)
  const [dailyHabits, setDailyHabits] = useState<DailyMinimumHabit[]>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.DAILY_HABITS);
      return raw ? JSON.parse(raw) : getDefaultDailyHabits();
    } catch {
      return getDefaultDailyHabits();
    }
  });

  // CẤU HÌNH AI TỰ TRUY CẬP WEB TRƯỜNG ĐỂ TỰ CẬP NHẬT VIỆC CHẾT KHI ĐỔI THỜI KHÓA BIỂU
  const [schoolSyncConfig, setSchoolSyncConfig] = useState<SchoolPortalSyncConfig>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.SCHOOL_SYNC);
      return raw ? JSON.parse(raw) : getDefaultSchoolSyncConfig();
    } catch {
      return getDefaultSchoolSyncConfig();
    }
  });

  const [pinnedWidgetSize, setPinnedWidgetSize] = useState<WidgetSize>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.WIDGET);
    return saved === '2x2' || saved === '4x2' || saved === '4x4' ? saved : '4x2';
  });

  const [notificationsEnabled, setNotificationsEnabled] = useState<boolean>(() => {
    return localStorage.getItem(STORAGE_KEYS.NOTIF) !== 'false';
  });

  const [lastDriveBackupAt, setLastDriveBackupAt] = useState<string>(() => {
    return localStorage.getItem(STORAGE_KEYS.DRIVE_BACKUP) || '';
  });

  const [preselectedIncidentTask, setPreselectedIncidentTask] = useState<ScheduleTask | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const { isInstallable, isInstalled, install } = usePWAInstall();
  const notifiedTasksRef = useRef<Set<string>>(new Set());

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 3500);
  };

  // Sync Dark / Light class on <html>
  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    localStorage.setItem(STORAGE_KEYS.THEME, theme);
  }, [theme]);

  // Persist to localStorage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.TASKS, JSON.stringify(tasks));
  }, [tasks]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.GOALS, JSON.stringify(goals));
  }, [goals]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.MEMORIES, JSON.stringify(memories));
  }, [memories]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.LOCKED_BLOCKS, JSON.stringify(lockedBlocks));
  }, [lockedBlocks]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.DAILY_HABITS, JSON.stringify(dailyHabits));
  }, [dailyHabits]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SCHOOL_SYNC, JSON.stringify(schoolSyncConfig));
  }, [schoolSyncConfig]);

  // Initialize Firebase Authentication
  useEffect(() => {
    const unsub = initAuth((authUser, token) => {
      setUser(authUser);
      if (token) setAccessToken(token);
      setIsAuthReady(true);
    });
    return () => unsub();
  }, []);

  // Attach Firestore Real-Time Listeners when authenticated
  useEffect(() => {
    if (!isAuthReady || !user) return;

    const uid = user.uid;

    const tasksQuery = query(collection(db, 'tasks'), where('userId', '==', uid));
    const unsubTasks = onSnapshot(
      tasksQuery,
      (snap) => {
        if (!snap.empty) {
          const loaded: ScheduleTask[] = snap.docs.map((d) => d.data() as ScheduleTask);
          setTasks(loaded);
        }
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'tasks')
    );

    const goalsQuery = query(collection(db, 'goals'), where('userId', '==', uid));
    const unsubGoals = onSnapshot(
      goalsQuery,
      (snap) => {
        if (!snap.empty) {
          const loaded: GoalItem[] = snap.docs.map((d) => d.data() as GoalItem);
          setGoals(loaded);
        }
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'goals')
    );

    const memoriesQuery = query(collection(db, 'ai_memories'), where('userId', '==', uid));
    const unsubMemories = onSnapshot(
      memoriesQuery,
      (snap) => {
        if (!snap.empty) {
          const loaded: AIMemoryItem[] = snap.docs.map((d) => d.data() as AIMemoryItem);
          setMemories(loaded);
        }
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'ai_memories')
    );

    return () => {
      unsubTasks();
      unsubGoals();
      unsubMemories();
    };
  }, [isAuthReady, user]);

  // Push Notification Reminder Scheduler
  useEffect(() => {
    if (!notificationsEnabled) return;

    const checkReminders = () => {
      const now = new Date();
      const todayStr = getTodayStr();
      const nowMinutes = now.getHours() * 60 + now.getMinutes();

      tasks.forEach((task) => {
        if (task.date !== todayStr || task.completed || !task.reminderEnabled) return;
        const [sh, sm] = task.startTime.split(':').map(Number);
        const startMins = sh * 60 + sm;
        const diff = startMins - nowMinutes;

        const key = `${task.id}_${todayStr}`;
        if (diff >= 0 && diff <= task.reminderMinutesBefore && !notifiedTasksRef.current.has(key)) {
          notifiedTasksRef.current.add(key);
          const msg = `Nhắc việc (${task.startTime}): ${task.title}`;
          showToast(msg);

          if ('Notification' in window && Notification.permission === 'granted') {
            new Notification('ChronoFlow Nhắc Việc Quan Trọng', {
              body: `${task.startTime} - ${task.endTime}: ${task.title}`,
              icon: '/icon.svg',
            });
          }
        }
      });
    };

    const timer = setInterval(checkReminders, 30000);
    return () => clearInterval(timer);
  }, [tasks, notificationsEnabled]);

  const syncTaskToFirestore = async (task: ScheduleTask, isNew: boolean) => {
    if (!user) return;
    const safeId = task.id.replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 128);
    const payload = {
      id: safeId,
      userId: user.uid,
      title: task.title.slice(0, 200),
      notes: (task.notes || '').slice(0, 2000),
      date: task.date.slice(0, 10),
      startTime: task.startTime.slice(0, 5),
      endTime: task.endTime.slice(0, 5),
      category: task.category,
      priority: task.priority,
      completed: Boolean(task.completed),
      isMinimumDaily: Boolean(task.isMinimumDaily),
      currentStreak: Math.max(0, Math.floor(task.currentStreak || 0)),
      bestStreak: Math.max(0, Math.floor(task.bestStreak || 0)),
      lastCompletedDate: (task.lastCompletedDate || '').slice(0, 10),
      reminderEnabled: Boolean(task.reminderEnabled),
      reminderMinutesBefore: Math.max(0, Math.floor(task.reminderMinutesBefore || 10)),
      goalId: (task.goalId || '').slice(0, 128),
      ...(isNew ? { createdAt: serverTimestamp() } : {}),
      updatedAt: serverTimestamp(),
    };

    try {
      if (isNew) {
        await setDoc(doc(db, 'tasks', safeId), payload);
      } else {
        await updateDoc(doc(db, 'tasks', safeId), payload);
      }
    } catch (err) {
      handleFirestoreError(err, isNew ? OperationType.CREATE : OperationType.UPDATE, `tasks/${safeId}`);
    }
  };

  // --- VIỆC 2 HANDLERS: VIỆC HÀNG NGÀY / VIỆC TỐI THIỂU (CHỈ THÊM HOẶC XÓA) ---
  const handleAddDailyHabit = (title: string, startTime: string, endTime: string) => {
    const newHabit: DailyMinimumHabit = {
      id: `habit_${Date.now()}`,
      title: title.slice(0, 150),
      startTime,
      endTime,
      currentStreak: 1,
      bestStreak: 1,
      completedDates: [],
    };
    const nextHabits = [...dailyHabits, newHabit];
    setDailyHabits(nextHabits);
    showToast(`Đã thêm Việc hàng ngày "${newHabit.title}" (~${startTime}–${endTime} mỗi ngày)!`);
  };

  const handleDeleteDailyHabit = (habitId: string) => {
    setDailyHabits((prev) => prev.filter((h) => h.id !== habitId));
    showToast('Đã xóa việc hàng ngày.');
  };

  const handleToggleDailyHabitForDate = (habitId: string, dateStr: string) => {
    setDailyHabits((prev) =>
      prev.map((h) => {
        if (h.id !== habitId) return h;
        const alreadyDone = h.completedDates.includes(dateStr);
        const nextDates = alreadyDone
          ? h.completedDates.filter((d) => d !== dateStr)
          : [...h.completedDates, dateStr];
        const nextStreak = alreadyDone ? Math.max(0, h.currentStreak - 1) : h.currentStreak + 1;
        const nextBest = Math.max(h.bestStreak, nextStreak);
        if (!alreadyDone) {
          showToast(`Tuyệt vời! Chuỗi Streak "${h.title}" đạt ${nextStreak} ngày!`);
        }
        return {
          ...h,
          completedDates: nextDates,
          currentStreak: nextStreak,
          bestStreak: nextBest,
        };
      })
    );
  };

  // --- VIỆC 3 HANDLERS: VIỆC CHẾT / KHÓA CỐ ĐỊNH QUA TUẦN SAU & THÁNG SAU ---
  const handleAddLockedBlock = (
    title: string,
    daysOfWeek: number[],
    startTime: string,
    endTime: string
  ) => {
    const newBlock: LockedFixedBlock = {
      id: `lock_${Date.now()}`,
      title: title.slice(0, 150),
      daysOfWeek,
      startTime,
      endTime,
      source: 'manual',
    };
    const nextBlocks = [...lockedBlocks, newBlock];
    setLockedBlocks(nextBlocks);

    const memSummary = `Việc chết khóa cố định: "${newBlock.title}" (${startTime}–${endTime} vào ${formatDaysOfWeekBadge(daysOfWeek)}). Tự động tiếp diễn qua tuần sau và tháng sau.`;
    handleSaveMemory(memSummary, 'routine');

    showToast(`Đã khóa chết "${newBlock.title}"! Tự động lặp lại qua các tuần và tháng sau.`);
  };

  const handleDeleteLockedBlock = (blockId: string) => {
    setLockedBlocks((prev) => prev.filter((b) => b.id !== blockId));
    showToast('Đã mở khóa / xóa khung giờ việc chết.');
  };

  // --- AI TỰ TRUY CẬP WEB TRƯỜNG CẬP NHẬT THỜI KHÓA BIỂU & TỰ DỜI LỊCH MỤC TIÊU ---
  const handleApplySchoolWebSync = async (
    syncResult: AISchoolWebSyncResponse,
    updatedConfig: SchoolPortalSyncConfig
  ) => {
    setSchoolSyncConfig(updatedConfig);

    // Keep manual extra-class blocks that were not from school_web, and replace school_web blocks with the newly extracted timetable
    const manualBlocks = lockedBlocks.filter((b) => b.source === 'manual');
    const newSchoolBlocks: LockedFixedBlock[] = (syncResult.extractedLockedBlocks || []).map(
      (b, idx) => ({
        id: `lock_school_web_${Date.now()}_${idx}`,
        title: b.title.slice(0, 150),
        daysOfWeek: Array.isArray(b.daysOfWeek)
          ? b.daysOfWeek.filter((d) => d >= 0 && d <= 6)
          : [1, 2, 3, 4, 5],
        startTime: b.startTime || '07:30',
        endTime: b.endTime || '11:15',
        source: 'school_web',
      })
    );

    const nextLockedBlocks =
      newSchoolBlocks.length > 0 ? [...newSchoolBlocks, ...manualBlocks] : lockedBlocks;
    setLockedBlocks(nextLockedBlocks);

    // Automatically re-pack ALL existing Goal Roadmap tasks across all dates around the newly updated school timetable!
    const allDates = Array.from(new Set(tasks.map((t) => t.date)));
    let nextAllTasks = [...tasks];
    for (const dStr of allDates) {
      const dayList = nextAllTasks.filter((t) => t.date === dStr);
      const others = nextAllTasks.filter((t) => t.date !== dStr);
      const repacked = packGoalTasksAroundLockedAndHabits(
        dStr,
        dayList,
        nextLockedBlocks,
        dailyHabits
      );
      nextAllTasks = [...others, ...repacked];
    }
    setTasks(nextAllTasks);

    // Save the updated school timetable summary into AI Memory so future prompts know automatically
    const schoolSummaryRule = `[Đồng bộ tự động từ Web Trường - ${syncResult.schoolNameOrPageTitle}]: ${syncResult.changeSummary}`;
    await handleSaveMemory(schoolSummaryRule, 'routine', 'mem_fixed_school');

    showToast(
      `AI đã tự cập nhật ${newSchoolBlocks.length} khung Thời khóa biểu từ Web Trường và tự dời lịch học Mục tiêu!`
    );
  };

  // Task Handlers
  const handleToggleTask = async (taskId: string) => {
    const target = tasks.find((t) => t.id === taskId);
    if (!target) return;

    const nextCompleted = !target.completed;
    const updated: ScheduleTask = {
      ...target,
      completed: nextCompleted,
    };

    setTasks((prev) => prev.map((t) => (t.id === taskId ? updated : t)));

    if (user) {
      try {
        await updateDoc(doc(db, 'tasks', taskId), {
          completed: updated.completed,
          updatedAt: serverTimestamp(),
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, `tasks/${taskId}`);
      }
    }
  };

  const handleDeleteTask = async (taskId: string) => {
    setTasks((prev) => prev.filter((t) => t.id !== taskId));
    showToast('Đã xóa nhiệm vụ khỏi lịch.');
    if (user) {
      try {
        await deleteDoc(doc(db, 'tasks', taskId));
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, `tasks/${taskId}`);
      }
    }
  };

  const handleReportIncidentFromTask = (task: ScheduleTask) => {
    setPreselectedIncidentTask(task);
    setActiveTab('ai');
  };

  // --- GÓP Ý & DẠY AI TỰ HỌC THÓI QUEN: CẬP NHẬT LỊCH NGÀY THEO Ý KIẾN NGƯỜI DÙNG ---
  const handleApplyFeedbackAdjustedTasks = async (
    targetDate: string,
    updatedDayTasks: AIFeedbackAdjustResponse['updatedDayTasks']
  ) => {
    const otherTasks = tasks.filter((t) => t.date !== targetDate);
    const currentDayTasks = tasks.filter((t) => t.date === targetDate);

    const newDayList: ScheduleTask[] = updatedDayTasks.map((item, idx) => {
      const existing = currentDayTasks.find((t) => t.id === item.taskId);
      if (existing) {
        return {
          ...existing,
          title: item.title.slice(0, 200),
          date: item.date || targetDate,
          startTime: item.startTime,
          endTime: item.endTime,
          notes: item.notes.slice(0, 2000),
        };
      }
      return {
        id: `task_fb_${Date.now()}_${idx}`,
        userId: user?.uid || 'local-user',
        title: item.title.slice(0, 200),
        notes: item.notes.slice(0, 2000),
        date: item.date || targetDate,
        startTime: item.startTime,
        endTime: item.endTime,
        category: 'study',
        priority: 'high',
        completed: false,
        isMinimumDaily: false,
        currentStreak: 0,
        bestStreak: 0,
        lastCompletedDate: '',
        reminderEnabled: true,
        reminderMinutesBefore: 15,
        goalId: goals[0]?.id || '',
      };
    });

    setTasks([...otherTasks, ...newDayList]);
    showToast(
      'AI đã tiếp thu ý kiến, sửa lại lịch trình và lưu thói quen của bạn cho các lần sau!'
    );

    for (const t of newDayList) {
      await syncTaskToFirestore(t, !currentDayTasks.some((old) => old.id === t.id));
    }
  };

  // --- VIỆC 1 HANDLER: LƯU MỤC TIÊU + TỰ PHÂN BỐ LỘ TRÌNH ---
  const handleSaveGoalWithRoadmap = async (
    goalData: Omit<GoalItem, 'id' | 'userId' | 'createdAt' | 'updatedAt'>,
    dailySteps: AIGoalDailyStep[]
  ) => {
    const goalId = `goal_${Date.now()}`;
    const newGoal: GoalItem = {
      ...goalData,
      id: goalId,
      userId: user?.uid || 'local-user',
    };

    const rawCreatedTasks: ScheduleTask[] = dailySteps.map((step, idx) => ({
      id: `task_goal_${Date.now()}_${idx}`,
      userId: user?.uid || 'local-user',
      title: step.title.slice(0, 200),
      notes: `${step.notes} · [${step.freeTimeSummary}]`.slice(0, 2000),
      date: step.date,
      startTime: step.startTime,
      endTime: step.endTime,
      category: 'study',
      priority: 'high',
      completed: false,
      isMinimumDaily: false,
      currentStreak: 0,
      bestStreak: 0,
      lastCompletedDate: '',
      reminderEnabled: true,
      reminderMinutesBefore: 15,
      goalId,
    }));

    const affectedDates = Array.from(new Set(rawCreatedTasks.map((t) => t.date)));
    let nextAllTasks = [...tasks, ...rawCreatedTasks];
    for (const dStr of affectedDates) {
      const dayList = nextAllTasks.filter((t) => t.date === dStr);
      const others = nextAllTasks.filter((t) => t.date !== dStr);
      const packed = packGoalTasksAroundLockedAndHabits(dStr, dayList, lockedBlocks, dailyHabits);
      nextAllTasks = [...others, ...packed];
    }

    setGoals((prev) => [newGoal, ...prev]);
    setTasks(nextAllTasks);
    showToast(
      `Đã tạo mục tiêu "${newGoal.title}" và tự phân bổ ${rawCreatedTasks.length} ca học kèm đệm việc vặt linh hoạt (±20p)!`
    );

    if (user) {
      try {
        await setDoc(doc(db, 'goals', goalId), {
          ...newGoal,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, `goals/${goalId}`);
      }

      for (const t of rawCreatedTasks) {
        await syncTaskToFirestore(t, true);
      }
    }
  };

  const handleIncrementGoalDay = async (goalId: string) => {
    const target = goals.find((g) => g.id === goalId);
    if (!target || target.isAchieved) return;

    const nextDays = Math.min(target.totalTargetDays, target.completedDays + 1);
    const nextPercent = Math.min(100, Math.round((nextDays / target.totalTargetDays) * 100));
    const nowAchieved = nextPercent >= 100;
    const achievedDate = nowAchieved ? getTodayStr() : '';

    const updated: GoalItem = {
      ...target,
      completedDays: nextDays,
      progressPercent: nextPercent,
      isAchieved: nowAchieved,
      achievedDate,
    };

    setGoals((prev) => prev.map((g) => (g.id === goalId ? updated : g)));
    showToast(
      nowAchieved
        ? `Chúc mừng! Bạn đã hoàn thành 100% mục tiêu "${target.title}"!`
        : `Đã điểm danh tiến độ định kỳ (+1 ngày) cho "${target.title}"!`
    );

    if (user) {
      try {
        await updateDoc(doc(db, 'goals', goalId), {
          completedDays: nextDays,
          progressPercent: nextPercent,
          isAchieved: nowAchieved,
          achievedDate,
          updatedAt: serverTimestamp(),
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, `goals/${goalId}`);
      }
    }
  };

  const handleMarkGoalAchieved = async (goalId: string) => {
    const target = goals.find((g) => g.id === goalId);
    if (!target || target.isAchieved) return;

    const todayStr = getTodayStr();
    const updated: GoalItem = {
      ...target,
      completedDays: target.totalTargetDays,
      progressPercent: 100,
      isAchieved: true,
      achievedDate: todayStr,
    };

    setGoals((prev) => prev.map((g) => (g.id === goalId ? updated : g)));
    showToast(`Đã ghi nhận mục tiêu "${target.title}" vào Nhật ký Thành tựu!`);

    if (user) {
      try {
        await updateDoc(doc(db, 'goals', goalId), {
          completedDays: updated.completedDays,
          progressPercent: 100,
          isAchieved: true,
          achievedDate: todayStr,
          updatedAt: serverTimestamp(),
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, `goals/${goalId}`);
      }
    }
  };

  const handleReopenGoal = async (goalId: string) => {
    const target = goals.find((g) => g.id === goalId);
    if (!target) return;

    const nextDays = Math.max(0, target.totalTargetDays - 1);
    const nextPercent = Math.round((nextDays / target.totalTargetDays) * 100);

    const updated: GoalItem = {
      ...target,
      isAchieved: false,
      achievedDate: '',
      completedDays: nextDays,
      progressPercent: nextPercent,
    };

    setGoals((prev) => prev.map((g) => (g.id === goalId ? updated : g)));
    showToast('Đã mở lại mục tiêu để tiếp tục theo dõi.');
  };

  const handleDeleteGoal = async (goalId: string) => {
    setGoals((prev) => prev.filter((g) => g.id !== goalId));
    showToast('Đã xóa mục tiêu.');
    if (user) {
      try {
        await deleteDoc(doc(db, 'goals', goalId));
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, `goals/${goalId}`);
      }
    }
  };

  // Persistent AI Memory Handlers
  const handleSaveMemory = async (
    content: string,
    category: AIMemoryCategory,
    existingId?: string
  ) => {
    const id = existingId || `mem_${Date.now()}`;
    const memObj: AIMemoryItem = {
      id,
      userId: user?.uid || 'local-user',
      content: content.slice(0, 500),
      category,
      isActive: true,
    };

    if (existingId) {
      setMemories((prev) => prev.map((m) => (m.id === existingId ? memObj : m)));
    } else {
      setMemories((prev) => [memObj, ...prev]);
    }
    showToast('AI đã học và lưu thói quen mới của bạn vào Hồ sơ cá nhân!');

    if (user) {
      try {
        await setDoc(doc(db, 'ai_memories', id), {
          ...memObj,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, `ai_memories/${id}`);
      }
    }
  };

  const handleToggleMemory = async (memoryId: string) => {
    const target = memories.find((m) => m.id === memoryId);
    if (!target) return;
    const nextActive = !target.isActive;
    setMemories((prev) =>
      prev.map((m) => (m.id === memoryId ? { ...m, isActive: nextActive } : m))
    );
  };

  const handleDeleteMemory = async (memoryId: string) => {
    setMemories((prev) => prev.filter((m) => m.id !== memoryId));
    showToast('Đã xóa quy tắc khỏi Bộ nhớ AI.');
  };

  const handleApplyProposedTasks = async (drafts: ProposedTaskDraft[]) => {
    const created: ScheduleTask[] = drafts.map((d, idx) => ({
      id: `task_ai_${Date.now()}_${idx}`,
      userId: user?.uid || 'local-user',
      title: d.title.slice(0, 200),
      notes: (d.notes || '').slice(0, 2000),
      date: d.date,
      startTime: d.startTime,
      endTime: d.endTime,
      category: ['study', 'work', 'health', 'personal', 'commute'].includes(d.category)
        ? d.category
        : 'study',
      priority: ['high', 'medium', 'low'].includes(d.priority) ? d.priority : 'medium',
      completed: false,
      isMinimumDaily: false,
      currentStreak: 0,
      bestStreak: 0,
      lastCompletedDate: '',
      reminderEnabled: true,
      reminderMinutesBefore: 15,
      goalId: '',
    }));

    setTasks((prev) => [...prev, ...created]);
    showToast(`Đã áp dụng ${created.length} nhiệm vụ mục tiêu từ Gemini vào lịch trình!`);
    setActiveTab('schedule');

    for (const t of created) {
      await syncTaskToFirestore(t, true);
    }
  };

  const handleApplyRescheduleAdjustments = async (
    adjustments: AIRescheduleResponse['adjustments']
  ) => {
    const updatedTasks = [...tasks];

    for (const adj of adjustments) {
      const existingIndex = updatedTasks.findIndex((t) => t.id === adj.taskId);
      if (existingIndex !== -1 && adj.taskId !== 'NEW') {
        const old = updatedTasks[existingIndex];
        const modified: ScheduleTask = {
          ...old,
          title: adj.title.slice(0, 200),
          date: adj.newDate,
          startTime: adj.newStartTime,
          endTime: adj.newEndTime,
          notes: `${old.notes ? old.notes + ' | ' : ''}[Gemini điều chỉnh]: ${adj.updatedNotes}`.slice(
            0,
            2000
          ),
        };
        updatedTasks[existingIndex] = modified;
        await syncTaskToFirestore(modified, false);
      } else {
        const newSplitTask: ScheduleTask = {
          id: `task_resched_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
          userId: user?.uid || 'local-user',
          title: adj.title.slice(0, 200),
          notes: `[Gemini bù lịch]: ${adj.updatedNotes}`.slice(0, 2000),
          date: adj.newDate,
          startTime: adj.newStartTime,
          endTime: adj.newEndTime,
          category: 'study',
          priority: 'high',
          completed: false,
          isMinimumDaily: false,
          currentStreak: 0,
          bestStreak: 0,
          lastCompletedDate: '',
          reminderEnabled: true,
          reminderMinutesBefore: 15,
          goalId: '',
        };
        updatedTasks.push(newSplitTask);
        await syncTaskToFirestore(newSplitTask, true);
      }
    }

    setTasks(updatedTasks);
    showToast('Đã cập nhật lịch trình điều chỉnh từ Gemini AI!');
    setActiveTab('schedule');
  };

  const handleGoogleLogin = async () => {
    try {
      const result = await googleSignIn();
      setUser(result.user);
      setAccessToken(result.accessToken);
      showToast(`Xin chào ${result.user.displayName || result.user.email}! Đã bật đồng bộ đám mây.`);
    } catch (err) {
      console.error(err);
      showToast('Đăng nhập Google không thành công hoặc đã bị hủy.');
    }
  };

  const handleGoogleLogout = async () => {
    await logout();
    setUser(null);
    setAccessToken(null);
    showToast('Đã đăng xuất tài khoản đám mây.');
  };

  const handleToggleNotifications = async () => {
    if (!notificationsEnabled && 'Notification' in window) {
      await Notification.requestPermission();
    }
    const next = !notificationsEnabled;
    setNotificationsEnabled(next);
    localStorage.setItem(STORAGE_KEYS.NOTIF, String(next));
    showToast(next ? 'Đã bật thông báo đẩy nhắc việc!' : 'Đã tạm tắt thông báo đẩy.');
  };

  const handleTestPushNotification = async () => {
    if ('Notification' in window && Notification.permission !== 'granted') {
      await Notification.requestPermission();
    }
    if ('Notification' in window && Notification.permission === 'granted') {
      new Notification('ChronoFlow Android — Nhắc việc thông minh', {
        body: 'Thông báo đẩy hoạt động tốt! Ứng dụng sẽ nhắc bạn trước các bài học mục tiêu.',
        icon: '/icon.svg',
      });
    }
    showToast('Chuông báo thử: Sẵn sàng nhắc nhở các bài học mục tiêu trong ngày!');
  };

  const handleRestoreBackupData = async (payload: ChronoFlowBackupPayload) => {
    if (Array.isArray(payload.tasks)) setTasks(payload.tasks);
    if (Array.isArray(payload.goals)) setGoals(payload.goals);
    if (Array.isArray(payload.memories)) setMemories(payload.memories);
    showToast('Đã khôi phục toàn bộ lịch trình, mục tiêu và bộ nhớ AI từ đám mây!');
  };

  const handleApplyGanttTemplate = async (
    templateType: 'deep_focus' | 'exam_sprint' | 'weekend_full',
    targetDate: string
  ) => {
    const uid = user?.uid || 'local-user';
    const otherDaysTasks = tasks.filter((t) => t.date !== targetDate);

    let rawTemplateTasks: ScheduleTask[] = [];
    if (templateType === 'deep_focus') {
      rawTemplateTasks = [
        {
          id: `gantt_df_1_${Date.now()}`,
          userId: uid,
          title: 'Ca 1: Học Lý thuyết Bài trọng tâm (Mục tiêu chính)',
          notes:
            'Mẫu Gantt Cân bằng · Đã chừa sẵn đệm 11:15-13:00 (±25p) cho đi học về, ăn trưa & nghỉ ngơi linh hoạt.',
          date: targetDate,
          startTime: '13:00',
          endTime: '14:45',
          category: 'study',
          priority: 'high',
          completed: false,
          isMinimumDaily: false,
          currentStreak: 0,
          bestStreak: 0,
          lastCompletedDate: '',
          reminderEnabled: true,
          reminderMinutesBefore: 15,
          goalId: goals[0]?.id || '',
        },
        {
          id: `gantt_df_2_${Date.now()}`,
          userId: uid,
          title: 'Ca 2: Thực hành Bài tập & Dự án (Linh hoạt ±20p)',
          notes: 'Chừa đệm 15 phút giải lao giữa ca.',
          date: targetDate,
          startTime: '15:00',
          endTime: '16:20',
          category: 'work',
          priority: 'high',
          completed: false,
          isMinimumDaily: false,
          currentStreak: 0,
          bestStreak: 0,
          lastCompletedDate: '',
          reminderEnabled: true,
          reminderMinutesBefore: 10,
          goalId: goals[0]?.id || '',
        },
        {
          id: `gantt_df_3_${Date.now()}`,
          userId: uid,
          title: 'Ca 3 (Khung Vàng Tối): Học Bài tiếp theo & Tổng kết',
          notes:
            'Đã chừa sẵn đệm 18:05-19:15 (±25p) cho ăn tối, tắm rửa & việc lặt vặt không cần báo.',
          date: targetDate,
          startTime: '19:15',
          endTime: '21:30',
          category: 'study',
          priority: 'high',
          completed: false,
          isMinimumDaily: false,
          currentStreak: 0,
          bestStreak: 0,
          lastCompletedDate: '',
          reminderEnabled: true,
          reminderMinutesBefore: 15,
          goalId: goals[0]?.id || '',
        },
      ];
    } else if (templateType === 'exam_sprint') {
      rawTemplateTasks = [
        {
          id: `gantt_es_1_${Date.now()}`,
          userId: uid,
          title: 'Sprint 1: Ôn tập Chuyên đề 1 & Giải đề (Ca chiều)',
          notes: 'Mẫu Gantt Nước rút Ôn thi · Tự động trừ hao đệm ăn trưa linh hoạt.',
          date: targetDate,
          startTime: '13:00',
          endTime: '16:20',
          category: 'study',
          priority: 'high',
          completed: false,
          isMinimumDaily: false,
          currentStreak: 0,
          bestStreak: 0,
          lastCompletedDate: '',
          reminderEnabled: true,
          reminderMinutesBefore: 15,
          goalId: goals[0]?.id || '',
        },
        {
          id: `gantt_es_2_${Date.now()}`,
          userId: uid,
          title: 'Sprint 2 (Tối): Chuyên đề 2 & Hệ thống hóa công thức',
          notes: 'Bắt đầu lúc 19:15 sau khi xong việc cá nhân/ăn tối linh hoạt.',
          date: targetDate,
          startTime: '19:15',
          endTime: '21:45',
          category: 'study',
          priority: 'high',
          completed: false,
          isMinimumDaily: false,
          currentStreak: 0,
          bestStreak: 0,
          lastCompletedDate: '',
          reminderEnabled: true,
          reminderMinutesBefore: 15,
          goalId: goals[0]?.id || '',
        },
      ];
    } else {
      rawTemplateTasks = [
        {
          id: `gantt_wk_1_${Date.now()}`,
          userId: uid,
          title: 'Ca Sáng: Học Bài 1, 2 Lộ trình Mục tiêu (Bắt đầu thong thả 08:15)',
          notes: 'Đã tự động trừ hao thời gian dậy muộn, rửa mặt & ăn sáng linh hoạt.',
          date: targetDate,
          startTime: '08:15',
          endTime: '11:15',
          category: 'study',
          priority: 'high',
          completed: false,
          isMinimumDaily: false,
          currentStreak: 0,
          bestStreak: 0,
          lastCompletedDate: '',
          reminderEnabled: true,
          reminderMinutesBefore: 15,
          goalId: goals[0]?.id || '',
        },
        {
          id: `gantt_wk_2_${Date.now()}`,
          userId: uid,
          title: 'Ca Chiều: Thực hành Dự án & Luyện đề',
          notes: 'Chừa đệm nghỉ trưa thoải mái 11:15 - 13:00.',
          date: targetDate,
          startTime: '13:00',
          endTime: '16:20',
          category: 'work',
          priority: 'high',
          completed: false,
          isMinimumDaily: false,
          currentStreak: 0,
          bestStreak: 0,
          lastCompletedDate: '',
          reminderEnabled: true,
          reminderMinutesBefore: 10,
          goalId: goals[0]?.id || '',
        },
        {
          id: `gantt_wk_3_${Date.now()}`,
          userId: uid,
          title: 'Ca Tối: Học Bài 3 & Tổng ôn',
          notes: 'Khung Vàng buổi tối 19:15 - 21:30.',
          date: targetDate,
          startTime: '19:15',
          endTime: '21:30',
          category: 'study',
          priority: 'high',
          completed: false,
          isMinimumDaily: false,
          currentStreak: 0,
          bestStreak: 0,
          lastCompletedDate: '',
          reminderEnabled: true,
          reminderMinutesBefore: 15,
          goalId: goals[0]?.id || '',
        },
      ];
    }

    const packed = packGoalTasksAroundLockedAndHabits(
      targetDate,
      rawTemplateTasks,
      lockedBlocks,
      dailyHabits
    );

    setTasks([...otherDaysTasks, ...packed]);
    showToast(
      'Đã áp dụng Mẫu Gantt có sẵn khoảng đệm linh hoạt (±25p) cho ăn uống & việc lặt vặt!'
    );
    for (const t of packed) {
      await syncTaskToFirestore(t, true);
    }
  };

  const handleCompactDaySchedule = async (targetDate: string) => {
    const dayList = tasks.filter((t) => t.date === targetDate);
    if (dayList.length === 0) return;

    const compacted = packGoalTasksAroundLockedAndHabits(
      targetDate,
      dayList,
      lockedBlocks,
      dailyHabits
    );

    const otherTasks = tasks.filter((t) => t.date !== targetDate);
    setTasks([...otherTasks, ...compacted]);
    showToast(
      'Đã tối ưu khung giờ học (vẫn giữ nguyên khoảng đệm linh hoạt cho ăn uống & việc vặt)!'
    );

    for (const t of compacted) {
      await syncTaskToFirestore(t, false);
    }
  };

  const NAV_ITEMS: { id: NavTab; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { id: 'schedule', label: 'Lịch trình', icon: Calendar },
    { id: 'goals', label: 'Mục tiêu', icon: Target },
    { id: 'ai', label: 'Trợ lý AI', icon: Sparkles },
    { id: 'analytics', label: 'Phân tích', icon: BarChart3 },
    { id: 'widget_cloud', label: 'Đồng bộ & APK', icon: Smartphone },
  ];

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 pb-24 lg:pb-10">
      {/* Top Bar Contract: 3 Zones separated by gap-8 */}
      <header className="sticky top-0 z-30 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 px-4 sm:px-6 h-14 flex items-center justify-between gap-8">
        {/* Zone 1: Brand Title */}
        <a
          href="#top"
          onClick={(e) => {
            e.preventDefault();
            setActiveTab('schedule');
          }}
          className="text-base sm:text-lg font-extrabold tracking-tight text-slate-900 dark:text-white whitespace-nowrap shrink-0"
        >
          ChronoFlow
        </a>

        {/* Zone 2: Desktop Navigation Links */}
        <nav className="hidden lg:flex items-center gap-6 text-sm font-medium text-slate-600 dark:text-slate-400">
          {NAV_ITEMS.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setActiveTab(item.id)}
              className={`py-1 transition-colors whitespace-nowrap shrink-0 border-b-2 ${
                activeTab === item.id
                  ? 'border-indigo-600 dark:border-indigo-400 text-slate-900 dark:text-white font-semibold'
                  : 'border-transparent hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              {item.label}
            </button>
          ))}
        </nav>

        {/* Zone 3: Primary Action */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => setActiveTab('widget_cloud')}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold shadow-2xs transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Xuất APK & Lịch</span>
          </button>
          <button
            type="button"
            onClick={() => setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'))}
            className="min-h-[38px] px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-xs font-semibold text-slate-800 dark:text-slate-200 flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0"
          >
            {theme === 'dark' ? (
              <>
                <Moon className="w-3.5 h-3.5 text-indigo-400" />
                <span className="hidden sm:inline">Tối</span>
              </>
            ) : (
              <>
                <Sun className="w-3.5 h-3.5 text-amber-500" />
                <span className="hidden sm:inline">Sáng</span>
              </>
            )}
          </button>
        </div>
      </header>

      {/* Main Content Container */}
      <main className="max-w-5xl mx-auto px-4 sm:px-6 py-4">
        {activeTab === 'schedule' && (
          <ScheduleView
            tasks={tasks}
            goals={goals}
            memories={memories}
            lockedBlocks={lockedBlocks}
            dailyHabits={dailyHabits}
            schoolSyncConfig={schoolSyncConfig}
            selectedDate={selectedDate}
            onSelectDate={setSelectedDate}
            viewMode={viewMode}
            onChangeViewMode={setViewMode}
            onToggleTask={handleToggleTask}
            onDeleteTask={handleDeleteTask}
            onReportIncident={handleReportIncidentFromTask}
            onAddDailyHabit={handleAddDailyHabit}
            onDeleteDailyHabit={handleDeleteDailyHabit}
            onToggleDailyHabitForDate={handleToggleDailyHabitForDate}
            onAddLockedBlock={handleAddLockedBlock}
            onDeleteLockedBlock={handleDeleteLockedBlock}
            onUpdateSchoolSyncConfig={setSchoolSyncConfig}
            onApplySchoolWebSync={handleApplySchoolWebSync}
            onSaveGoalWithRoadmap={handleSaveGoalWithRoadmap}
            onSaveMemory={(content, cat) => handleSaveMemory(content, cat)}
            onApplyFeedbackAdjustedTasks={handleApplyFeedbackAdjustedTasks}
            onApplyGanttTemplate={handleApplyGanttTemplate}
            onCompactDaySchedule={handleCompactDaySchedule}
          />
        )}

        {activeTab === 'goals' && (
          <GoalsStreakView
            goals={goals}
            tasks={tasks}
            memories={memories}
            lockedBlocks={lockedBlocks}
            dailyHabits={dailyHabits}
            onSaveGoalWithRoadmap={handleSaveGoalWithRoadmap}
            onAddDailyHabit={handleAddDailyHabit}
            onDeleteDailyHabit={handleDeleteDailyHabit}
            onIncrementGoalDay={handleIncrementGoalDay}
            onMarkGoalAchieved={handleMarkGoalAchieved}
            onReopenGoal={handleReopenGoal}
            onDeleteGoal={handleDeleteGoal}
          />
        )}

        {activeTab === 'ai' && (
          <AISchedulerView
            tasks={tasks}
            goals={goals}
            memories={memories}
            selectedDate={selectedDate}
            preselectedIncidentTask={preselectedIncidentTask}
            onClearPreselectedIncident={() => setPreselectedIncidentTask(null)}
            onSaveMemory={handleSaveMemory}
            onToggleMemory={handleToggleMemory}
            onDeleteMemory={handleDeleteMemory}
            onApplyProposedTasks={handleApplyProposedTasks}
            onApplyRescheduleAdjustments={handleApplyRescheduleAdjustments}
          />
        )}

        {activeTab === 'analytics' && (
          <AnalyticsView
            tasks={tasks}
            goals={goals}
            dailyHabits={dailyHabits}
            lockedBlocks={lockedBlocks}
            memories={memories}
            onSaveMemory={(content, cat) => handleSaveMemory(content, cat)}
          />
        )}

        {activeTab === 'widget_cloud' && (
          <WidgetCloudApkView
            user={user}
            accessToken={accessToken}
            tasks={tasks}
            goals={goals}
            memories={memories}
            pinnedWidgetSize={pinnedWidgetSize}
            notificationsEnabled={notificationsEnabled}
            lastDriveBackupAt={lastDriveBackupAt}
            onChangeWidgetSize={(sz) => {
              setPinnedWidgetSize(sz);
              localStorage.setItem(STORAGE_KEYS.WIDGET, sz);
            }}
            onToggleNotifications={handleToggleNotifications}
            onTestPushNotification={handleTestPushNotification}
            onToggleTask={handleToggleTask}
            onReportIncident={handleReportIncidentFromTask}
            onGoogleLogin={handleGoogleLogin}
            onGoogleLogout={handleGoogleLogout}
            onRestoreBackupData={handleRestoreBackupData}
            onRecordDriveBackupTime={(ts: string) => {
              setLastDriveBackupAt(ts);
              localStorage.setItem(STORAGE_KEYS.DRIVE_BACKUP, ts);
            }}
          />
        )}
      </main>

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-20 lg:bottom-6 right-4 left-4 sm:left-auto sm:max-w-sm z-50 bg-slate-900 dark:bg-indigo-600 text-white px-4 py-3 rounded-2xl shadow-xl border border-slate-700 dark:border-indigo-400/30 flex items-center gap-2.5 text-xs font-medium">
          <Bell className="w-4 h-4 text-amber-400 dark:text-white shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Mobile Bottom Navigation Bar */}
      <nav className="lg:hidden fixed bottom-0 inset-x-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 px-2 py-1.5 grid grid-cols-5 gap-1">
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          const active = activeTab === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => setActiveTab(item.id)}
              className={`min-h-[48px] rounded-xl flex flex-col items-center justify-center gap-0.5 transition-colors ${
                active
                  ? 'text-indigo-600 dark:text-indigo-400 bg-indigo-500/10 font-semibold'
                  : 'text-slate-500 dark:text-slate-400'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span className="text-[10px] truncate max-w-full px-1">{item.label}</span>
            </button>
          );
        })}
      </nav>
    </div>
  );
}
