import {
  SchoolClassDaySchedule,
  SchoolClassPeriodItem,
  LockedFixedBlock,
} from '../types';
import {
  RAW_EXCEL_MAIN_CSV,
  RAW_EXCEL_TIN_CN_12_CSV,
  THPT_BENCAT_EXCEL_FILES,
} from './thptBenCatExcelRaw';

export { THPT_BENCAT_EXCEL_FILES };

const MORNING_PERIOD_TIMES: Record<number, { start: string; end: string }> = {
  1: { start: '07:00', end: '07:45' },
  2: { start: '07:50', end: '08:35' },
  3: { start: '08:55', end: '09:40' },
  4: { start: '09:45', end: '10:30' },
  5: { start: '10:35', end: '11:15' },
};

const AFTERNOON_PERIOD_TIMES: Record<number, { start: string; end: string }> = {
  1: { start: '13:00', end: '13:45' },
  2: { start: '13:50', end: '14:35' },
  3: { start: '14:50', end: '15:35' },
  4: { start: '15:40', end: '16:25' },
  5: { start: '16:30', end: '17:15' },
};

const DAY_LABELS: Record<number, string> = {
  1: 'Thứ 2',
  2: 'Thứ 3',
  3: 'Thứ 4',
  4: 'Thứ 5',
  5: 'Thứ 6',
  6: 'Thứ 7',
};

function parseCSVLine(line: string): string[] {
  const result: string[] = [];
  let cur = '';
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') {
      inQuotes = !inQuotes;
    } else if (ch === ',' && !inQuotes) {
      result.push(cur.trim());
      cur = '';
    } else {
      cur += ch;
    }
  }
  result.push(cur.trim());
  return result;
}

function normalizeSubjectLabel(raw: string): string {
  const trimmed = (raw || '').trim();
  if (!trimmed) return '';
  if (trimmed.toUpperCase() === 'CHAOCO') return 'Chào cờ';
  if (trimmed.toUpperCase() === 'GDTC') return 'GD Thể chất (Thể dục)';
  if (trimmed.toUpperCase() === 'GDQP') return 'GD Quốc phòng';
  if (trimmed.toUpperCase() === 'GD ĐP') return 'GD Địa phương';
  if (trimmed.toUpperCase() === 'HĐTN') return 'HĐ Trải nghiệm - HN';
  return trimmed;
}

/**
  * Chuẩn hóa tên lớp: ở Trường THPT Bến Cát các lớp đặt tên là 10C1..10C17, 11C1..11C15, 12C1..12C15.
  * Nếu người dùng gõ 12A1 -> tự động ánh xạ sang 12C1 để khớp đúng sheet Excel của trường.
  */
export function normalizeBenCatClassName(rawClass: string): string {
  const clean = (rawClass || '12C1').trim().toUpperCase();
  const matchA = clean.match(/^(10|11|12)A([0-9]+)$/);
  if (matchA) {
    return `${matchA[1]}C${matchA[2]}`;
  }
  return clean;
}

export function parseTinHocCongNghe12Csv(
  csvTinCN: string = RAW_EXCEL_TIN_CN_12_CSV
): Record<
  string,
  {
    dayOfWeek: number;
    periodNumber: number;
    subject: string;
    roomOrTeacher: string;
  }[]
> {
  const dayMapVN: Record<string, number> = {
    Hai: 1,
    Ba: 2,
    Tư: 3,
    Năm: 4,
    Sáu: 5,
    Bảy: 6,
  };
  const teacherCols = [
    { col: 3, teacher: 'Cô Trang - Phòng tin 2' },
    { col: 4, teacher: 'Cô Quế Anh - Phòng tin 1' },
    { col: 5, teacher: 'Cô Lựu' },
    { col: 6, teacher: 'Cô Vân' },
  ];

  const tinCNByClass: Record<
    string,
    {
      dayOfWeek: number;
      periodNumber: number;
      subject: string;
      roomOrTeacher: string;
    }[]
  > = {};

  const lines = (csvTinCN || '').split(/\r?\n/);
  let currentDay = 0;

  for (const line of lines) {
    const cols = parseCSVLine(line);
    if (cols[0] && dayMapVN[cols[0]]) {
      currentDay = dayMapVN[cols[0]];
    }
    const periodNum = parseInt(cols[2] || '', 10);
    if (currentDay && periodNum >= 1 && periodNum <= 5) {
      for (const tc of teacherCols) {
        const cell = cols[tc.col] || '';
        if (!cell) continue;
        const groupMatch = cell.match(/^([A-Za-z0-9]+)\(([^)]+)\)/);
        if (groupMatch) {
          const groupCode = groupMatch[1];
          const classList = groupMatch[2]
            .split(',')
            .map((s) => s.trim().toUpperCase());
          const subjLabel = groupCode.startsWith('Ti')
            ? `Tin học 12 (${groupCode})`
            : groupCode.startsWith('CN')
            ? `Công nghệ CN (${groupCode})`
            : `Công nghệ NN (${groupCode})`;

          for (const cls of classList) {
            if (!tinCNByClass[cls]) tinCNByClass[cls] = [];
            tinCNByClass[cls].push({
              dayOfWeek: currentDay,
              periodNumber: periodNum,
              subject: subjLabel,
              roomOrTeacher: tc.teacher,
            });
          }
        }
      }
    }
  }

  return tinCNByClass;
}

export function extractAllClassesFromBenCatExcel(
  csvMain: string = RAW_EXCEL_MAIN_CSV
): string[] {
  const lines = (csvMain || '').split(/\r?\n/);
  const classes: string[] = [];
  for (const line of lines) {
    const m = line.match(/Lớp,([0-9]{2}[A-Z][0-9]+)/i);
    if (m) {
      const cls = m[1].toUpperCase();
      if (!classes.includes(cls)) {
        classes.push(cls);
      }
    }
  }
  return classes;
}

export function parseClassTimetableFromBenCatExcel(
  rawClassName: string,
  csvMain: string = RAW_EXCEL_MAIN_CSV,
  csvTinCN: string = RAW_EXCEL_TIN_CN_12_CSV
): {
  className: string;
  resolvedClassName: string;
  effectiveDateInExcel: string;
  allClasses: string[];
  availableClasses: string[];
  classTimetable: SchoolClassDaySchedule[];
  extractedLockedBlocks: LockedFixedBlock[];
  diffFromOldVersion: string[];
  changeSummary: string;
} {
  const availableClasses = extractAllClassesFromBenCatExcel(csvMain);
  let resolvedClassName = normalizeBenCatClassName(rawClassName);
  if (
    availableClasses.length > 0 &&
    !availableClasses.includes(resolvedClassName)
  ) {
    resolvedClassName = availableClasses[0];
  }

  const tinCNMap = parseTinHocCongNghe12Csv(csvTinCN);
  const classTinCN = tinCNMap[resolvedClassName] || [];

  const lines = (csvMain || '').split(/\r?\n/);
  const classLineIdx = lines.findIndex((l) =>
    new RegExp(`Lớp,${resolvedClassName}(?:,|$)`, 'i').test(l)
  );

  let effectiveDateInExcel = '26/10/2026 (Áp dụng cho Tuần 9 - 02/11/2026)';
  const morningGrid: Record<number, Record<number, string>> = {
    1: {},
    2: {},
    3: {},
    4: {},
    5: {},
    6: {},
  };
  const afternoonGrid: Record<number, Record<number, string>> = {
    1: {},
    2: {},
    3: {},
    4: {},
    5: {},
    6: {},
  };

  if (classLineIdx !== -1) {
    const blockLines = lines.slice(classLineIdx, classLineIdx + 20);
    let currentSession: 'morning' | 'afternoon' | null = null;

    for (const rowStr of blockLines) {
      const cols = parseCSVLine(rowStr);
      if (rowStr.includes('Có tác dụng từ ngày')) {
        const dtCandidate = cols.find((c) => /\d{1,2}\/\d{1,2}\/\d{4}/.test(c));
        if (dtCandidate) effectiveDateInExcel = dtCandidate;
      }
      if (cols[0]?.toLowerCase().includes('buổi sáng')) {
        currentSession = 'morning';
        continue;
      }
      if (cols[0]?.toLowerCase().includes('buổi chiều')) {
        currentSession = 'afternoon';
        continue;
      }
      const pNum = parseInt(cols[0] || '', 10);
      if (currentSession && pNum >= 1 && pNum <= 5) {
        for (let dayOfWeek = 1; dayOfWeek <= 6; dayOfWeek++) {
          const rawSubj = cols[dayOfWeek] || '';
          const normSubj = normalizeSubjectLabel(rawSubj);
          if (normSubj) {
            if (currentSession === 'morning') {
              morningGrid[dayOfWeek][pNum] = normSubj;
            } else {
              afternoonGrid[dayOfWeek][pNum] = normSubj;
            }
          }
        }
      }
    }
  }

  const classTimetable: SchoolClassDaySchedule[] = [1, 2, 3, 4, 5, 6].map(
    (dayOfWeek) => {
      const periods: SchoolClassPeriodItem[] = [];

      // Morning periods (1..5)
      for (let p = 1; p <= 5; p++) {
        const subj = morningGrid[dayOfWeek][p];
        if (subj) {
          periods.push({
            periodNumber: p,
            session: 'morning',
            startTime: MORNING_PERIOD_TIMES[p].start,
            endTime: MORNING_PERIOD_TIMES[p].end,
            subject: subj,
            roomOrTeacher: `Phòng ${resolvedClassName}`,
          });
        }
      }

      // Afternoon periods from File Excel 1 (TKB Chính khóa) + File Excel 2 (TKB Ghép Tin học & Công nghệ 12)
      for (let p = 1; p <= 5; p++) {
        const mainAftSubj = afternoonGrid[dayOfWeek][p];
        const tinCNAftItems = classTinCN.filter(
          (item) => item.dayOfWeek === dayOfWeek && item.periodNumber === p
        );

        const combinedSubjects: string[] = [];
        const combinedTeachers: string[] = [];

        if (mainAftSubj) {
          combinedSubjects.push(mainAftSubj);
          combinedTeachers.push(`Phòng ${resolvedClassName}`);
        }
        for (const tcItem of tinCNAftItems) {
          if (!combinedSubjects.includes(tcItem.subject)) {
            combinedSubjects.push(tcItem.subject);
            combinedTeachers.push(tcItem.roomOrTeacher);
          }
        }

        if (combinedSubjects.length > 0) {
          periods.push({
            periodNumber: p,
            session: 'afternoon',
            startTime: AFTERNOON_PERIOD_TIMES[p].start,
            endTime: AFTERNOON_PERIOD_TIMES[p].end,
            subject: combinedSubjects.join(' / '),
            roomOrTeacher: combinedTeachers.join(' · '),
          });
        }
      }

      const morningPeriods = periods.filter((item) => item.session === 'morning');
      const afternoonPeriods = periods.filter(
        (item) => item.session === 'afternoon'
      );

      const maxMorningPeriod =
        morningPeriods.length > 0
          ? Math.max(...morningPeriods.map((m) => m.periodNumber))
          : 0;
      const morningEndTime =
        maxMorningPeriod >= 5
          ? '11:15'
          : maxMorningPeriod === 4
          ? '10:30'
          : '10:30';

      const morningSummary =
        morningPeriods.length > 0
          ? `Sáng (07:00–${morningEndTime}): ${morningPeriods
              .map((m) => m.subject)
              .join(', ')}`
          : 'Nghỉ sáng';

      let afternoonSummary = 'Nghỉ chiều';
      if (afternoonPeriods.length > 0) {
        const firstStart = afternoonPeriods[0].startTime;
        const lastEnd = afternoonPeriods[afternoonPeriods.length - 1].endTime;
        afternoonSummary = `Chiều (${firstStart}–${lastEnd}): ${afternoonPeriods
          .map((a) => a.subject)
          .join(', ')}`;
      }

      return {
        dayOfWeek,
        dayLabel: DAY_LABELS[dayOfWeek],
        morningSummary,
        afternoonSummary,
        periods,
      };
    }
  );

  // Derive concise LockedFixedBlock[] from the real Excel periods of this class
  const fivePeriodMorningDays: number[] = [];
  const fourPeriodMorningDays: number[] = [];
  const afternoonBlocksByRange: Record<
    string,
    { days: number[]; start: string; end: string; subjects: string[] }
  > = {};

  for (const day of classTimetable) {
    const mPeriods = day.periods.filter((p) => p.session === 'morning');
    const aPeriods = day.periods.filter((p) => p.session === 'afternoon');

    const maxM =
      mPeriods.length > 0 ? Math.max(...mPeriods.map((p) => p.periodNumber)) : 0;
    if (maxM >= 5) {
      fivePeriodMorningDays.push(day.dayOfWeek);
    } else if (maxM > 0) {
      fourPeriodMorningDays.push(day.dayOfWeek);
    }

    if (aPeriods.length > 0) {
      const start = aPeriods[0].startTime;
      const end = aPeriods[aPeriods.length - 1].endTime;
      const key = `${start}_${end}`;
      if (!afternoonBlocksByRange[key]) {
        afternoonBlocksByRange[key] = { days: [], start, end, subjects: [] };
      }
      afternoonBlocksByRange[key].days.push(day.dayOfWeek);
      for (const ap of aPeriods) {
        if (!afternoonBlocksByRange[key].subjects.includes(ap.subject)) {
          afternoonBlocksByRange[key].subjects.push(ap.subject);
        }
      }
    }
  }

  const fmtDays = (arr: number[]) => arr.map((d) => `T${d + 1}`).join(', ');
  const extractedLockedBlocks: LockedFixedBlock[] = [];

  if (fivePeriodMorningDays.length > 0) {
    extractedLockedBlocks.push({
      id: `excel_${resolvedClassName.toLowerCase()}_morning_5p`,
      title: `Học sáng Lớp ${resolvedClassName} (5 tiết)`,
      daysOfWeek: fivePeriodMorningDays,
      startTime: '07:00',
      endTime: '11:15',
      source: 'school_web',
    });
  }

  if (fourPeriodMorningDays.length > 0) {
    extractedLockedBlocks.push({
      id: `excel_${resolvedClassName.toLowerCase()}_morning_4p`,
      title: `Học sáng Lớp ${resolvedClassName} (4 tiết · Tan 10:30)`,
      daysOfWeek: fourPeriodMorningDays,
      startTime: '07:00',
      endTime: '10:30',
      source: 'school_web',
    });
  }

  Object.entries(afternoonBlocksByRange).forEach(([key, grp], idx) => {
    extractedLockedBlocks.push({
      id: `excel_${resolvedClassName.toLowerCase()}_aft_${idx}_${key}`,
      title: `Học chiều Lớp ${resolvedClassName}: ${grp.subjects.slice(0, 2).join(', ')}`,
      daysOfWeek: grp.days,
      startTime: grp.start,
      endTime: grp.end,
      source: 'school_web',
    });
  });

  const busyAfternoonDays = Object.values(afternoonBlocksByRange).flatMap((g) => g.days);
  const freeAfternoonDays = [1, 2, 3, 4, 5, 6]
    .filter((d) => !busyAfternoonDays.includes(d))
    .map((d) => `T${d + 1}`)
    .join(', ');

  const diffFromOldVersion: string[] = [
    `Đọc trực tiếp từ File Excel TKB Tuần 9 (02/11/2026) trên thptbencat.edu.vn cho Lớp ${resolvedClassName}.`,
    `Ca chiều học vào: ${busyAfternoonDays.length > 0 ? fmtDays(busyAfternoonDays) : 'Không có'} · Nghỉ chiều: ${freeAfternoonDays || 'T7'}.`,
  ];

  const changeSummary = `Đã đồng bộ TKB Lớp ${resolvedClassName} từ File Excel trường THPT Bến Cát (Nghỉ chiều: ${freeAfternoonDays}).`;

  return {
    className: resolvedClassName,
    resolvedClassName,
    effectiveDateInExcel,
    allClasses: availableClasses,
    availableClasses,
    classTimetable,
    extractedLockedBlocks,
    diffFromOldVersion,
    changeSummary,
  };
}
