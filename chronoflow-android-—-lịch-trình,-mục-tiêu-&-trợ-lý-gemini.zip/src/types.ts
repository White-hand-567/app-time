import {
  THPT_BENCAT_EXCEL_FILES,
} from './data/thptBenCatExcelRaw';
import {
  parseClassTimetableFromBenCatExcel,
} from './data/thptBenCatExcelParser';

export type TaskCategory = 'study' | 'work' | 'health' | 'personal' | 'commute';
export type TaskPriority = 'high' | 'medium' | 'low';
export type ScheduleViewMode = 'day' | 'multiday' | 'week' | 'month';
export type ScheduleDisplayFormat = 'gantt' | 'list' | 'donut' | 'kanban';
export type AIMemoryCategory = 'commute' | 'routine' | 'energy' | 'constraint';
export type WidgetSize = '2x2' | '4x2' | '4x4';

/**
 * VIỆC 3: VIỆC CHẾT (Chỉ khóa các lịch bắt buộc bên ngoài như học ở trường, đi học thêm — Mặc định tự động tiếp diễn qua tuần sau, tháng sau)
 */
export interface LockedFixedBlock {
  id: string;
  title: string;
  daysOfWeek: number[]; // 0 = CN, 1 = T2, 2 = T3, 3 = T4, 4 = T5, 5 = T6, 6 = T7
  startTime: string; // HH:mm
  endTime: string; // HH:mm
  source?: 'manual' | 'school_web';
}

/**
 * Chi tiết từng tiết học cụ thể của từng Lớp trên Thời khóa biểu trường
 */
export interface SchoolClassPeriodItem {
  periodNumber: number; // Tiết 1..5
  session: 'morning' | 'afternoon'; // Sáng | Chiều
  startTime: string; // HH:mm
  endTime: string; // HH:mm
  subject: string; // VD: Toán, Vật Lý, Hóa Học, Ngữ Văn, Tiếng Anh...
  roomOrTeacher?: string; // VD: P.A201 · Cô Lan
}

/**
 * Lịch học cụ thể của 1 Lớp trong 1 Thứ (Thứ 2 -> Thứ 7)
 */
export interface SchoolClassDaySchedule {
  dayOfWeek: number; // 1 = T2 .. 6 = T7
  dayLabel: string; // Thứ 2 .. Thứ 7
  morningSummary: string; // VD: "Tiết 1-5: Chào cờ, Toán, Toán, Văn, Anh (07:00–11:15)"
  afternoonSummary: string; // VD: "Tiết 1-3: Bồi dưỡng Lý & Hóa (13:30–15:55)" hoặc "Trống lịch chiều"
  periods: SchoolClassPeriodItem[];
}

/**
 * Thông tin phiên bản Thời khóa biểu trên cổng trường (để phát hiện và loại bỏ TKB cũ)
 */
export interface TimetableVersionItem {
  id: string;
  versionLabel: string; // VD: "TKB Tuần 9 (Mới nhất - Áp dụng từ 02/11/2026)"
  effectiveDate: string; // VD: "02/11/2026"
  isLatest: boolean;
  isDeprecatedOld: boolean;
  sourceNote: string; // VD: "VietSchool #74000714 · Gồm TKB Chính khóa + Tin học MOS + Tiếng Anh giao tiếp"
}

/**
 * Cấu hình kết nối Web Trường để AI tự động truy cập và cập nhật Thời khóa biểu chi tiết theo từng Lớp
 */
export interface SchoolPortalSyncConfig {
  schoolUrl: string;
  selectedClassName: string; // VD: "12A1", "12A2", "11A1", "10A1"
  availableClasses: string[]; // Danh sách các lớp trên cổng trường
  activeVersionId?: string;
  activeVersionLabel?: string;
  availableVersions?: TimetableVersionItem[];
  diffFromOldVersion?: string[]; // Danh sách các điểm thay đổi so với TKB cũ đã bị loại bỏ
  classCodeOrNote: string;
  autoSyncOnStartup: boolean;
  lastSyncedAt: string;
  lastChangeSummary: string;
  classTimetable: SchoolClassDaySchedule[];
}

/**
 * Kết quả khi AI truy cập Web Trường (hoặc đọc ảnh/bảng TKB) để trích xuất Thời khóa biểu cụ thể của từng Lớp
 */
export interface AISchoolWebSyncResponse {
  schoolNameOrPageTitle: string;
  detectedClassName: string;
  availableClassesOnPortal: string[];
  activeVersionId?: string;
  activeVersionLabel?: string;
  availableVersions?: TimetableVersionItem[];
  diffFromOldVersion?: string[];
  changeSummary: string;
  detectedChanges: string[];
  classTimetable: SchoolClassDaySchedule[];
  extractedLockedBlocks: {
    title: string;
    daysOfWeek: number[];
    startTime: string;
    endTime: string;
  }[];
}

/**
 * VIỆC 2: VIỆC HÀNG NGÀY / VIỆC TỐI THIỂU (Chỉ Thêm hoặc Xóa — Tự động lặp lại mỗi ngày & ghi chuỗi Streak)
 */
export interface DailyMinimumHabit {
  id: string;
  title: string;
  startTime: string; // HH:mm (khung giờ gợi ý linh hoạt ±20p)
  endTime: string; // HH:mm
  currentStreak: number;
  bestStreak: number;
  completedDates: string[]; // Danh sách ngày YYYY-MM-DD đã hoàn thành
}

export interface ScheduleTask {
  id: string;
  userId: string;
  title: string;
  notes: string;
  date: string; // YYYY-MM-DD
  startTime: string; // HH:mm
  endTime: string; // HH:mm
  category: TaskCategory;
  priority: TaskPriority;
  completed: boolean;
  isMinimumDaily: boolean;
  currentStreak: number;
  bestStreak: number;
  lastCompletedDate: string;
  reminderEnabled: boolean;
  reminderMinutesBefore: number;
  goalId: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface GoalItem {
  id: string;
  userId: string;
  title: string;
  description: string;
  targetDate: string; // YYYY-MM-DD
  dailyActionTitle: string;
  dailyTargetMinutes: number;
  totalTargetDays: number;
  completedDays: number;
  progressPercent: number;
  isAchieved: boolean;
  achievedDate: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface AIMemoryItem {
  id: string;
  userId: string;
  content: string;
  category: AIMemoryCategory;
  isActive: boolean;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface UserSettings {
  userId: string;
  theme: 'dark' | 'light';
  notificationsEnabled: boolean;
  pinnedWidgetSize: WidgetSize;
  lastDriveBackupAt: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface ProposedTaskDraft {
  title: string;
  notes: string;
  date: string;
  startTime: string;
  endTime: string;
  category: TaskCategory;
  priority: TaskPriority;
  isMinimumDaily: boolean;
}

export interface AIGoalDailyStep {
  dayNumber: number;
  date: string;
  title: string;
  notes: string;
  startTime: string;
  endTime: string;
  freeTimeSummary: string;
  isMinimumDaily: boolean;
}

export interface AIGoalRoadmapResponse {
  goalTitle: string;
  goalDescription: string;
  dailyTargetMinutes: number;
  totalDays: number;
  strategyNote: string;
  dailyPlan: AIGoalDailyStep[];
}

export interface AIPlanResponse {
  summary: string;
  appliedMemoryNotes: string[];
  proposedTasks: ProposedTaskDraft[];
  extractedNewMemories: {
    content: string;
    category: AIMemoryCategory;
  }[];
}

export interface AIAdjustmentItem {
  taskId: string;
  actionType: 'move' | 'shorten' | 'split';
  title: string;
  oldDate: string;
  oldStartTime: string;
  oldEndTime: string;
  newDate: string;
  newStartTime: string;
  newEndTime: string;
  updatedNotes: string;
  reason: string;
}

export interface AIRescheduleResponse {
  empathyAndAnalysis: string;
  appliedMemoryNotes: string[];
  adjustments: AIAdjustmentItem[];
  extractedNewMemories: {
    content: string;
    category: AIMemoryCategory;
  }[];
}

export interface AIFeedbackAdjustResponse {
  aiUnderstanding: string;
  learnedHabitRule: string;
  learnedCategory: AIMemoryCategory;
  predictedBestWindows: {
    label: string;
    startTime: string;
    endTime: string;
    confidencePct: number;
    reason: string;
  }[];
  updatedDayTasks: {
    taskId: string;
    title: string;
    date: string;
    startTime: string;
    endTime: string;
    notes: string;
  }[];
}

export interface AIAnalyticsReviewResponse {
  overallComment: string;
  strengthsAnalysis: string;
  habitAndBufferDetection: string;
  predictedPeakWindow: string;
  recommendations: {
    title: string;
    detail: string;
    memoryRuleToSave: string;
    impactLabel: string;
  }[];
}

export interface DriveBackupFile {
  id: string;
  name: string;
  modifiedTime: string;
  size?: string;
}

export const CATEGORY_LABELS: Record<TaskCategory, string> = {
  study: 'Lộ trình Mục tiêu',
  work: 'Thực hành Mục tiêu',
  health: 'Việc hàng ngày',
  personal: 'Cá nhân',
  commute: 'Khác',
};

export const PRIORITY_LABELS: Record<TaskPriority, string> = {
  high: 'Ưu tiên cao',
  medium: 'Trung bình',
  low: 'Thấp',
};

export const MEMORY_CATEGORY_LABELS: Record<AIMemoryCategory, string> = {
  routine: 'Việc chết / Thời khóa biểu cố định',
  commute: 'Đệm việc vặt & Sinh hoạt linh hoạt',
  energy: 'Khung giờ AI dự đoán hiệu quả nhất',
  constraint: 'Ý kiến & Thói quen cá nhân đã học',
};

export const WEEKDAY_LABELS: { day: number; short: string; full: string }[] = [
  { day: 1, short: 'T2', full: 'Thứ 2' },
  { day: 2, short: 'T3', full: 'Thứ 3' },
  { day: 3, short: 'T4', full: 'Thứ 4' },
  { day: 4, short: 'T5', full: 'Thứ 5' },
  { day: 5, short: 'T6', full: 'Thứ 6' },
  { day: 6, short: 'T7', full: 'Thứ 7' },
  { day: 0, short: 'CN', full: 'Chủ nhật' },
];

export function getTodayStr(): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function addDaysStr(dateStr: string, offset: number): string {
  const [y, m, d] = dateStr.split('-').map(Number);
  const dt = new Date(y, m - 1, d);
  dt.setDate(dt.getDate() + offset);
  const ny = dt.getFullYear();
  const nm = String(dt.getMonth() + 1).padStart(2, '0');
  const nd = String(dt.getDate()).padStart(2, '0');
  return `${ny}-${nm}-${nd}`;
}

export function getWeekdayFromDateStr(dateStr: string): number {
  const [y, m, d] = dateStr.split('-').map(Number);
  return new Date(y, m - 1, d).getDay();
}

export function formatDaysOfWeekBadge(days: number[]): string {
  if (days.length === 7) return 'Mỗi ngày';
  const weekdays = [1, 2, 3, 4, 5];
  if (days.length === 5 && weekdays.every((d) => days.includes(d))) {
    return 'T2 – T6';
  }
  const map: Record<number, string> = {
    1: 'T2',
    2: 'T3',
    3: 'T4',
    4: 'T5',
    5: 'T6',
    6: 'T7',
    0: 'CN',
  };
  return days
    .slice()
    .sort((a, b) => (a === 0 ? 7 : a) - (b === 0 ? 7 : b))
    .map((d) => map[d])
    .join(', ');
}

/**
 * Tự động bóc tách link gốc nếu người dùng copy link chuyển hướng từ Google Search
 */
export function unwrapSchoolUrl(rawInput: string): string {
  const trimmed = (rawInput || '').trim();
  if (!trimmed) return '';
  try {
    const withProto = /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
    const parsed = new URL(withProto);
    if (
      parsed.hostname.includes('google.') &&
      (parsed.pathname === '/url' || parsed.searchParams.has('q') || parsed.searchParams.has('url'))
    ) {
      const target = parsed.searchParams.get('q') || parsed.searchParams.get('url');
      if (target) return target.trim();
    }
    return withProto;
  } catch {
    const match = trimmed.match(/[?&](?:q|url)=([^&]+)/i);
    if (match && match[1]) {
      try {
        return decodeURIComponent(match[1]);
      } catch {
        return match[1];
      }
    }
    return trimmed;
  }
}

export function getDefaultTimetableVersions(): TimetableVersionItem[] {
  return THPT_BENCAT_EXCEL_FILES;
}

export function getDefaultClassTimetable(className = '12C1'): SchoolClassDaySchedule[] {
  return parseClassTimetableFromBenCatExcel(className).classTimetable;
}

/**
 * Tự động suy ra danh sách Khung Giờ Chết Cố Định từ bảng Thời khóa biểu chi tiết của Lớp
 */
export function deriveLockedBlocksFromClassTimetable(
  className: string,
  _versionBadge: string,
  timetable: SchoolClassDaySchedule[]
): LockedFixedBlock[] {
  const fivePeriodDays: number[] = [];
  const fourPeriodDays: number[] = [];
  const afternoonBlocksByRange: Record<
    string,
    { days: number[]; start: string; end: string; subjects: string[] }
  > = {};

  for (const day of timetable) {
    const mPeriods = day.periods.filter((p) => p.session === 'morning');
    const aPeriods = day.periods.filter((p) => p.session === 'afternoon');
    const maxM =
      mPeriods.length > 0 ? Math.max(...mPeriods.map((p) => p.periodNumber)) : 0;

    if (maxM >= 5) {
      fivePeriodDays.push(day.dayOfWeek);
    } else if (maxM > 0) {
      fourPeriodDays.push(day.dayOfWeek);
    }

    if (aPeriods.length > 0) {
      const start = aPeriods[0].startTime;
      const end = aPeriods[aPeriods.length - 1].endTime;
      const key = `${start}_${end}`;
      if (!afternoonBlocksByRange[key]) {
        afternoonBlocksByRange[key] = { days: [], start, end, subjects: [] };
      }
      afternoonBlocksByRange[key].days.push(day.dayOfWeek);
      for (const ap of aPeriods) {
        if (!afternoonBlocksByRange[key].subjects.includes(ap.subject)) {
          afternoonBlocksByRange[key].subjects.push(ap.subject);
        }
      }
    }
  }

  const blocks: LockedFixedBlock[] = [];

  if (fivePeriodDays.length > 0) {
    blocks.push({
      id: `lock_${className.toLowerCase()}_5p_morning`,
      title: `Học sáng Lớp ${className} (5 tiết)`,
      daysOfWeek: fivePeriodDays,
      startTime: '07:00',
      endTime: '11:15',
      source: 'school_web',
    });
  }
  if (fourPeriodDays.length > 0) {
    blocks.push({
      id: `lock_${className.toLowerCase()}_4p_morning`,
      title: `Học sáng Lớp ${className} (4 tiết · Tan 10:30)`,
      daysOfWeek: fourPeriodDays,
      startTime: '07:00',
      endTime: '10:30',
      source: 'school_web',
    });
  }
  Object.entries(afternoonBlocksByRange).forEach(([key, grp], idx) => {
    blocks.push({
      id: `lock_${className.toLowerCase()}_aft_${idx}_${key}`,
      title: `Học chiều Lớp ${className}: ${grp.subjects.slice(0, 2).join(', ')}`,
      daysOfWeek: grp.days,
      startTime: grp.start,
      endTime: grp.end,
      source: 'school_web',
    });
  });

  return blocks;
}

export function getDefaultSchoolSyncConfig(): SchoolPortalSyncConfig {
  const parsed12C1 = parseClassTimetableFromBenCatExcel('12C1');
  return {
    schoolUrl: 'https://thptbencat.edu.vn/category/thoi-khoa-bieu',
    selectedClassName: parsed12C1.resolvedClassName,
    availableClasses: parsed12C1.availableClasses,
    activeVersionId: 'excel_main_tkblop_w9',
    activeVersionLabel: 'TKB Tuần 9 (02/11/2026 · File Excel)',
    availableVersions: getDefaultTimetableVersions(),
    diffFromOldVersion: parsed12C1.diffFromOldVersion,
    classCodeOrNote: 'File Excel TKB trường THPT Bến Cát',
    autoSyncOnStartup: true,
    lastSyncedAt: 'Đã đồng bộ File Excel Tuần 9',
    lastChangeSummary: parsed12C1.changeSummary,
    classTimetable: parsed12C1.classTimetable,
  };
}

export function getDefaultLockedBlocks(): LockedFixedBlock[] {
  return parseClassTimetableFromBenCatExcel('12C1').extractedLockedBlocks;
}

export function getDefaultDailyHabits(): DailyMinimumHabit[] {
  const today = getTodayStr();
  return [
    {
      id: 'habit_english_daily',
      title: 'Ôn 30 từ vựng Anki & Nghe IELTS',
      startTime: '16:30',
      endTime: '17:15',
      currentStreak: 12,
      bestStreak: 18,
      completedDates: [today],
    },
    {
      id: 'habit_workout_daily',
      title: 'Vận động thể lực 35 phút',
      startTime: '17:20',
      endTime: '17:55',
      currentStreak: 8,
      bestStreak: 14,
      completedDates: [],
    },
  ];
}

export function getDefaultMemories(userId = 'local-user'): AIMemoryItem[] {
  return [
    {
      id: 'mem_flexible_micro_chores',
      userId,
      content:
        'Chừa khoảng đệm linh hoạt (±25p) sau giờ học (11:15–13:00 và 18:00–19:15) cho ăn uống, nghỉ ngơi & việc vặt.',
      category: 'commute',
      isActive: true,
    },
    {
      id: 'mem_predicted_peak_hours',
      userId,
      content:
        'Khung giờ tập trung tốt nhất: Ca chiều (13:00–16:15 các ngày nghỉ chiều) và Ca tối (19:15–21:30).',
      category: 'energy',
      isActive: true,
    },
  ];
}

export function getDefaultTasks(userId = 'local-user'): ScheduleTask[] {
  const today = getTodayStr();
  const tomorrow = addDaysStr(today, 1);
  const dayAfter = addDaysStr(today, 2);

  return [
    {
      id: 'task_goal_day1_1',
      userId,
      title: 'Bài 1 & 2: Cấu trúc dữ liệu Mảng & Chuỗi',
      notes: 'Lộ trình mục tiêu · Ca chiều',
      date: today,
      startTime: '13:00',
      endTime: '14:45',
      category: 'study',
      priority: 'high',
      completed: true,
      isMinimumDaily: false,
      currentStreak: 0,
      bestStreak: 0,
      lastCompletedDate: today,
      reminderEnabled: true,
      reminderMinutesBefore: 15,
      goalId: 'goal_android_dev',
    },
    {
      id: 'task_goal_day1_2',
      userId,
      title: 'Thực hành 5 bài tập Mảng & Chuỗi',
      notes: 'Lộ trình mục tiêu · Ca chiều 2',
      date: today,
      startTime: '15:00',
      endTime: '16:15',
      category: 'work',
      priority: 'high',
      completed: true,
      isMinimumDaily: false,
      currentStreak: 0,
      bestStreak: 0,
      lastCompletedDate: today,
      reminderEnabled: true,
      reminderMinutesBefore: 10,
      goalId: 'goal_android_dev',
    },
    {
      id: 'task_evening_project',
      userId,
      title: 'Bài 3: Danh sách liên kết & Giao diện Android',
      notes: 'Lộ trình mục tiêu · Khung giờ tối',
      date: today,
      startTime: '19:15',
      endTime: '21:15',
      category: 'study',
      priority: 'high',
      completed: false,
      isMinimumDaily: false,
      currentStreak: 0,
      bestStreak: 0,
      lastCompletedDate: '',
      reminderEnabled: true,
      reminderMinutesBefore: 10,
      goalId: 'goal_android_dev',
    },
    {
      id: 'task_tomorrow_1',
      userId,
      title: 'Bài 4 & 5: Ngăn xếp (Stack) & Hàng đợi (Queue)',
      notes: 'Lộ trình mục tiêu · Khung giờ tối',
      date: tomorrow,
      startTime: '19:15',
      endTime: '21:15',
      category: 'study',
      priority: 'high',
      completed: false,
      isMinimumDaily: false,
      currentStreak: 0,
      bestStreak: 0,
      lastCompletedDate: '',
      reminderEnabled: true,
      reminderMinutesBefore: 15,
      goalId: 'goal_android_dev',
    },
    {
      id: 'task_day3_1',
      userId,
      title: 'Bài 6: Cây nhị phân & Đồ thị BFS/DFS',
      notes: 'Lộ trình mục tiêu · Ca chiều',
      date: dayAfter,
      startTime: '13:00',
      endTime: '16:15',
      category: 'study',
      priority: 'high',
      completed: false,
      isMinimumDaily: false,
      currentStreak: 0,
      bestStreak: 0,
      lastCompletedDate: '',
      reminderEnabled: true,
      reminderMinutesBefore: 15,
      goalId: 'goal_android_dev',
    },
    {
      id: 'task_day3_2',
      userId,
      title: 'Bài 7: Quy hoạch động & Tối ưu Firebase',
      notes: 'Lộ trình mục tiêu · Khung giờ tối',
      date: dayAfter,
      startTime: '19:15',
      endTime: '21:15',
      category: 'work',
      priority: 'high',
      completed: false,
      isMinimumDaily: false,
      currentStreak: 0,
      bestStreak: 0,
      lastCompletedDate: '',
      reminderEnabled: true,
      reminderMinutesBefore: 15,
      goalId: 'goal_android_dev',
    },
    {
      id: 'task_day4_1',
      userId,
      title: 'Bài 8: Clean Architecture & Tổng ôn',
      notes: 'Hoàn tất lộ trình mục tiêu',
      date: addDaysStr(today, 3),
      startTime: '19:15',
      endTime: '21:15',
      category: 'study',
      priority: 'high',
      completed: false,
      isMinimumDaily: false,
      currentStreak: 0,
      bestStreak: 0,
      lastCompletedDate: '',
      reminderEnabled: true,
      reminderMinutesBefore: 15,
      goalId: 'goal_android_dev',
    },
  ];
}

export function getDefaultGoals(userId = 'local-user'): GoalItem[] {
  const today = getTodayStr();
  return [
    {
      id: 'goal_android_dev',
      userId,
      title: 'Lộ trình Thuật toán & Lập trình Android',
      description: 'Ngày 1: Bài 1–3 · Ngày 2: Bài 4–5 · Ngày 3: Bài 6–7 · Ngày 4: Bài 8',
      targetDate: addDaysStr(today, 7),
      dailyActionTitle: 'Học theo khung giờ rảnh AI phân bổ',
      dailyTargetMinutes: 150,
      totalTargetDays: 4,
      completedDays: 1,
      progressPercent: 25,
      isAchieved: false,
      achievedDate: '',
    },
  ];
}
