import { AIMemoryItem, DriveBackupFile, GoalItem, ScheduleTask, UserSettings } from '../types';

export interface ChronoFlowBackupPayload {
  appVersion: string;
  exportedAt: string;
  tasks: ScheduleTask[];
  goals: GoalItem[];
  memories: AIMemoryItem[];
  settings: Partial<UserSettings>;
}

const BACKUP_FILE_PREFIX = 'ChronoFlow_Backup_';

export async function listDriveBackups(accessToken: string): Promise<DriveBackupFile[]> {
  const query = encodeURIComponent(
    `name contains '${BACKUP_FILE_PREFIX}' and mimeType = 'application/json' and trashed = false`
  );
  const url = `https://www.googleapis.com/drive/v3/files?q=${query}&fields=files(id,name,modifiedTime,size)&orderBy=modifiedTime desc&pageSize=10`;

  const response = await fetch(url, {
    headers: {
      Authorization: `Bearer ${accessToken}`,
    },
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Không thể tải danh sách bản sao lưu Google Drive (${response.status}): ${errText}`);
  }

  const data = await response.json();
  return Array.isArray(data.files) ? data.files : [];
}

export async function uploadBackupToDrive(
  accessToken: string,
  payload: ChronoFlowBackupPayload,
  existingFileId?: string
): Promise<DriveBackupFile> {
  const dateTag = new Date().toISOString().slice(0, 10);
  const fileName = `${BACKUP_FILE_PREFIX}${dateTag}.json`;

  const metadata = {
    name: fileName,
    mimeType: 'application/json',
    description: 'Bản sao lưu dữ liệu lịch trình, mục tiêu và bộ nhớ AI từ ứng dụng ChronoFlow Android.',
  };

  const boundary = '-------ChronoFlowDriveBoundary7MA4YWxkTrZu0gW';
  const delimiter = `\r\n--${boundary}\r\n`;
  const closeDelimiter = `\r\n--${boundary}--`;

  const multipartBody =
    delimiter +
    'Content-Type: application/json; charset=UTF-8\r\n\r\n' +
    JSON.stringify(metadata) +
    delimiter +
    'Content-Type: application/json; charset=UTF-8\r\n\r\n' +
    JSON.stringify(payload, null, 2) +
    closeDelimiter;

  const endpoint = existingFileId
    ? `https://www.googleapis.com/upload/drive/v3/files/${existingFileId}?uploadType=multipart&fields=id,name,modifiedTime,size`
    : 'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,modifiedTime,size';

  const method = existingFileId ? 'PATCH' : 'POST';

  const response = await fetch(endpoint, {
    method,
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': `multipart/related; boundary=${boundary}`,
    },
    body: multipartBody,
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Sao lưu lên Google Drive thất bại (${response.status}): ${errText}`);
  }

  return await response.json();
}

export async function downloadBackupFromDrive(
  accessToken: string,
  fileId: string
): Promise<ChronoFlowBackupPayload> {
  const url = `https://www.googleapis.com/drive/v3/files/${fileId}?alt=media`;
  const response = await fetch(url, {
    headers: {
      Authorization: `Bearer ${accessToken}`,
    },
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Không thể tải tệp sao lưu từ Google Drive (${response.status}): ${errText}`);
  }

  return await response.json();
}

export async function deleteBackupFromDrive(
  accessToken: string,
  fileId: string
): Promise<void> {
  const url = `https://www.googleapis.com/drive/v3/files/${fileId}`;
  const response = await fetch(url, {
    method: 'DELETE',
    headers: {
      Authorization: `Bearer ${accessToken}`,
    },
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Không thể xóa tệp sao lưu trên Google Drive (${response.status}): ${errText}`);
  }
}
