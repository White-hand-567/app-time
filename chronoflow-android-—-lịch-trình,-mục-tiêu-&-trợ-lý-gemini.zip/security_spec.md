# Firestore Security Specification (Phase 0 TDD)

## 1. Data Invariants

1. **Zero-Trust Ownership (`userId == request.auth.uid`)**: Every document in `/tasks/{taskId}`, `/goals/{goalId}`, `/ai_memories/{memoryId}`, and `/user_settings/{userId}` belongs strictly to a single authenticated and email-verified user (`request.auth.token.email_verified == true`). Cross-user reads, lists, creates, updates, or deletes are strictly prohibited.
2. **Strict Schema & Key Allowlisting (`hasAll` & `hasOnly`)**: Every `create` and `update` operation must pass its entity validation helper (`isValidScheduleTask`, `isValidGoalItem`, `isValidAIMemoryItem`, `isValidUserSettings`) enforcing exact required/allowed keys, string `.size()` bounds, numeric boundaries, and regex patterns matching `firebase-blueprint.json`.
3. **Path Variable Hardening (`isValidId`)**: Document path IDs (`{taskId}`, `{goalId}`, `{memoryId}`, `{userId}`) on single-document operations (`get`, `create`, `update`, `delete`) must satisfy `^[a-zA-Z0-9_\-]+$` with length `1..128`.
4. **Temporal & Identity Immutability**:
   - `createdAt == request.time` and `updatedAt == request.time` on `create`.
   - `createdAt == existing().createdAt`, `userId == existing().userId`, and `updatedAt == request.time` on `update`.
5. **Secure List Queries**: All `allow list` rules explicitly verify `resource.data.userId == request.auth.uid` without `get()`/`exists()` calls.

## 2. The "Dirty Dozen" Payloads

1. **Payload 1 (Identity Spoofing on Task Create)**: `userId: "victim_uid"` while authenticated as `"attacker_uid"`. -> `PERMISSION_DENIED`
2. **Payload 2 (Unverified Email Write)**: Valid task payload sent by user with `email_verified: false`. -> `PERMISSION_DENIED`
3. **Payload 3 (Shadow Field Injection on Task Create)**: Task payload including unauthorized `"isAdmin": true` ghost field. -> `PERMISSION_DENIED`
4. **Payload 4 (Resource Poisoning / Oversized Title)**: `title` with 5,000 characters (exceeds `maxLength: 200`). -> `PERMISSION_DENIED`
5. **Payload 5 (ID Poisoning)**: Document ID containing spaces or special characters (`task/../admin`). -> `PERMISSION_DENIED`
6. **Payload 6 (Client Timestamp Forgery on Create)**: `createdAt` set to a past timestamp instead of `request.time`. -> `PERMISSION_DENIED`
7. **Payload 7 (Immutable Field Mutation on Update)**: Changing `userId` or `createdAt` during an update to `/tasks/{taskId}`. -> `PERMISSION_DENIED`
8. **Payload 8 (Value Poisoning on Update)**: Updating `priority` to `"super_urgent"` (not in `['high', 'medium', 'low']`). -> `PERMISSION_DENIED`
9. **Payload 9 (Unauthorized Cross-User Read)**: User A calling `get` on User B's `/ai_memories/{memoryId}` document. -> `PERMISSION_DENIED`
10. **Payload 10 (Unconstrained List Scraping)**: User A querying `/tasks` without `where('userId', '==', auth.uid)`. -> `PERMISSION_DENIED`
11. **Payload 11 (Invalid Date/Time Format)**: Creating a task with `date: "05-11-2026"` or `startTime: "25:99"`. -> `PERMISSION_DENIED`
12. **Payload 12 (Shadow Key on Update)**: Updating `/user_settings/{userId}` with an extra key `role: "admin"` not in `affectedKeys()`. -> `PERMISSION_DENIED`
