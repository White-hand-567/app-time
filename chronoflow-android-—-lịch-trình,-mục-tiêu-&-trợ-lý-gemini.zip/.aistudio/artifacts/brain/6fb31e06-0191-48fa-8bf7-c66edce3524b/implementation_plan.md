# ChronoFlow Android — Ứng Dụng Quản Lý Thời Gian Biểu, Mục Tiêu & Trợ Lý Lịch Trình Thông Minh (APK / Android)

Ứng dụng cá nhân hóa chuyên biệt dành cho Android giúp lập thời gian biểu linh hoạt (Ngày, Nhiều ngày, Tuần, Tháng), theo dõi mục tiêu dài hạn, duy trì chuỗi công việc tối thiểu hằng ngày (Streak), thống kê hiệu suất tuần, đồng bộ đám mây đa thiết bị qua tài khoản cá nhân (Firebase + Google Drive) và tự động tối ưu hoặc điều chỉnh lịch trình cùng Gemini AI với **Bộ nhớ Ngữ cảnh Cá nhân (AI Memory)** giúp ghi nhớ mọi thói quen, thời gian di chuyển cố định mà không cần nhập lại.

### User Review & Critical Decisions

> [!IMPORTANT]
> Dưới đây là các quyết định cốt lõi đã được thống nhất (bao gồm cập nhật mới nhất về Bộ nhớ Ngữ cảnh cho Gemini):

- **Quyết định 1 — Kiến trúc Android APK & Trải nghiệm Di động**: Thiết kế với **giao diện Android Native 100%** (chuẩn Material You, điều hướng ngón cái một tay, cử chỉ chạm mượt mà), tích hợp chuẩn **Android Web APK (PWA Standalone + TWA/Capacitor Config Generator)** để cài đặt trực tiếp lên màn hình chính Android toàn màn hình hoặc xuất gói cấu hình đóng gói `.apk`.
- **Quyết định 2 — Cơ chế Đồng bộ Đa thiết bị & Sao lưu Đám mây**: Kết hợp **Firebase Authentication & Firestore** để đồng bộ dữ liệu thời gian thực tức thời khi đăng nhập tài khoản Google cá nhân trên nhiều thiết bị, đồng thời tích hợp **Google Drive API (`drive.file`)** để sao lưu và khôi phục bản chụp dữ liệu (Backup Snapshot) an toàn trên Google Drive của riêng bạn.
- **Quyết định 3 — Hệ thống Widget Màn hình chính (2x2, 4x2, 4x4)**: Cung cấp **Trình quản lý & Xem trước Widget trực quan** ngay trong ứng dụng với 3 kích thước chuẩn Android (`2x2` Chuỗi Streak & Việc tối thiểu, `4x2` Lịch trình & Báo cáo sự cố nhanh cho Gemini, `4x4` Bảng điều khiển ngày & Tiến độ mục tiêu) kèm chế độ "Ghim màn hình chính / Chế độ Launcher".
- **Quyết định 4 — Quy trình Gemini AI Điều chỉnh Sự cố**: Sử dụng mô hình miễn phí tốc độ cao `gemini-3.8-flash`. Khi bạn báo cáo sự cố không hoàn thành nhiệm vụ, Gemini sẽ phân tích nguyên nhân, tính toán khối lượng công việc tồn đọng và **hiển thị bản so sánh lịch trình đề xuất mới (Trước / Sau)** để bạn duyệt trước khi chính thức áp dụng.
- **Quyết định 5 (Mới cập nhật) — Bộ nhớ Ngữ cảnh & Quy tắc Cá nhân cho Gemini (AI Context Memory)**: Tích hợp kho lưu trữ **Thông tin & Ràng buộc Cố định** (ví dụ: *"Đi học tốn 20 phút tới trường"*, *"Nghỉ trưa từ 12:00 đến 13:00"*, *"Tối thứ 3 và thứ 5 bận học thêm"*). Mọi thông tin này sẽ **tự động đính kèm vào Gemini** mỗi khi lập lịch mới hoặc điều chỉnh sự cố để bạn không bao giờ phải gõ lại. Bạn có thể quản lý dễ dàng: **Thêm mới, Chỉnh sửa, Bật/Tắt tạm thời hoặc Xóa bỏ** bất cứ lúc nào, đồng thời Gemini cũng tự động gợi ý lưu các thông tin mới phát sinh từ lời nhắc của bạn.

---

### 1. Overview & Core Concept

- **Chức năng cốt lõi**:
  - **Quản lý thời gian biểu đa chiều**: Chuyển đổi tức thì giữa chế độ xem **Ngày (Timeline theo giờ)**, **Nhiều ngày (3 ngày liên tiếp)**, **Tuần (Lưới 7 ngày)** và **Tháng (Tổng quan lịch)**.
  - **Công việc tối thiểu hằng ngày (Minimum Daily Non-negotiables) & Chuỗi (Streak)**: Thiết lập các việc bắt buộc mỗi ngày, tự động tính chuỗi ngày hoàn thành liên tiếp (Streak), lưu lịch sử chuỗi và đính kèm **Ghi chú chi tiết (Notes)** cho từng nhiệm vụ.
  - **Lập kế hoạch Mục tiêu & Kho lưu trữ Thành tựu**: Chia mục tiêu lớn thành các cột mốc định kỳ hàng ngày, theo dõi phần trăm hoàn thành và lưu danh sách các mục tiêu đã chinh phục.
  - **Trợ lý Gemini AI thông minh kèm Bộ nhớ Ngữ cảnh Cá nhân (AI Memory)**:
    - Lưu trữ danh sách các quy tắc cá nhân, thời gian di chuyển (ví dụ: 20 phút đi tới trường), khung giờ sinh hoạt cố định và thói quen làm việc.
    - Tự động chèn các quy tắc đang bật vào mọi yêu cầu lập kế hoạch hoặc xử lý sự cố (ví dụ: khi xếp lịch đi học lúc 07:30, Gemini tự động chừa 20 phút di chuyển từ 07:10–07:30 mà không cần nhắc lại).
    - Cho phép cập nhật, bật/tắt hoặc xóa từng mục ghi nhớ chỉ với 1 chạm; tự động đồng bộ Bộ nhớ AI này qua Firebase và Google Drive.
  - **Biểu đồ hiệu suất hàng tuần**: Phân tích tỷ lệ hoàn thành công việc, thời lượng tập trung theo danh mục, điểm duy trì chuỗi ngày và xu hướng năng suất 7 ngày qua.
  - **Thông báo đẩy & Nhắc nhở**: Tích hợp hệ thống Notification API kết hợp Service Worker và bộ hẹn giờ chủ động để phát thông báo kèm âm báo cho các công việc quan trọng.
- **Đối tượng sử dụng**: Thiết kế tối ưu riêng cho cá nhân bạn sử dụng hằng ngày trên điện thoại Android và đồng bộ liền mạch khi mở trên máy tính bảng hoặc thiết bị phụ.
- **Giá trị mang lại**: Loại bỏ cảm giác đứt gãy kế hoạch khi có sự cố phát sinh và tiết kiệm tối đa thời gian nhập liệu nhờ Bộ nhớ Ngữ cảnh thông minh của Gemini, đồng thời bảo vệ dữ liệu tuyệt đối trên đám mây.

---

### 2. User Experience & Visual Design

- **Luồng trải nghiệm người dùng chính (Key User Flows)**:
  1. **Khởi động & Đồng bộ**: Đăng nhập bằng tài khoản Google cá nhân -> Dữ liệu lịch trình, chuỗi thói quen, mục tiêu và **Bộ nhớ Ngữ cảnh AI** tự động đồng bộ từ Firebase; hiển thị trạng thái sao lưu Google Drive.
  2. **Quản lý Lịch trình & Việc tối thiểu trong ngày**: Xem thanh cuộn ngày ngang và chuyển đổi linh hoạt Ngày / 3 Ngày / Tuần / Tháng -> Đánh dấu hoàn thành công việc tối thiểu để tăng số ngày Streak -> Mở ngăn kéo (Bottom Sheet) để viết ghi chú chi tiết hoặc đặt giờ nhắc nhở.
  3. **Quản lý Bộ nhớ Ngữ cảnh & Lập lịch tự động cùng Gemini**:
     - Trong tab **AI Điều phối**, mở mục **"Bộ nhớ & Quy tắc cố định"** để xem các thẻ thông tin đã lưu (ví dụ: *"Đi học tốn 20 phút tới trường"*, phân loại theo Di chuyển / Giờ cố định / Thói quen).
     - Người dùng có thể thêm nhanh quy tắc mới, bấm sửa nội dung, gạt nút Bật/Tắt (nếu nghỉ hè không cần tính giờ đi học) hoặc xóa hẳn khi không còn cần thiết.
     - Khi nhập yêu cầu mới, nếu phát hiện thông tin có tính lặp lại (như thời gian di chuyển mới), ứng dụng có nút **"Lưu vào Bộ nhớ AI"** chỉ với 1 chạm để lần sau không phải gõ lại.
  4. **Báo cáo sự cố & Tái lập lịch (Incident Rescheduling)**: Nhấn nút "Báo sự cố" trên nhiệm vụ bị trễ hoặc từ Widget -> Chọn nhanh các mẫu lý do có sẵn hoặc nhập ngắn gọn -> Gemini kết hợp **lịch trình hiện tại + Bộ nhớ Ngữ cảnh cố định** để sinh bản đề xuất điều chỉnh lịch trình tiếp theo -> Người dùng xem bảng đối chiếu Trước/Sau và nhấn "Xác nhận cập nhật".
  5. **Theo dõi Mục tiêu & Thống kê Tuần**: Kiểm tra tiến độ định kỳ hàng ngày của từng mục tiêu, chuyển mục tiêu đạt 100% vào "Nhật ký Thành tựu", và xem biểu đồ hiệu suất cá nhân hàng tuần.
  6. **Tùy chỉnh Widget & Xuất APK**: Xem trước và tương tác trực tiếp với các mẫu Widget Android `2x2`, `4x2`, `4x4`, ghim chế độ Widget nhanh hoặc tải cấu hình đóng gói APK Android.

- **Định hướng Thẩm mỹ & Giao diện (Visual Identity & Theme)**:
  - *Phong cách thiết kế*: **Tactile Android Utility (Chuẩn công thái học di động Material You hiện đại)** — tập trung vào thao tác một tay (vùng ngón cái 40% dưới màn hình), nút bấm chạm tối thiểu `44x44px`, bo góc mềm mại (`rounded-2xl` / `rounded-3xl`) và phân tách không gian rõ ràng.
  - *Bảng màu & Chế độ Tối (Dark Mode ưu tiên giảm mỏi mắt)*:
    - **Chế độ Tối (OLED Comfort Dark - Mặc định ban đêm)**: Nền chính `#0B0F17` (`slate-950`), bề mặt thẻ `#111827` (`slate-900`) giúp dịu mắt tuyệt đối trong đêm, chữ chính `#F8FAFC`, chữ phụ `#94A3B8`.
    - **Chế độ Sáng (Daylight Crisp)**: Nền chính `#F8FAFC` (`slate-50`), bề mặt thẻ `#FFFFFF`, chữ chính `#0F172A`, chữ phụ `#475569`.
    - **Màu nhấn chức năng (10% Accent Budget)**: Xanh Indigo năng lượng `#6366F1` cho hành động chính & Gemini AI; Xanh Ngọc lục bảo `#10B981` cho mục tiêu hoàn thành; Cam Hổ phách `#F59E0B` cho chuỗi ngày (Streak) & cảnh báo sự cố.
  - *Typography & Hệ thống chữ*:
    - Font tiêu đề & điều hướng: `Plus Jakarta Sans` (rõ nét, hiện đại trên màn hình Android).
    - Font nội dung & ghi chú: `DM Sans` (dễ đọc ở kích thước nhỏ).
    - Font số liệu, giờ giấc & chuỗi Streak: `JetBrains Mono` với thuộc tính `tabular-nums` giúp các con số thống kê và khung giờ thẳng hàng tuyệt đối.
  - *Bố cục & Quy tắc hiển thị*:
    - Thanh điều hướng dưới cùng cố định (Bottom Navigation Bar) gồm 5 tab cốt lõi: **Lịch trình**, **Mục tiêu & Streak**, **AI Điều phối**, **Thống kê**, **Widget & Đám mây**.
    - Tổng chiều cao thanh tiêu đề trên và thanh điều hướng dưới luôn $\le 15\%$ chiều cao màn hình để tối ưu không gian vuốt nội dung.

- **Phản hồi Tương tác & Chuyển động**:
  - Chuyển đổi khung nhìn (Ngày / Nhiều ngày / Tuần / Tháng) và đóng/mở Bottom Sheet mượt mà trong $\le 200\text{ms}$.
  - Hiệu ứng xác nhận trực quan khi hoàn thành đủ "Công việc tối thiểu hằng ngày" và nâng cấp chuỗi Streak.

---

### 3. Key Product Decisions & Trade-Offs

- **Quyết định 1: Kiến trúc Lưu trữ Kép (Local-First + Firebase Realtime + Google Drive Snapshot)**
  - *Phương án lựa chọn*: Lưu tức thời trên bộ nhớ thiết bị kết hợp đồng bộ tự động qua **Firebase Firestore** (khi có mạng và đã đăng nhập) và cho phép tạo/khôi phục file sao lưu JSON trên **Google Drive** (bao gồm cả Bộ nhớ Ngữ cảnh AI).
  - *Lý do*: Đảm bảo ứng dụng mở lên tức thì kể cả khi mất mạng (Offline-first cho Android APK), đồng bộ thời gian thực giữa nhiều thiết bị nhờ Firestore, đồng thời có bản sao lưu vật lý an toàn trong Google Drive cá nhân của bạn.
- **Quyết định 2: Bộ nhớ Ngữ cảnh Bền vững cho Gemini (Persistent AI Context Injection)**
  - *Phương án lựa chọn*: Tách riêng các quy tắc cố định của người dùng thành danh sách các mục ngữ cảnh (`AIMemoryNote`) có trạng thái `isActive`. Khi gọi API `/api/gemini/plan` hoặc `/api/gemini/reschedule`, ứng dụng tự động tổng hợp toàn bộ các quy tắc đang bật vào `systemInstruction` của Gemini.
  - *Lý do*: Giúp bạn chỉ cần nhập một lần duy nhất các thông tin như *"Đi học tốn 20 phút tới trường"*, tiết kiệm thời gian gõ phím trên điện thoại và cho phép kiểm soát minh bạch (sửa/xóa/tắt từng quy tắc dễ dàng hơn so với việc để AI tự nhớ ngầm trong lịch sử chat dài).
- **Quyết định 3: Cơ chế Phê duyệt Lịch trình từ Gemini AI (Human-in-the-Loop)**
  - *Phương án lựa chọn*: Mọi thay đổi lịch trình do Gemini tạo ra (dù là lập lịch mới hay điều chỉnh do sự cố) đều hiển thị ở trạng thái "Bản nháp đề xuất" kèm lý do giải thích của AI (ví dụ: *"Đã tự động cộng 20 phút di chuyển tới trường theo Bộ nhớ của bạn"*), chỉ ghi đè vào lịch chính thức khi bạn nhấn xác nhận.
  - *Lý do*: Tránh việc AI tự ý xáo trộn các khung giờ cố định quan trọng của bạn mà chưa được kiểm duyệt.

---

### 4. Technical Architecture & Data Strategy *(Technical Reference)*

- **Sơ đồ Kiến trúc Hệ thống & Luồng Dữ liệu**:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                   GIAO DIỆN ANDROID MOBILE & PWA / APK SHELL                │
│  ┌──────────────┐ ┌──────────────┐ ┌────────────────┐ ┌──────────────────┐  │
│  │ Lịch Trình   │ │ Mục Tiêu &   │ │ Trợ Lý AI,     │ │ Biểu Đồ Tuần,    │  │
│  │ Đa Chiều     │ │ Việc Tối     │ │ Bộ Nhớ Ngữ Cảnh│ │ Widget (2x2/4x2/ │  │
│  │ (Ngày/3Ngày/ │ │ Thiểu Hàng   │ │ Cố Định &      │ │ 4x4), Sao Lưu    │  │
│  │ Tuần/Tháng)  │ │ Ngày (Streak)│ │ Báo Sự Cố      │ │ Drive & Xuất APK │  │
│  └──────┬───────┘ └──────┬───────┘ └───────┬────────┘ └────────┬─────────┘  │
│         └────────────────┴────────┬────────┴───────────────────┘            │
│                                   ▼                                         │
│         ┌─────────────────────────────────────────────────────────┐         │
│         │     TRUNG TÂM QUẢN LÝ TRẠNG THÁI & THÔNG BÁO ĐẨY        │         │
│         │ (State Store + AI Context Vault + Notification Engine)  │         │
│         └────────┬───────────────────┬───────────────────┬────────┘         │
└──────────────────┼───────────────────┼───────────────────┼──────────────────┘
                   │                   │                   │
                   ▼                   ▼                   ▼
     ┌───────────────────────┐ ┌───────────────┐ ┌────────────────────────┐
     │   FIREBASE CLOUD      │ │ GOOGLE DRIVE  │ │  EXPRESS SERVER PROXY  │
     │ (Auth + Firestore DB) │ │   REST API    │ │   (/api/gemini/*)      │
     │ Đồng bộ Lịch, Mục tiêu│ │ (drive.file)  │ │  Model: gemini-3.8-    │
     │ & Bộ nhớ AI đa thiết  │ │ Sao lưu/Khôi  │ │  flash + Tự động nạp   │
     │ bị theo tài khoản     │ │ phục đám mây  │ │  Bộ nhớ Ngữ cảnh AI    │
     └───────────────────────┘ └───────────────┘ └────────────────────────┘
```

- **Mô hình Dữ liệu Cốt lõi (Data Entities)**:
  - **Công việc & Lịch trình (`ScheduleTask`)**: Định danh, tiêu đề, ghi chú chi tiết (`notes`), ngày thực hiện, khung giờ bắt đầu/kết thúc, mức độ ưu tiên, trạng thái hoàn thành, đánh dấu "Công việc tối thiểu hằng ngày" (`isMinimumDaily`), số chuỗi ngày liên tiếp (`currentStreak`, `bestStreak`), lịch sử ngày hoàn thành, cài đặt giờ nhắc nhở (`reminderTime`) và nhật ký sự cố.
  - **Bộ nhớ Ngữ cảnh & Quy tắc Cá nhân (`AIMemoryItem`)**: Định danh, nội dung quy tắc (ví dụ: *"Đi học tốn 20 phút di chuyển tới trường"*), phân loại (`commute` Di chuyển, `routine` Sinh hoạt cố định, `preference` Sở thích/Năng lượng, `constraint` Ràng buộc khác), trạng thái kích hoạt (`isActive: boolean`), thời gian tạo và cập nhật.
  - **Mục tiêu Cá nhân (`GoalItem`)**: Định danh, tên mục tiêu, mô tả, hạn hoàn thành, chỉ tiêu định kỳ hàng ngày (`dailyTarget`), tiến độ hiện tại (`progress`), trạng thái (`active` hoặc `achieved`), thời điểm đạt mục tiêu (`achievedAt`) và danh sách các nhiệm vụ con liên kết.
  - **Báo cáo Sự cố & Đề xuất AI (`IncidentReport`)**: Nhiệm vụ gặp sự cố, mô tả nguyên nhân, thời điểm phát sinh, danh sách các thay đổi lịch trình do Gemini đề xuất đang chờ xác nhận, và các gợi ý quy tắc mới Gemini đề xuất lưu thêm vào `AIMemoryItem`.
  - **Cấu hình Cá nhân & Widget (`UserSettings`)**: Giao diện Sáng/Tối, cấu hình bật/tắt thông báo đẩy, bố cục Widget ưu tiên (`2x2`, `4x2`, `4x4`) và lịch sử đồng bộ Google Drive gần nhất.

- **Ánh xạ Tương tác & Xử lý Trạng thái (Interactive Component & State Mapping)**:
  - **Trình quản lý Bộ nhớ AI (AI Context Memory Manager)**:
    - Hiển thị danh sách các thẻ `AIMemoryItem` ngay trong màn hình Trợ lý Gemini.
    - Cung cấp thanh nhập nhanh kèm các mẫu gợi ý (Thời gian di chuyển, Giờ ăn/ngủ, Khung giờ tập trung) và nút chỉnh sửa trực tiếp (`Edit`), công tắc bật/tắt (`Toggle Active`) hoặc nút xóa (`Delete`) cho từng thẻ.
    - Mọi thao tác thêm/sửa/xóa `AIMemoryItem` đều được lưu tức thời vào bộ nhớ cục bộ, đồng bộ lên collection `ai_memories` trong Firestore và đóng gói chung vào bản sao lưu Google Drive.
  - **Bộ chuyển đổi khung nhìn Lịch (Ngày / 3 Ngày / Tuần / Tháng)**: Lọc và nhóm danh sách `ScheduleTask` theo dải ngày tương ứng; cho phép chạm vào từng ô giờ hoặc ngày để thêm nhanh nhiệm vụ hoặc mở chi tiết ghi chú.
  - **Trình theo dõi Việc tối thiểu & Chuỗi (Streak Engine)**: Khi người dùng đánh dấu hoàn thành một nhiệm vụ tối thiểu hoặc định kỳ hàng ngày, hệ thống kiểm tra ngày liền kề trước đó để cộng dồn chuỗi Streak, cập nhật tiến độ mục tiêu liên kết và đồng bộ tức thì lên Firestore.
  - **Trình xử lý Sự cố & Lập lịch Gemini (`/api/gemini/reschedule` & `/api/gemini/plan`)**: Tự động đính kèm mảng `AIMemoryItem` đang bật cùng danh sách công việc hiện tại lên máy chủ; nhận về mảng lịch trình điều chỉnh (đã tính toán sẵn thời gian di chuyển/ràng buộc đã lưu) kèm gợi ý quy tắc mới (nếu có) để người dùng nhấn **"Xác nhận áp dụng"**.
  - **Hệ thống Sao lưu Google Drive & Xuất APK**: Kiểm tra quyền OAuth `drive.file`, hiển thị hộp thoại xác nhận rõ ràng trước khi ghi đè hoặc khôi phục bản sao lưu trên Google Drive, đồng thời cung cấp trình tải gói cấu hình Android APK.
