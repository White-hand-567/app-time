/**
 * Firestore Security Rules Verification Specification
 * Tests all Dirty Dozen adversarial payloads against firestore.rules invariants.
 */

export interface SecurityTestCase {
  id: number;
  name: string;
  collection: string;
  operation: 'get' | 'list' | 'create' | 'update' | 'delete';
  expectedResult: 'PERMISSION_DENIED' | 'ALLOWED';
}

export const DIRTY_DOZEN_TESTS: SecurityTestCase[] = [
  { id: 1, name: 'Identity Spoofing on Task Create', collection: 'tasks', operation: 'create', expectedResult: 'PERMISSION_DENIED' },
  { id: 2, name: 'Unverified Email Write', collection: 'tasks', operation: 'create', expectedResult: 'PERMISSION_DENIED' },
  { id: 3, name: 'Shadow Field Injection on Task Create', collection: 'tasks', operation: 'create', expectedResult: 'PERMISSION_DENIED' },
  { id: 4, name: 'Oversized Title String Poisoning', collection: 'tasks', operation: 'create', expectedResult: 'PERMISSION_DENIED' },
  { id: 5, name: 'Path Variable ID Poisoning', collection: 'tasks', operation: 'create', expectedResult: 'PERMISSION_DENIED' },
  { id: 6, name: 'Client Timestamp Forgery on Create', collection: 'tasks', operation: 'create', expectedResult: 'PERMISSION_DENIED' },
  { id: 7, name: 'Immutable Field Mutation on Update', collection: 'tasks', operation: 'update', expectedResult: 'PERMISSION_DENIED' },
  { id: 8, name: 'Enum Value Poisoning on Update', collection: 'tasks', operation: 'update', expectedResult: 'PERMISSION_DENIED' },
  { id: 9, name: 'Unauthorized Cross-User Read on AI Memory', collection: 'ai_memories', operation: 'get', expectedResult: 'PERMISSION_DENIED' },
  { id: 10, name: 'Unconstrained List Scraping on Goals', collection: 'goals', operation: 'list', expectedResult: 'PERMISSION_DENIED' },
  { id: 11, name: 'Malformed Date Regex Injection', collection: 'tasks', operation: 'create', expectedResult: 'PERMISSION_DENIED' },
  { id: 12, name: 'Shadow Key on UserSettings Update', collection: 'user_settings', operation: 'update', expectedResult: 'PERMISSION_DENIED' },
];
