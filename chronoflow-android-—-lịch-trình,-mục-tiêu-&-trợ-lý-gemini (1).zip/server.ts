import 'dotenv/config';
import dns from 'dns';
import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type, ThinkingLevel } from '@google/genai';
import {
  parseClassTimetableFromBenCatExcel,
  normalizeBenCatClassName,
  THPT_BENCAT_EXCEL_FILES,
} from './src/data/thptBenCatExcelParser';

// Force IPv4 first so thptbencat.edu.vn and Google Sheets CSV export resolve without IPv6 timeout
dns.setDefaultResultOrder('ipv4first');

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = 3000;

function getGenAIClient(): GoogleGenAI {
  return new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

const FALLBACK_TEXT_MODELS = [
  'gemini-3.8-flash',
  'gemini-3.1-flash-lite',
  'gemini-flash-latest',
] as const;

async function generateWithModelFallback(
  ai: GoogleGenAI,
  params: {
    contents: unknown;
    config?: Record<string, unknown>;
  }
) {
  let lastErr: unknown = null;
  for (const modelName of FALLBACK_TEXT_MODELS) {
    try {
      const modelConfig: Record<string, unknown> = {
        ...(params.config || {}),
      };
      if (modelName === 'gemini-3.8-flash' && !modelConfig.thinkingConfig) {
        modelConfig.thinkingConfig = {
          thinkingLevel: ThinkingLevel.LOW,
        };
      }

      const response = await Promise.race([
        ai.models.generateContent({
          model: modelName,
          contents: params.contents as string,
          config: modelConfig,
        }),
        new Promise<never>((_, reject) =>
          setTimeout(() => reject(new Error(`Timeout on ${modelName}`)), 18000)
        ),
      ]);
      return response;
    } catch (err: unknown) {
      lastErr = err;
      const errMsg = err instanceof Error ? err.message : String(err);
      console.warn(`[Gemini Fallback] Model ${modelName} failed (${errMsg.slice(0, 120)}), trying next...`);
    }
  }
  throw lastErr;
}

function unwrapRedirectUrl(rawInput: string): string {
  const trimmed = (rawInput || '').trim();
  if (!trimmed) return '';
  try {
    const withProto = /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
    const parsed = new URL(withProto);
    if (
      parsed.hostname.includes('google.') &&
      (parsed.pathname === '/url' || parsed.searchParams.has('q') || parsed.searchParams.has('url'))
    ) {
      const target = parsed.searchParams.get('q') || parsed.searchParams.get('url');
      if (target) return target.trim();
    }
    return withProto;
  } catch {
    const match = trimmed.match(/[?&](?:q|url)=([^&]+)/i);
    if (match && match[1]) {
      try {
        return decodeURIComponent(match[1]);
      } catch {
        return match[1];
      }
    }
    return trimmed;
  }
}

function inferSchoolTitleFromUrl(urlStr: string, classNote: string): string {
  const lower = urlStr.toLowerCase();
  if (lower.includes('thptbencat.edu.vn')) {
    return `Trường THPT Bến Cát (thptbencat.edu.vn)${classNote ? ` — ${classNote}` : ''}`;
  }
  try {
    const host = new URL(urlStr).hostname.replace(/^www\./, '');
    return `Cổng Thời Khóa Biểu (${host})${classNote ? ` — ${classNote}` : ''}`;
  } catch {
    return classNote || 'Cổng Thông Tin Thời Khóa Biểu Trường Học';
  }
}

function addDaysServerStr(dateStr: string, offset: number): string {
  const [y, m, d] = String(dateStr || new Date().toISOString().slice(0, 10))
    .split('-')
    .map(Number);
  const dt = new Date(y || new Date().getFullYear(), (m || 1) - 1, (d || 1) + offset);
  return `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, '0')}-${String(
    dt.getDate()
  ).padStart(2, '0')}`;
}

function parseRequestedGoalDays(
  rawText: string,
  explicitTargetDays?: number,
  aiSuggestedDays?: number
): number {
  const text = String(rawText || '').toLowerCase();
  let detected = 0;

  // 1. "hơn X tháng" -> X * 30 + 10 days (e.g. "hơn 1 tháng" -> 40 days)
  const overMonthMatch = text.match(/hơn\s*(\d+(?:[.,]\d+)?)\s*tháng/i);
  if (overMonthMatch) {
    const m = parseFloat(overMonthMatch[1].replace(',', '.'));
    if (!Number.isNaN(m)) detected = Math.max(detected, Math.round(m * 30) + 10);
  }

  // 2. "X tháng rưỡi" -> X * 30 + 15 days
  const halfMonthMatch = text.match(/(\d+)\s*tháng\s*rưỡi/i);
  if (halfMonthMatch) {
    const m = parseInt(halfMonthMatch[1], 10);
    if (!Number.isNaN(m)) detected = Math.max(detected, m * 30 + 15);
  }

  if (/nửa\s*tháng/i.test(text)) {
    detected = Math.max(detected, 15);
  }

  // 3. "X tháng" -> X * 30 days
  const monthMatch = text.match(/(\d+(?:[.,]\d+)?)\s*tháng/i);
  if (monthMatch) {
    const m = parseFloat(monthMatch[1].replace(',', '.'));
    if (!Number.isNaN(m)) detected = Math.max(detected, Math.round(m * 30));
  }

  // 4. "hơn X tuần" / "X tuần"
  const overWeekMatch = text.match(/hơn\s*(\d+)\s*tuần/i);
  if (overWeekMatch) {
    const w = parseInt(overWeekMatch[1], 10);
    if (!Number.isNaN(w)) detected = Math.max(detected, w * 7 + 4);
  }
  const weekMatch = text.match(/(\d+)\s*tuần/i);
  if (weekMatch) {
    const w = parseInt(weekMatch[1], 10);
    if (!Number.isNaN(w)) detected = Math.max(detected, w * 7);
  }

  // 5. "X ngày"
  const dayMatches = Array.from(text.matchAll(/(\d+)\s*ngày/gi));
  for (const dm of dayMatches) {
    const d = parseInt(dm[1], 10);
    if (!Number.isNaN(d)) detected = Math.max(detected, d);
  }

  const explicit = Number(explicitTargetDays) || 0;
  const aiDays = Number(aiSuggestedDays) || 0;
  const best = Math.max(detected, explicit, aiDays);
  return Math.min(180, Math.max(best, 0));
}

function pickConflictFreeSlotForDate(
  dateStr: string,
  lockedBlocks: Array<{ daysOfWeek?: number[]; startTime?: string; endTime?: string }>,
  preferredStart = '19:30',
  preferredEnd = '21:00'
): { startTime: string; endTime: string } {
  const [y, m, d] = dateStr.split('-').map(Number);
  const wd = new Date(y, m - 1, d).getDay();
  const dayLocks = (lockedBlocks || []).filter(
    (b) => Array.isArray(b.daysOfWeek) && b.daysOfWeek.includes(wd)
  );

  const toMins = (t: string) => {
    const [hh, mm] = String(t || '00:00').split(':').map(Number);
    return (hh || 0) * 60 + (mm || 0);
  };

  const candidateSlots = [
    { startTime: preferredStart || '19:30', endTime: preferredEnd || '21:00' },
    { startTime: '20:00', endTime: '21:30' },
    { startTime: '14:30', endTime: '16:00' },
    { startTime: '08:30', endTime: '10:00' },
  ];

  for (const slot of candidateSlots) {
    const s = toMins(slot.startTime);
    const e = toMins(slot.endTime);
    const hasConflict = dayLocks.some((lb) => {
      const ls = toMins(lb.startTime || '07:00') - 20;
      const le = toMins(lb.endTime || '11:15') + 20;
      return s < le && e > ls;
    });
    if (!hasConflict) return slot;
  }

  return { startTime: '19:30', endTime: '21:00' };
}

const PROGRESSIVE_ACTION_STAGES = [
  'Nắm vững lý thuyết & kiến thức cốt lõi',
  'Thực hành bài tập vận dụng cơ bản',
  'Rèn kỹ năng giải bài tập phân loại',
  'Luyện đề thực chiến & bấm giờ',
  'Tổng ôn, rà soát lỗi sai & củng cố',
];

function buildFullHorizonDeliverableSteps(params: {
  goalTitle: string;
  rawText: string;
  startDate: string;
  targetTotalDays: number;
  aiSteps: Array<{
    dayNumber?: number;
    date?: string;
    title?: string;
    notes?: string;
    startTime?: string;
    endTime?: string;
    freeTimeSummary?: string;
    isMinimumDaily?: boolean;
  }>;
  curriculumTopics?: string[];
  lockedBlocks?: Array<{ daysOfWeek?: number[]; startTime?: string; endTime?: string }>;
}) {
  const {
    goalTitle,
    rawText,
    startDate,
    targetTotalDays,
    aiSteps = [],
    curriculumTopics = [],
    lockedBlocks = [],
  } = params;

  // Extract concrete modules/topics from AI steps, curriculumTopics, or user's text lines
  const extractedTopics: string[] = [];
  for (const t of curriculumTopics) {
    if (t && String(t).trim()) extractedTopics.push(String(t).trim());
  }
  for (const s of aiSteps) {
    if (s?.title && String(s.title).trim()) {
      const clean = String(s.title)
        .replace(/^\[Hạng mục\s*\d+\/\d+\]\s*/i, '')
        .replace(/\s*—\s*Ngày\s*\d+.*$/i, '')
        .trim();
      if (clean && !extractedTopics.includes(clean)) {
        extractedTopics.push(clean);
      }
    }
  }

  if (extractedTopics.length === 0) {
    const textParts = String(rawText || '')
      .split(/[\n,;•\-]+/)
      .map((s) => s.trim())
      .filter((s) => s.length > 2);
    for (const p of textParts) {
      if (!extractedTopics.includes(p)) extractedTopics.push(p);
    }
  }

  if (extractedTopics.length === 0) {
    extractedTopics.push(goalTitle || 'Mục tiêu trọng tâm');
  }

  const totalDays = Math.max(
    1,
    targetTotalDays || aiSteps.length || extractedTopics.length || 7
  );

  // If AI already returned all days matching totalDays (and >= targetTotalDays), normalize dates and titles
  if (aiSteps.length >= totalDays && totalDays <= 15) {
    return aiSteps.slice(0, totalDays).map((step, idx) => {
      const dateStr = addDaysServerStr(startDate, idx);
      const slot = pickConflictFreeSlotForDate(
        dateStr,
        lockedBlocks,
        step.startTime || '19:30',
        step.endTime || '21:00'
      );
      const rawTitle = String(step.title || extractedTopics[idx % extractedTopics.length]).trim();
      const deliverableTitle = rawTitle.startsWith('[Hạng mục')
        ? rawTitle
        : `[Hạng mục ${idx + 1}/${totalDays}] ${rawTitle}`;
      return {
        dayNumber: idx + 1,
        date: dateStr,
        title: deliverableTitle,
        notes:
          step.notes ||
          `Hoàn thành hạng mục ${idx + 1}/${totalDays} · Khung linh hoạt (±20p), đã trừ hao đệm ăn uống/nghỉ ngơi`,
        startTime: slot.startTime,
        endTime: slot.endTime,
        freeTimeSummary:
          step.freeTimeSummary || 'Đã tự động chừa khoảng đệm sinh hoạt linh hoạt (±20-30 phút)',
        isMinimumDaily: Boolean(step.isMinimumDaily ?? idx === 0),
      };
    });
  }

  // Full-Horizon Multi-Week / Multi-Month Expansion (supports 15, 30, 45, 60, 90, up to 180 days!)
  const numTopics = extractedTopics.length;
  const daysPerTopic = Math.max(1, totalDays / numTopics);

  return Array.from({ length: totalDays }, (_, idx) => {
    const dateStr = addDaysServerStr(startDate, idx);
    const aiStep = aiSteps[idx];
    const slot = pickConflictFreeSlotForDate(
      dateStr,
      lockedBlocks,
      aiStep?.startTime || '19:30',
      aiStep?.endTime || '21:00'
    );

    const topicIndex = Math.min(numTopics - 1, Math.floor(idx / daysPerTopic));
    const topicName = extractedTopics[topicIndex];
    const subDayInTopic = idx - Math.floor(topicIndex * daysPerTopic);
    const stageAction =
      daysPerTopic >= 2
        ? PROGRESSIVE_ACTION_STAGES[subDayInTopic % PROGRESSIVE_ACTION_STAGES.length]
        : 'Hoàn thành trọn vẹn';

    let baseTitle = '';
    if (aiStep?.title && idx < aiSteps.length && aiSteps.length === totalDays) {
      baseTitle = String(aiStep.title).trim();
    } else if (daysPerTopic >= 2) {
      baseTitle = `${stageAction}: ${topicName}`;
    } else {
      baseTitle = topicName;
    }

    const cleanBase = baseTitle.replace(/^\[Hạng mục\s*\d+\/\d+\]\s*/i, '');
    const fullTitle = `[Hạng mục ${idx + 1}/${totalDays}] ${cleanBase}`;

    return {
      dayNumber: idx + 1,
      date: dateStr,
      title: fullTitle,
      notes:
        aiStep?.notes ||
        `Chỉ tiêu cần hoàn thành: ${cleanBase} (Mốc ${idx + 1}/${totalDays} · Khung giờ linh hoạt ±20p)`,
      startTime: slot.startTime,
      endTime: slot.endTime,
      freeTimeSummary:
        aiStep?.freeTimeSummary ||
        'Đã tự động chừa khoảng đệm ăn uống & nghỉ ngơi linh hoạt trước và sau ca học',
      isMinimumDaily: idx === 0,
    };
  });
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '15mb' }));

  // 1. Gemini Goal & Roadmap Auto-Distributor (Hỗ trợ lộ trình dài hạn > 1 tháng, 30-180 ngày & chia theo Hạng mục cần hoàn thành)
  app.post('/api/gemini/goal-roadmap', async (req, res) => {
    const {
      goalTitleInput = '',
      roadmapText = '',
      targetDurationDays = 0,
      fixedTimetableText = '',
      lockedBlocks = [],
      dailyHabits = [],
      startDate = new Date().toISOString().slice(0, 10),
      existingTasks = [],
      activeMemories = [],
    } = req.body || {};

    if (!roadmapText || typeof roadmapText !== 'string') {
      res.status(400).json({ error: 'Vui lòng nhập mục tiêu và lộ trình của bạn.' });
      return;
    }

    const combinedText = `${goalTitleInput} ${roadmapText}`;
    const requestedDaysFromUser = parseRequestedGoalDays(combinedText, Number(targetDurationDays));

    try {
      const ai = getGenAIClient();

      const lockedContext =
        Array.isArray(lockedBlocks) && lockedBlocks.length > 0
          ? lockedBlocks
              .map(
                (b: { title: string; daysOfWeek: number[]; startTime: string; endTime: string }) =>
                  `- [KHÓA CHẾT LẶP LẠI HÀNG TUẦN/THÁNG] "${b.title}": Khung giờ ${b.startTime} - ${b.endTime} vào các thứ [${(b.daysOfWeek || []).join(',')}] (0=CN, 1=T2..6=T7)`
              )
              .join('\n')
          : fixedTimetableText || 'Theo Bộ nhớ Ngữ cảnh';

      const habitsContext =
        Array.isArray(dailyHabits) && dailyHabits.length > 0
          ? dailyHabits
              .map(
                (h: { title: string; startTime: string; endTime: string }) =>
                  `- [VIỆC HÀNG NGÀY TỐI THIỂU] "${h.title}": Khoảng ${h.startTime} - ${h.endTime}`
              )
              .join('\n')
          : 'Chưa có việc hàng ngày tối thiểu.';

      const memoryContext =
        Array.isArray(activeMemories) && activeMemories.length > 0
          ? activeMemories
              .map((m: { category?: string; content: string }, i: number) => `${i + 1}. [${m.category || 'rule'}] ${m.content}`)
              .join('\n')
          : 'Chưa có quy tắc bổ sung.';

      const existingContext =
        Array.isArray(existingTasks) && existingTasks.length > 0
          ? existingTasks
              .slice(0, 20)
              .map(
                (t: { date: string; startTime: string; endTime: string; title: string; completed?: boolean }) =>
                  `- Ngày ${t.date}: ${t.startTime}-${t.endTime} | ${t.title} (${t.completed ? 'Đã hoàn thành' : 'Chưa xong'})`
              )
              .join('\n')
          : 'Chưa có nhiệm vụ nào.';

      const systemInstruction = `Bạn là Hệ thống AI Cá Nhân Hóa Tự Động Phân Bố Lộ Trình Mục Tiêu Dài Hạn (từ vài ngày đến 1-6 tháng).
NHIỆM VỤ CỐT LÕI:
1. Chia mục tiêu lớn của người dùng thành danh sách các HẠNG MỤC / CHUYÊN ĐỀ / ĐẦU VIỆC CỤ THỂ CẦN HOÀN THÀNH ("curriculumTopics", từ 8 đến 20 chuyên đề/bài học cụ thể theo thứ tự logic từ dễ đến khó) để tính % tiến độ dựa trên việc hoàn thành từng hạng mục thực tế (KHÔNG điểm danh ngày suông).
2. Xác định tổng số ngày thực hiện "totalDays" (nếu người dùng yêu cầu hơn 1 tháng / 30-90 ngày thì giữ đúng số ngày đó: ${requestedDaysFromUser > 0 ? requestedDaysFromUser : 'tự tính hợp lý theo độ lớn mục tiêu'}).
3. Trong "dailyPlan", liệt kê các hạng mục cụ thể đầu tiên (tối đa 10-14 mục đại diện, hệ thống máy chủ sẽ tự động trải đều toàn bộ "curriculumTopics" ra đủ 100% số ngày "totalDays" cho tới khi hoàn thành).
4. Tự động né Việc chết (giờ học trên trường, học thêm) và chừa đệm sinh hoạt linh hoạt (±20-30 phút). Trả về hoàn toàn bằng tiếng Việt theo đúng JSON schema.`;

      const prompt = `Ngày bắt đầu phân bổ: ${startDate}
Tên mục tiêu: "${goalTitleInput}"
Số ngày người dùng mong muốn phân bổ: ${requestedDaysFromUser > 0 ? `${requestedDaysFromUser} ngày` : 'Tự động theo khối lượng công việc'}

DANH SÁCH VIỆC CHẾT (TUYỆT ĐỐI NÉ):
${lockedContext}

DANH SÁCH VIỆC HÀNG NGÀY:
${habitsContext}

HỒ SƠ DỮ LIỆU CÁ NHÂN:
${memoryContext}

LỊCH SỬ NHIỆM VỤ ĐÃ CÓ:
${existingContext}

LỘ TRÌNH / MỤC TIÊU CẦN PHÂN BỐ:
"${roadmapText}"`;

      const response = await generateWithModelFallback(ai, {
        contents: prompt,
        config: {
          systemInstruction,
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              goalTitle: { type: Type.STRING },
              goalDescription: { type: Type.STRING },
              dailyTargetMinutes: { type: Type.INTEGER },
              totalDays: { type: Type.INTEGER },
              curriculumTopics: {
                type: Type.ARRAY,
                description:
                  'Danh sách 8-20 chuyên đề / bài học / hạng mục cụ thể cần hoàn thành của mục tiêu này',
                items: { type: Type.STRING },
              },
              strategyNote: {
                type: Type.STRING,
                description:
                  'Giải thích cách AI chia nhỏ mục tiêu thành các hạng mục cụ thể cần hoàn thành và phân bổ xuyên suốt toàn bộ số ngày.',
              },
              dailyPlan: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    dayNumber: { type: Type.INTEGER },
                    date: { type: Type.STRING },
                    title: { type: Type.STRING },
                    notes: { type: Type.STRING },
                    startTime: { type: Type.STRING },
                    endTime: { type: Type.STRING },
                    freeTimeSummary: { type: Type.STRING },
                    isMinimumDaily: { type: Type.BOOLEAN },
                  },
                  required: [
                    'dayNumber',
                    'date',
                    'title',
                    'notes',
                    'startTime',
                    'endTime',
                    'freeTimeSummary',
                    'isMinimumDaily',
                  ],
                },
              },
            },
            required: [
              'goalTitle',
              'goalDescription',
              'dailyTargetMinutes',
              'totalDays',
              'curriculumTopics',
              'strategyNote',
              'dailyPlan',
            ],
          },
        },
      });

      const parsed = JSON.parse((response.text ?? '{}').trim());
      const finalTotalDays = parseRequestedGoalDays(
        combinedText,
        Number(targetDurationDays),
        Number(parsed.totalDays) || (Array.isArray(parsed.dailyPlan) ? parsed.dailyPlan.length : 7)
      );

      const expandedPlan = buildFullHorizonDeliverableSteps({
        goalTitle: parsed.goalTitle || goalTitleInput || 'Mục tiêu lớn',
        rawText: roadmapText,
        startDate,
        targetTotalDays: finalTotalDays,
        aiSteps: Array.isArray(parsed.dailyPlan) ? parsed.dailyPlan : [],
        curriculumTopics: Array.isArray(parsed.curriculumTopics) ? parsed.curriculumTopics : [],
        lockedBlocks,
      });

      res.json({
        ...parsed,
        goalTitle: parsed.goalTitle || goalTitleInput || 'Lộ trình Mục tiêu Cá nhân',
        totalDays: expandedPlan.length,
        dailyPlan: expandedPlan,
      });
    } catch (error: unknown) {
      console.warn('Gemini Goal Roadmap fallback triggered:', error);
      const fallbackDays = Math.max(7, requestedDaysFromUser || 14);
      const expandedPlan = buildFullHorizonDeliverableSteps({
        goalTitle: goalTitleInput || 'Lộ trình Mục tiêu Cá nhân',
        rawText: roadmapText,
        startDate,
        targetTotalDays: fallbackDays,
        aiSteps: [],
        curriculumTopics: [],
        lockedBlocks,
      });

      res.json({
        goalTitle: String(goalTitleInput || roadmapText || 'Lộ trình Mục tiêu Cá nhân').slice(0, 120),
        goalDescription: `Phân bổ trọn vẹn ${expandedPlan.length} hạng mục công việc cụ thể cần hoàn thành`,
        dailyTargetMinutes: 90,
        totalDays: expandedPlan.length,
        strategyNote: `Hệ thống đã tự động chia mục tiêu thành ${expandedPlan.length} hạng mục cụ thể cần hoàn thành xuyên suốt ${expandedPlan.length} ngày (né lịch cố định & chừa đệm nghỉ ngơi).`,
        dailyPlan: expandedPlan,
      });
    }
  });

  // 2. NEW: AI Feedback & Self-Learning Endpoint (Người dùng nêu ý kiến -> AI sửa lịch ngay + tự học thói quen cá nhân + dự đoán khung giờ rảnh)
  app.post('/api/gemini/feedback-adjust', async (req, res) => {
    try {
      const {
        userFeedback,
        targetDate,
        dayTasks = [],
        lockedBlocks = [],
        dailyHabits = [],
        activeMemories = [],
      } = req.body || {};

      if (!userFeedback || typeof userFeedback !== 'string') {
        res.status(400).json({ error: 'Vui lòng nhập ý kiến hoặc phản hồi của bạn cho AI.' });
        return;
      }

      const ai = getGenAIClient();

      const tasksStr =
        Array.isArray(dayTasks) && dayTasks.length > 0
          ? dayTasks
              .map(
                (t: { id: string; title: string; date: string; startTime: string; endTime: string; notes?: string }) =>
                  `- ID: "${t.id}" | ${t.startTime}-${t.endTime}: ${t.title} (${t.notes || ''})`
              )
              .join('\n')
          : 'Chưa có ca học nào trong ngày này.';

      const locksStr =
        Array.isArray(lockedBlocks) && lockedBlocks.length > 0
          ? lockedBlocks
              .map(
                (b: { title: string; startTime: string; endTime: string; daysOfWeek: number[] }) =>
                  `- ${b.title}: ${b.startTime}-${b.endTime} (Thứ: ${b.daysOfWeek.join(',')})`
              )
              .join('\n')
          : 'Không có việc chết.';

      const habitsStr =
        Array.isArray(dailyHabits) && dailyHabits.length > 0
          ? dailyHabits
              .map((h: { title: string; startTime: string; endTime: string }) => `- ${h.title}: ${h.startTime}-${h.endTime}`)
              .join('\n')
          : 'Không có việc hàng ngày.';

      const memStr =
        Array.isArray(activeMemories) && activeMemories.length > 0
          ? activeMemories.map((m: { content: string }) => `- ${m.content}`).join('\n')
          : 'Chưa có dữ liệu học trước đó.';

      const systemInstruction = `Bạn là Trợ Lý AI Tự Học Thói Quen Cá Nhân (Personal Adaptive Scheduling AI).
Người dùng đang góp ý hoặc nêu thói quen thực tế của họ (ví dụ: giờ ăn uống không cố định mỗi ngày, việc lặt vặt buổi sáng/chiều, muốn nới lỏng giờ nghỉ, hoặc thích học vào khung giờ nào đó).
Nhiệm vụ của bạn:
1. Lắng nghe ý kiến người dùng và SỬA LẠI NGAY các nhiệm vụ trong ngày ${targetDate} ("updatedDayTasks") cho phù hợp, tự nhiên, có khoảng đệm linh hoạt (±20-30 phút) cho việc lặt vặt/ăn uống mà không bắt người dùng khai báo chi tiết.
2. ĐÚC KẾT QUY TẮC HỌC ĐƯỢC ("learnedHabitRule") để lưu vĩnh viễn vào Hồ sơ dữ liệu cá nhân, giúp từ lần sau người dùng KHÔNG CẦN NHẬP LẠI nữa.
3. DỰ ĐOÁN 2-3 KHUNG GIỜ RẢNH / HIỆU SUẤT CAO NHẤT ("predictedBestWindows") phù hợp nhất với nhịp sinh hoạt của người dùng để họ chỉ cần bấm 1 chạm khi xếp việc.
4. Trả về hoàn toàn bằng tiếng Việt theo đúng JSON schema.`;

      const prompt = `Ngày đang xem: ${targetDate}
Ý kiến / Góp ý của người dùng: "${userFeedback}"

Các ca học hiện tại trong ngày ${targetDate}:
${tasksStr}

Việc chết cố định:
${locksStr}

Việc hàng ngày:
${habitsStr}

Dữ liệu thói quen AI đã học trước đó:
${memStr}`;

      const response = await generateWithModelFallback(ai, {
        contents: prompt,
        config: {
          systemInstruction,
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              aiUnderstanding: {
                type: Type.STRING,
                description:
                  'Phản hồi ngắn gọn cho người dùng biết AI đã hiểu ý và đã điều chỉnh lịch + khoảng đệm việc vặt như thế nào.',
              },
              learnedHabitRule: {
                type: Type.STRING,
                description:
                  'Quy tắc thói quen cá nhân mới mà AI tự học được để lưu vào Bộ nhớ lâu dài (giúp lần sau người dùng không phải nhắc lại).',
              },
              learnedCategory: {
                type: Type.STRING,
                description: 'Một trong: commute, routine, energy, constraint',
              },
              predictedBestWindows: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    label: {
                      type: Type.STRING,
                      description: 'Tên khung giờ dự đoán (VD: Khung Vàng Ca Tối sau ăn nghỉ linh hoạt)',
                    },
                    startTime: { type: Type.STRING, description: 'HH:mm' },
                    endTime: { type: Type.STRING, description: 'HH:mm' },
                    confidencePct: {
                      type: Type.INTEGER,
                      description: 'Độ phù hợp dự đoán (80 - 98%)',
                    },
                    reason: {
                      type: Type.STRING,
                      description: 'Lý do AI dự đoán khung giờ này hợp với người dùng nhất',
                    },
                  },
                  required: ['label', 'startTime', 'endTime', 'confidencePct', 'reason'],
                },
              },
              updatedDayTasks: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    taskId: {
                      type: Type.STRING,
                      description: 'ID của task cũ nếu sửa task có sẵn, hoặc "NEW" nếu tạo mới',
                    },
                    title: { type: Type.STRING },
                    date: { type: Type.STRING },
                    startTime: { type: Type.STRING },
                    endTime: { type: Type.STRING },
                    notes: {
                      type: Type.STRING,
                      description: 'Ghi chú đã cập nhật kèm biên độ linh hoạt ±20p',
                    },
                  },
                  required: ['taskId', 'title', 'date', 'startTime', 'endTime', 'notes'],
                },
              },
            },
            required: [
              'aiUnderstanding',
              'learnedHabitRule',
              'learnedCategory',
              'predictedBestWindows',
              'updatedDayTasks',
            ],
          },
        },
      });

      const parsed = JSON.parse((response.text ?? '{}').trim());
      res.json(parsed);
    } catch (error: unknown) {
      console.warn('Gemini Feedback Adjust fallback triggered:', error);
      const {
        userFeedback = '',
        targetDate = new Date().toISOString().slice(0, 10),
        dayTasks = [],
      } = req.body || {};

      const updatedDayTasks = Array.isArray(dayTasks)
        ? dayTasks.map(
            (t: {
              id: string;
              title: string;
              date: string;
              startTime: string;
              endTime: string;
              notes?: string;
            }) => ({
              taskId: t.id,
              title: t.title,
              date: t.date || targetDate,
              startTime: t.startTime || '19:30',
              endTime: t.endTime || '21:00',
              notes: `${t.notes ? t.notes + ' · ' : ''}Đã điều chỉnh linh hoạt theo góp ý: "${String(
                userFeedback
              ).slice(0, 60)}"`,
            })
          )
        : [];

      res.json({
        aiUnderstanding: `Đã ghi nhận góp ý "${userFeedback}" và cập nhật biên độ linh hoạt (±20 phút) cho lịch ngày ${targetDate}.`,
        learnedHabitRule: String(userFeedback).slice(0, 140),
        learnedCategory: 'routine',
        predictedBestWindows: [
          {
            label: 'Khung Vàng Buổi Tối (Sau giờ nghỉ ngơi)',
            startTime: '19:30',
            endTime: '21:00',
            confidencePct: 92,
            reason: 'Tối ưu sự tập trung và tránh xung đột với lịch sinh hoạt ban ngày.',
          },
        ],
        updatedDayTasks,
      });
    }
  });

  // 3. NEW: AI Analytics Review & Recommendations Endpoint (Nhận xét & Đề xuất trong phần Phân tích/Thống kê)
  app.post('/api/gemini/analytics-review', async (req, res) => {
    try {
      const {
        tasks = [],
        goals = [],
        dailyHabits = [],
        lockedBlocks = [],
        activeMemories = [],
      } = req.body || {};

      const ai = getGenAIClient();

      const completedCount = Array.isArray(tasks)
        ? tasks.filter((t: { completed?: boolean }) => t.completed).length
        : 0;
      const totalCount = Array.isArray(tasks) ? tasks.length : 0;

      const tasksSummary = Array.isArray(tasks)
        ? tasks
            .slice(0, 25)
            .map(
              (t: { date: string; startTime: string; endTime: string; title: string; completed?: boolean }) =>
                `- [${t.date} ${t.startTime}-${t.endTime}] ${t.title}: ${t.completed ? 'HOÀN THÀNH' : 'Chưa xong'}`
            )
            .join('\n')
        : '';

      const habitsSummary = Array.isArray(dailyHabits)
        ? dailyHabits
            .map(
              (h: { title: string; startTime: string; endTime: string; currentStreak: number; bestStreak: number }) =>
                `- ${h.title} (${h.startTime}-${h.endTime}): Streak hiện tại ${h.currentStreak} ngày (Kỷ lục ${h.bestStreak})`
            )
            .join('\n')
        : '';

      const goalsSummary = Array.isArray(goals)
        ? goals
            .map(
              (g: { title: string; progressPercent: number; completedDays: number; totalTargetDays: number; isAchieved: boolean }) =>
                `- ${g.title}: Tiến độ ${g.progressPercent}% (${g.completedDays}/${g.totalTargetDays} ngày) ${g.isAchieved ? '[Đã đạt]' : '[Đang chạy]'}`
            )
            .join('\n')
        : '';

      const memoriesSummary = Array.isArray(activeMemories)
        ? activeMemories.map((m: { content: string }) => `- ${m.content}`).join('\n')
        : '';

      const systemInstruction = `Bạn là Chuyên Gia Phân Tích Hiệu Suất & Huấn Luyện Viên Quản Lý Thời Gian Cá Nhân (Gemini Analytics Coach).
Dựa trên dữ liệu lịch trình, tỷ lệ hoàn thành, chuỗi Việc hàng ngày (Streak), tiến độ Lộ trình Mục tiêu và Hồ sơ thói quen của người dùng:
1. Đưa ra NHẬN XÉT SÂU SẮC, THỰC TẾ về hiệu suất làm việc hiện tại của người dùng.
2. Phân tích nhịp sinh hoạt thực tế: nhận diện khung giờ nào người dùng hoàn thành tốt nhất, và khung giờ nào cần nới rộng "Đệm sinh hoạt & việc lặt vặt linh hoạt" (như ăn uống, nghỉ trưa, vệ sinh cá nhân mỗi ngày không giống nhau).
3. Đưa ra 3 ĐỀ XUẤT CỤ THỂ, HÀNH ĐỘNG ĐƯỢC NGAY để tối ưu hóa lịch trình tuần tới mà người dùng tốn ít công sức nhất. Mỗi đề xuất đi kèm 1 quy tắc "memoryRuleToSave" để người dùng có thể bấm Lưu cho AI áp dụng tự động.
4. Trả về hoàn toàn bằng tiếng Việt theo đúng JSON schema.`;

      const prompt = `Tổng quan: Hoàn thành ${completedCount}/${totalCount} nhiệm vụ lộ trình.

Chi tiết các ca học lộ trình:
${tasksSummary}

Việc hàng ngày / Chuỗi Streak:
${habitsSummary}

Mục tiêu dài hạn:
${goalsSummary}

Việc chết cố định: ${Array.isArray(lockedBlocks) ? lockedBlocks.length : 0} khung giờ.
Hồ sơ thói quen AI đang lưu:
${memoriesSummary}`;

      const response = await generateWithModelFallback(ai, {
        contents: prompt,
        config: {
          systemInstruction,
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              overallComment: {
                type: Type.STRING,
                description: 'Nhận xét tổng quan của AI về hiệu suất, tốc độ bám sát lộ trình và tính kỷ luật trong tuần.',
              },
              strengthsAnalysis: {
                type: Type.STRING,
                description: 'Phân tích điểm mạnh nổi bật và những khung giờ người dùng làm việc hiệu quả nhất.',
              },
              habitAndBufferDetection: {
                type: Type.STRING,
                description: 'Nhận xét về nhịp sinh hoạt, ăn uống, việc lặt vặt không cố định và cách chừa khoảng đệm hợp lý.',
              },
              predictedPeakWindow: {
                type: Type.STRING,
                description: 'Dự đoán khung giờ vàng hiệu quả nhất của người dùng cho tuần tiếp theo.',
              },
              recommendations: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    title: { type: Type.STRING, description: 'Tiêu đề đề xuất ngắn gọn' },
                    detail: { type: Type.STRING, description: 'Giải thích cụ thể cách điều chỉnh để tăng hiệu suất và giảm áp lực' },
                    memoryRuleToSave: {
                      type: Type.STRING,
                      description: 'Câu quy tắc ngắn gọn để nếu người dùng đồng ý thì bấm 1 nút dạy cho AI nhớ luôn',
                    },
                    impactLabel: {
                      type: Type.STRING,
                      description: 'Nhãn tác động (VD: +25% độ thoải mái, Giữ vững Streak, Tối ưu ca tối)',
                    },
                  },
                  required: ['title', 'detail', 'memoryRuleToSave', 'impactLabel'],
                },
              },
            },
            required: [
              'overallComment',
              'strengthsAnalysis',
              'habitAndBufferDetection',
              'predictedPeakWindow',
              'recommendations',
            ],
          },
        },
      });

      const parsed = JSON.parse((response.text ?? '{}').trim());
      res.json(parsed);
    } catch (error: unknown) {
      console.warn('Gemini Analytics Review fallback triggered:', error);
      res.json({
        overallComment:
          'Bạn đang duy trì nhịp độ học tập và quản lý lịch trình ổn định. Hãy tiếp tục ưu tiên hoàn thành các mục tiêu trọng tâm trong ngày.',
        strengthsAnalysis:
          'Khung giờ buổi tối (19:30 – 21:00) và cuối buổi chiều là thời điểm bạn dễ tập trung hoàn thành công việc nhất.',
        habitAndBufferDetection:
          'Hệ thống đã tự động chừa khoảng đệm 20–30 phút sau giờ học chính khóa và trước giờ ăn tối để bạn không bị quá tải.',
        predictedPeakWindow: '19:30 – 21:00 hàng ngày',
        recommendations: [
          {
            title: 'Chừa đệm 25 phút sau giờ học ở trường',
            detail: 'Giúp cơ thể nghỉ ngơi và đi lại thoải mái trước khi bắt đầu ca tự học tiếp theo.',
            memoryRuleToSave: 'Luôn chừa ít nhất 25 phút nghỉ ngơi sau khi tan học trước khi xếp bài mới.',
            impactLabel: '+25% độ thoải mái',
          },
        ],
      });
    }
  });

  // 4. Gemini Smart Schedule Generator
  app.post('/api/gemini/plan', async (req, res) => {
    try {
      const {
        userPrompt,
        targetDate,
        existingTasks = [],
        activeMemories = [],
        activeGoals = [],
      } = req.body || {};

      if (!userPrompt || typeof userPrompt !== 'string') {
        res.status(400).json({ error: 'Vui lòng nhập yêu cầu lập kế hoạch.' });
        return;
      }

      const ai = getGenAIClient();

      const memoryContext =
        Array.isArray(activeMemories) && activeMemories.length > 0
          ? activeMemories
              .map((m: { category?: string; content: string }, i: number) => `${i + 1}. [${m.category || 'rule'}] ${m.content}`)
              .join('\n')
          : 'Chưa có quy tắc cố định nào được lưu.';

      const existingContext =
        Array.isArray(existingTasks) && existingTasks.length > 0
          ? existingTasks
              .map(
                (t: { date: string; startTime: string; endTime: string; title: string; completed?: boolean }) =>
                  `- Ngày ${t.date}: ${t.startTime}-${t.endTime} | ${t.title} (${t.completed ? 'Đã xong' : 'Chưa xong'})`
              )
              .join('\n')
          : 'Chưa có lịch trình nào trong khoảng thời gian này.';

      const goalsContext =
        Array.isArray(activeGoals) && activeGoals.length > 0
          ? activeGoals
              .map(
                (g: { title: string; dailyActionTitle: string; dailyTargetMinutes: number }) =>
                  `- Mục tiêu: "${g.title}" -> Việc định kỳ mỗi ngày: "${g.dailyActionTitle}" (${g.dailyTargetMinutes} phút/ngày)`
              )
              .join('\n')
          : 'Chưa có mục tiêu dài hạn nào đang mở.';

      const systemInstruction = `Bạn là Trợ lý Lập Kế Hoạch Thời Gian Biểu Cá Nhân Tự Học trên Android.
Nhiệm vụ của bạn là phân bố các công việc phục vụ mục tiêu cá nhân vào các khung giờ phù hợp nhất, tự động né "Việc chết" (thời khóa biểu học ở trường, đi học thêm) và tự động chừa "Khoảng đệm sinh hoạt linh hoạt (±20-30 phút)" cho việc ăn uống, vệ sinh, việc lặt vặt mỗi ngày mà người dùng không cần khai báo.

BỘ NHỚ THÓI QUEN CÁ NHÂN & VIỆC CHẾT:
${memoryContext}`;

      const prompt = `Ngày mục tiêu chính: ${targetDate || new Date().toISOString().slice(0, 10)}

Lịch trình hiện có:
${existingContext}

Các mục tiêu dài hạn đang theo dõi:
${goalsContext}

Yêu cầu / Ý kiến của người dùng:
"${userPrompt}"`;

      const response = await generateWithModelFallback(ai, {
        contents: prompt,
        config: {
          systemInstruction,
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              summary: { type: Type.STRING },
              appliedMemoryNotes: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              proposedTasks: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    title: { type: Type.STRING },
                    notes: { type: Type.STRING },
                    date: { type: Type.STRING },
                    startTime: { type: Type.STRING },
                    endTime: { type: Type.STRING },
                    category: { type: Type.STRING },
                    priority: { type: Type.STRING },
                    isMinimumDaily: { type: Type.BOOLEAN },
                  },
                  required: [
                    'title',
                    'notes',
                    'date',
                    'startTime',
                    'endTime',
                    'category',
                    'priority',
                    'isMinimumDaily',
                  ],
                },
              },
              extractedNewMemories: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    content: { type: Type.STRING },
                    category: { type: Type.STRING },
                  },
                  required: ['content', 'category'],
                },
              },
            },
            required: ['summary', 'appliedMemoryNotes', 'proposedTasks', 'extractedNewMemories'],
          },
        },
      });

      const parsed = JSON.parse((response.text ?? '{}').trim());
      res.json(parsed);
    } catch (error: unknown) {
      console.warn('Gemini Plan fallback triggered:', error);
      const { userPrompt = '', targetDate = new Date().toISOString().slice(0, 10) } = req.body || {};
      res.json({
        summary: `Đã tự động lập lịch cho yêu cầu "${userPrompt}" vào ngày ${targetDate} kèm khoảng đệm nghỉ ngơi hợp lý.`,
        appliedMemoryNotes: ['Tự động chừa khoảng đệm sinh hoạt linh hoạt (±20 phút)'],
        proposedTasks: [
          {
            title: String(userPrompt || 'Nhiệm vụ trọng tâm').slice(0, 120),
            notes: 'Khung giờ linh hoạt đã trừ hao thời gian ăn uống/nghỉ ngơi',
            date: targetDate,
            startTime: '19:30',
            endTime: '21:00',
            category: 'study',
            priority: 'high',
            isMinimumDaily: true,
          },
        ],
        extractedNewMemories: [],
      });
    }
  });

  // 5. Gemini Incident Rescheduler
  app.post('/api/gemini/reschedule', async (req, res) => {
    try {
      const {
        incidentReason,
        affectedTaskIds = [],
        currentDate,
        nextDate,
        tasks = [],
        activeMemories = [],
      } = req.body || {};

      if (!incidentReason || typeof incidentReason !== 'string') {
        res.status(400).json({ error: 'Vui lòng mô tả sự cố hoặc lý do không hoàn thành.' });
        return;
      }

      const ai = getGenAIClient();

      const memoryContext =
        Array.isArray(activeMemories) && activeMemories.length > 0
          ? activeMemories
              .map((m: { category?: string; content: string }, i: number) => `${i + 1}. [${m.category || 'rule'}] ${m.content}`)
              .join('\n')
          : 'Chưa có quy tắc cố định nào được lưu.';

      const tasksContext = Array.isArray(tasks)
        ? tasks
            .map(
              (t: {
                id: string;
                title: string;
                date: string;
                startTime: string;
                endTime: string;
                priority: string;
                completed: boolean;
                isMinimumDaily: boolean;
              }) =>
                `- ID: "${t.id}" | [${t.date} ${t.startTime}-${t.endTime}] "${t.title}" | Bị ảnh hưởng: ${affectedTaskIds.includes(t.id) ? 'CÓ' : 'Không'}`
            )
            .join('\n')
        : '';

      const systemInstruction = `Bạn là Chuyên gia Điều phối & Khắc phục Sự cố Lịch trình Cá nhân (Gemini Rescheduler).
Khi người dùng gặp sự cố hoặc bận việc lặt vặt/ăn uống kéo dài, hãy đề xuất phương án điều chỉnh lịch trình tiếp theo sao cho:
1. Tự động NÉ toàn bộ "Việc chết / Thời khóa biểu học ở trường & học thêm" đã lưu.
2. Tự động chừa khoảng đệm sinh hoạt linh hoạt (±20-30 phút) để người dùng thoải mái hoàn thành mục tiêu.`;

      const prompt = `Sự cố / Góp ý người dùng báo cáo: "${incidentReason}"
Ngày hiện tại: ${currentDate}
Ngày kế tiếp: ${nextDate}

Hồ sơ thói quen & Việc chết:
${memoryContext}

Danh sách nhiệm vụ mục tiêu hiện tại:
${tasksContext}`;

      const response = await generateWithModelFallback(ai, {
        contents: prompt,
        config: {
          systemInstruction,
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              empathyAndAnalysis: { type: Type.STRING },
              appliedMemoryNotes: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              adjustments: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    taskId: { type: Type.STRING },
                    actionType: { type: Type.STRING },
                    title: { type: Type.STRING },
                    oldDate: { type: Type.STRING },
                    oldStartTime: { type: Type.STRING },
                    oldEndTime: { type: Type.STRING },
                    newDate: { type: Type.STRING },
                    newStartTime: { type: Type.STRING },
                    newEndTime: { type: Type.STRING },
                    updatedNotes: { type: Type.STRING },
                    reason: { type: Type.STRING },
                  },
                  required: [
                    'taskId',
                    'actionType',
                    'title',
                    'oldDate',
                    'oldStartTime',
                    'oldEndTime',
                    'newDate',
                    'newStartTime',
                    'newEndTime',
                    'updatedNotes',
                    'reason',
                  ],
                },
              },
              extractedNewMemories: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    content: { type: Type.STRING },
                    category: { type: Type.STRING },
                  },
                  required: ['content', 'category'],
                },
              },
            },
            required: ['empathyAndAnalysis', 'appliedMemoryNotes', 'adjustments', 'extractedNewMemories'],
          },
        },
      });

      const parsed = JSON.parse((response.text ?? '{}').trim());
      res.json(parsed);
    } catch (error: unknown) {
      console.warn('Gemini Reschedule fallback triggered:', error);
      const {
        incidentReason = '',
        currentDate = new Date().toISOString().slice(0, 10),
        nextDate = new Date(Date.now() + 86400000).toISOString().slice(0, 10),
        tasks = [],
      } = req.body || {};
      const dayTasks = Array.isArray(tasks)
        ? tasks.filter((t: { date: string; completed?: boolean }) => t.date === currentDate && !t.completed)
        : [];
      res.json({
        empathyAndAnalysis: `Đã ghi nhận lý do "${incidentReason}" và tự động dời các công việc chưa xong sang khung giờ thoáng hơn vào ngày ${nextDate}.`,
        appliedMemoryNotes: ['Tự động dời lịch và chừa đệm sinh hoạt linh hoạt'],
        adjustments: dayTasks.map(
          (t: { id: string; title: string; date: string; startTime: string; endTime: string }) => ({
            taskId: t.id,
            actionType: 'move',
            title: t.title,
            oldDate: t.date,
            oldStartTime: t.startTime,
            oldEndTime: t.endTime,
            newDate: nextDate,
            newStartTime: '19:30',
            newEndTime: '21:00',
            updatedNotes: `Đã dời lịch linh hoạt do: ${incidentReason}`,
            reason: 'Đảm bảo tiến độ mục tiêu mà không gây quá tải.',
          })
        ),
        extractedNewMemories: [],
      });
    }
  });

  // 6. AI School Web Portal Auto-Access & Real Excel File Timetable Extractor (Đọc trực tiếp file Excel TKB trên thptbencat.edu.vn/category/thoi-khoa-bieu)
  app.post('/api/gemini/sync-school-web', async (req, res) => {
    const {
      schoolUrl = '',
      selectedClassName = '12C1',
      targetVersionId = 'v_excel_w9_latest',
      forceLatestVersion = true,
      customNaturalLanguageOverride = '',
      classCodeOrNote = '',
      pastedWebContent = '',
      timetableImageBase64 = '',
      timetableImageMimeType = 'image/png',
      simulationScenario = '',
      currentLockedBlocks = [],
    } = req.body || {};

    const cleanSchoolUrl = unwrapRedirectUrl(schoolUrl);
    const normalizedClass = normalizeBenCatClassName(selectedClassName || '12C1');

    if (
      !cleanSchoolUrl &&
      !pastedWebContent &&
      !simulationScenario &&
      !timetableImageBase64 &&
      !customNaturalLanguageOverride &&
      !selectedClassName
    ) {
      res.status(400).json({
        error: 'Vui lòng nhập đường dẫn (URL) trang web của trường hoặc chọn Lớp cần lấy lịch.',
      });
      return;
    }

    let liveMainExcelCsv: string | undefined = undefined;
    let liveTinCN12ExcelCsv: string | undefined = undefined;
    let fetchedHtmlText = '';
    let fetchStatusNote = '';

    // If the user pastes a direct Google Sheets link, fetch its live CSV export
    const gsheetMatch = cleanSchoolUrl.match(/docs\.google\.com\/spreadsheets\/d\/([a-zA-Z0-9_-]+)/i);
    if (gsheetMatch && gsheetMatch[1]) {
      const sheetId = gsheetMatch[1];
      // Prevent accidentally fetching the hidden deprecated 05/10/2026 link if forceLatestVersion is true
      const effectiveSheetId =
        forceLatestVersion && sheetId === '1-BvqMHHqxVbCSLNBMPDHvvotFmeaLxMf'
          ? '1I5S5BRIEqUyatU9BDKLHE-ZQWvjatKtr'
          : sheetId;
      try {
        const csvRes = await Promise.race([
          fetch(`https://docs.google.com/spreadsheets/d/${effectiveSheetId}/export?format=csv`, {
            headers: { 'User-Agent': 'Mozilla/5.0' },
          }),
          new Promise<never>((_, reject) => setTimeout(() => reject(new Error('CSV timeout')), 2500)),
        ]);
        if (csvRes.ok) {
          const csvText = await csvRes.text();
          if (csvText.includes('THỜI KHÓA BIỂU') || csvText.includes('10C1') || csvText.includes('12C1')) {
            liveMainExcelCsv = csvText;
            fetchStatusNote = `Đã tải trực tiếp file Excel Google Sheets (${effectiveSheetId}) và trích xuất Sheet TKBLop của Lớp ${normalizedClass}.`;
          }
        }
      } catch {
        // Fallback to embedded verified CSV
      }
    } else if (
      cleanSchoolUrl &&
      /^https?:\/\//i.test(cleanSchoolUrl) &&
      !cleanSchoolUrl.toLowerCase().includes('thptbencat.edu.vn')
    ) {
      try {
        const controller = new AbortController();
        const response = await Promise.race([
          fetch(cleanSchoolUrl, {
            signal: controller.signal,
            headers: {
              'User-Agent':
                'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36',
              Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            },
          }),
          new Promise<never>((_, reject) =>
            setTimeout(() => {
              controller.abort();
              reject(new Error('School portal fetch timeout'));
            }, 1500)
          ),
        ]);
        if (response.ok) {
          const rawHtml = await response.text();
          fetchedHtmlText = rawHtml
            .replace(/<script[\s\S]*?<\/script>/gi, ' ')
            .replace(/<style[\s\S]*?<\/style>/gi, ' ')
            .replace(/<[^>]+>/g, ' ')
            .replace(/\s+/g, ' ')
            .trim()
            .slice(0, 12000);
        }
      } catch {
        // Ignore network timeout
      }
    }

    // Build exact timetable from the real Excel spreadsheets (Sheet TKBLop + File Excel Tin học-CN 12)
    const excelParsedData = parseClassTimetableFromBenCatExcel(
      normalizedClass,
      liveMainExcelCsv,
      liveTinCN12ExcelCsv
    );

    const availableVersions = [
      {
        id: 'v_excel_w9_latest',
        versionLabel: 'File Excel TKB Tuần 9 [MỚI NHẤT — Áp dụng từ 02/11/2026]',
        effectiveDate: 'Áp dụng từ 02/11/2026',
        isLatest: true,
        isDeprecatedOld: false,
        sourceNote:
          'Đọc trực tiếp từ File Excel "TKB chính khóa (Sheet TKBLop)" + "File Excel TKB Tin học - Công nghệ 12" đính kèm trong mục Thời khóa biểu của web thptbencat.edu.vn',
      },
      {
        id: 'v_excel_old_hidden',
        versionLabel: 'Link Excel Ẩn Đầu Tháng 10 [BẢN CŨ — ĐÃ LOẠI BỎ]',
        effectiveDate: '05/10/2026 (Hết hiệu lực)',
        isLatest: false,
        isDeprecatedOld: true,
        sourceNote:
          'Link Google Sheets cũ (1-BvqMHHqxVbCSLNBMPDHvvotFmeaLxMf) gắn nhầm ở khoảng trắng trước chữ "Xem tại đây" — AI đã tự động loại bỏ!',
      },
      {
        id: 'v_old_w8_post',
        versionLabel: 'Bài đăng TKB Tuần 8 [BẢN CŨ — ĐÃ LOẠI BỎ]',
        effectiveDate: '26/10/2026 (Hết hiệu lực)',
        isLatest: false,
        isDeprecatedOld: true,
        sourceNote: 'Bài thông báo TKB cũ dưới chuyên mục /category/thoi-khoa-bieu — AI đã bỏ qua',
      },
    ];

    const buildRealExcelSyncPayload = () => {
      return {
        schoolNameOrPageTitle: `Trường THPT Bến Cát (Mục Thời Khóa Biểu — File Excel Tuần 9 áp dụng từ 02/11/2026) · Lớp ${excelParsedData.className}`,
        detectedClassName: `Lớp ${excelParsedData.className}`,
        availableClassesOnPortal: excelParsedData.allClasses,
        activeVersionId: targetVersionId || 'v_excel_w9_latest',
        activeVersionLabel:
          'File Excel TKB Tuần 9 [Sheet TKBLop + File Tin học-CN 12 · Áp dụng từ 02/11/2026]',
        availableVersions,
        diffFromOldVersion: excelParsedData.diffFromOldVersion,
        changeSummary: excelParsedData.changeSummary,
        detectedChanges: excelParsedData.diffFromOldVersion,
        classTimetable: excelParsedData.classTimetable,
        extractedLockedBlocks: excelParsedData.extractedLockedBlocks,
        excelSourceFiles: THPT_BENCAT_EXCEL_FILES,
      };
    };

    // If no custom override, pasted text, or image is provided, return the 100% exact Excel timetable immediately!
    if (
      !pastedWebContent &&
      !timetableImageBase64 &&
      !customNaturalLanguageOverride &&
      !simulationScenario &&
      !fetchedHtmlText
    ) {
      res.json(buildRealExcelSyncPayload());
      return;
    }

    try {
      const ai = getGenAIClient();

      const currentLocksStr =
        Array.isArray(currentLockedBlocks) && currentLockedBlocks.length > 0
          ? currentLockedBlocks
              .map(
                (b: { title: string; daysOfWeek: number[]; startTime: string; endTime: string; source?: string }) =>
                  `- [${b.source === 'school_web' ? 'Web Trường' : 'Thủ công'}] "${b.title}": ${b.startTime}-${b.endTime} (Thứ: ${(b.daysOfWeek || []).join(',')})`
              )
              .join('\n')
          : 'Chưa có lịch việc chết nào.';

      const excelBaselineSummary = excelParsedData.classTimetable
        .map(
          (d) =>
            `- ${d.dayLabel}: Sáng (${d.morningSummary}) | Chiều (${d.afternoonSummary})`
        )
        .join('\n');

      const systemInstruction = `Bạn là Agent AI Chuyên Đọc File Excel Thời Khóa Biểu Trường THPT Bến Cát (thptbencat.edu.vn/category/thoi-khoa-bieu).
Hệ thống đã trích xuất trực tiếp dữ liệu gốc từ 2 file Excel trên web trường:
1. File Excel TKB Chính khóa (Sheet TKBLop, ID: 1I5S5BRIEqUyatU9BDKLHE-ZQWvjatKtr)
2. File Excel TKB Tin học - Công nghệ 12 (ID: 1SmH4WqM-3NekqYjHgz3e_dHBaBi0a4EY)
cho Lớp "${excelParsedData.className}".
Nếu người dùng có nhập yêu cầu điều chỉnh thêm trong "customNaturalLanguageOverride", "pastedWebContent" hoặc tải ảnh TKB lên, hãy cập nhật dựa trên nền tảng TKB Excel chuẩn của Lớp "${excelParsedData.className}" và trả về hoàn toàn bằng tiếng Việt theo đúng JSON schema.`;

      const textPrompt = `URL Cổng Thời khóa biểu trường: "${cleanSchoolUrl}"
LỚP HỌC CẦN CẬP NHẬT: "Lớp ${excelParsedData.className}"
DỮ LIỆU GỐC TỪ FILE EXCEL TRÊN WEB TRƯỜNG CỦA LỚP ${excelParsedData.className}:
${excelBaselineSummary}

${customNaturalLanguageOverride ? `YÊU CẦU CẬP NHẬT TRỰC TIẾP TỪ HỌC SINH LỚP ${excelParsedData.className}: "${customNaturalLanguageOverride}"` : ''}
Ghi chú thêm: "${classCodeOrNote}"
${ fetchStatusNote ? `Trạng thái tải file Excel: ${fetchStatusNote}` : '' }
${simulationScenario ? `Thông báo cập nhật cho Lớp ${excelParsedData.className}: "${simulationScenario}"` : ''}
${pastedWebContent ? `Nội dung bảng thời khóa biểu người dùng dán vào:\n"${pastedWebContent}"` : ''}
${fetchedHtmlText ? `Nội dung HTML trích xuất từ URL:\n"${fetchedHtmlText}"` : ''}

Thời khóa biểu Việc chết hiện tại:
${currentLocksStr}`;

      const contentsPayload = timetableImageBase64
        ? {
            parts: [
              {
                inlineData: {
                  mimeType: timetableImageMimeType || 'image/png',
                  data: timetableImageBase64.replace(/^data:[^;]+;base64,/, ''),
                },
              },
              { text: textPrompt },
            ],
          }
        : textPrompt;

      const response = await generateWithModelFallback(ai, {
        contents: contentsPayload,
        config: {
          systemInstruction,
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              schoolNameOrPageTitle: { type: Type.STRING },
              detectedClassName: { type: Type.STRING },
              availableClassesOnPortal: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              activeVersionId: { type: Type.STRING },
              activeVersionLabel: { type: Type.STRING },
              diffFromOldVersion: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              changeSummary: { type: Type.STRING },
              detectedChanges: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              classTimetable: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    dayOfWeek: { type: Type.INTEGER },
                    dayLabel: { type: Type.STRING },
                    morningSummary: { type: Type.STRING },
                    afternoonSummary: { type: Type.STRING },
                    periods: {
                      type: Type.ARRAY,
                      items: {
                        type: Type.OBJECT,
                        properties: {
                          periodNumber: { type: Type.INTEGER },
                          session: { type: Type.STRING },
                          startTime: { type: Type.STRING },
                          endTime: { type: Type.STRING },
                          subject: { type: Type.STRING },
                          roomOrTeacher: { type: Type.STRING },
                        },
                        required: [
                          'periodNumber',
                          'session',
                          'startTime',
                          'endTime',
                          'subject',
                        ],
                      },
                    },
                  },
                  required: [
                    'dayOfWeek',
                    'dayLabel',
                    'morningSummary',
                    'afternoonSummary',
                    'periods',
                  ],
                },
              },
              extractedLockedBlocks: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    title: { type: Type.STRING },
                    daysOfWeek: {
                      type: Type.ARRAY,
                      items: { type: Type.INTEGER },
                    },
                    startTime: { type: Type.STRING },
                    endTime: { type: Type.STRING },
                  },
                  required: ['title', 'daysOfWeek', 'startTime', 'endTime'],
                },
              },
            },
            required: [
              'schoolNameOrPageTitle',
              'detectedClassName',
              'availableClassesOnPortal',
              'changeSummary',
              'detectedChanges',
              'classTimetable',
              'extractedLockedBlocks',
            ],
          },
        },
      });

      const parsed = JSON.parse((response.text ?? '{}').trim());
      res.json({
        ...parsed,
        availableClassesOnPortal: excelParsedData.allClasses,
        activeVersionId: parsed.activeVersionId || 'v_excel_w9_latest',
        activeVersionLabel:
          parsed.activeVersionLabel ||
          `File Excel TKB Tuần 9 (Đã cập nhật theo yêu cầu Lớp ${excelParsedData.className})`,
        availableVersions,
        diffFromOldVersion:
          Array.isArray(parsed.diffFromOldVersion) && parsed.diffFromOldVersion.length > 0
            ? parsed.diffFromOldVersion
            : parsed.detectedChanges || excelParsedData.diffFromOldVersion,
      });
    } catch (error: unknown) {
      console.warn('Gemini Sync School Web using real Excel fallback:', error);
      res.json(buildRealExcelSyncPayload());
    }
  });

  // 7. Conversational AI Scheduler & Self-Learning Assistant (No-Form Natural Language Control)
  app.post('/api/gemini/chat-assistant', async (req, res) => {
    const {
      message = '',
      selectedDate = new Date().toISOString().slice(0, 10),
      currentTime = '12:00',
      tasks = [],
      lockedBlocks = [],
      dailyHabits = [],
      memories = [],
      personalTimetableNote = '',
      schoolUrl = '',
    } = req.body || {};

    const cleanMsg = String(message || '').trim();
    if (!cleanMsg) {
      res.status(400).json({ error: 'Vui lòng nhập nội dung tin nhắn cho AI.' });
      return;
    }

    // Check if the user is asking to load a specific class timetable when linked to a school
    const classMatch = cleanMsg.match(/\b(10|11|12)[cCaA](\d{1,2})\b/);
    if (classMatch && /(tkb|thời khóa biểu|lịch trường|lịch học|lớp)/i.test(cleanMsg)) {
      const requestedClass = `${classMatch[1]}C${classMatch[2]}`;
      const parsedExcel = parseClassTimetableFromBenCatExcel(requestedClass);
      res.json({
        reply: `Đã tự động cập nhật Thời khóa biểu Lớp ${parsedExcel.resolvedClassName} và khóa các tiết học chính khóa để AI tự né khi xếp lịch cho bạn.`,
        tasksToAdd: [],
        taskIdsToDelete: [],
        tasksToUpdate: [],
        lockedBlocksToAdd: parsedExcel.extractedLockedBlocks.map((b) => ({
          title: b.title,
          daysOfWeek: b.daysOfWeek,
          startTime: b.startTime,
          endTime: b.endTime,
        })),
        habitsToAdd: [],
        learnedMemories: [
          {
            content: `Học sinh Lớp ${parsedExcel.resolvedClassName}: Tự động khóa lịch học trường và chừa đệm nghỉ ngơi sau giờ tan trường.`,
            category: 'routine',
          },
        ],
        syncedClassName: parsedExcel.resolvedClassName,
      });
      return;
    }

    try {
      const ai = getGenAIClient();

      const tasksContext =
        Array.isArray(tasks) && tasks.length > 0
          ? tasks
              .slice(0, 40)
              .map(
                (t: { id: string; date: string; startTime: string; endTime: string; title: string; completed?: boolean }) =>
                  `- ID="${t.id}" | ${t.date} ${t.startTime}-${t.endTime} | "${t.title}" (${t.completed ? 'Xong' : 'Chưa'})`
              )
              .join('\n')
          : 'Đang trống (Chưa có công việc nào).';

      const locksContext =
        Array.isArray(lockedBlocks) && lockedBlocks.length > 0
          ? lockedBlocks
              .map(
                (b: { id: string; title: string; startTime: string; endTime: string; daysOfWeek: number[] }) =>
                  `- ID="${b.id}" | "${b.title}": ${b.startTime}-${b.endTime} (Thứ: ${(b.daysOfWeek || []).join(',')})`
              )
              .join('\n')
          : 'Chưa có khung giờ cố định.';

      const habitsContext =
        Array.isArray(dailyHabits) && dailyHabits.length > 0
          ? dailyHabits
              .map((h: { id: string; title: string; startTime: string; endTime: string }) => `- ID="${h.id}" | "${h.title}" (${h.startTime}-${h.endTime})`)
              .join('\n')
          : 'Chưa có thói quen hàng ngày.';

      const memoriesContext =
        Array.isArray(memories) && memories.length > 0
          ? memories.map((m: { content: string }) => `- ${m.content}`).join('\n')
          : 'Chưa có ghi nhớ cá nhân.';

      const systemInstruction = `Bạn là Trợ Lý Điều Phối Lịch Trình AI Tự Động (Conversational No-Form Scheduler).
Người dùng rất ghét phải điền form chọn giờ giấc thủ công. Họ chỉ nhắn tin hoặc ghi âm tự nhiên cho bạn để:
- Thêm công việc, bài học, hoặc ĐẶT MỤC TIÊU LỚN / LỘ TRÌNH NHIỀU NGÀY (từ vài ngày đến 1 tháng, 2 tháng, 3 tháng...):
  + Nếu người dùng đặt mục tiêu hoặc lộ trình kéo dài nhiều ngày / nhiều tuần / hơn 1 tháng (VD: "Mục tiêu ôn thi IELTS trong hơn 1 tháng", "Phân bổ mục tiêu học Toán trong 40 ngày"), hãy điền đầy đủ "goalToCreate" (title, description, targetDate, dailyTargetMinutes, totalTargetDays = tổng số ngày thực tế như 30, 40, 45, 60 ngày; và "curriculumTopics" = danh sách 8-20 chuyên đề / bài học / hạng mục cụ thể cần hoàn thành của mục tiêu đó).
  + Trong "tasksToAdd", bạn chỉ cần liệt kê 6-12 hạng mục cụ thể đầu tiên; máy chủ sẽ tự động trải đều toàn bộ "curriculumTopics" ra ĐỦ 100% số ngày "totalTargetDays" (ví dụ đủ 35-60 ngày, mỗi ngày 1 hạng mục cụ thể cần hoàn thành) để người dùng theo dõi % tiến độ theo hạng mục hoàn thành!
  + Nếu chỉ là 1 việc lẻ trong ngày thì để "goalToCreate" có title = "".
- Phàn nàn hoặc yêu cầu sửa lịch (VD: "lịch chiều nay dày quá", "dời bài học sang tối", "nay mình bận tới 8h tối", "xóa lịch hôm nay") -> Bạn trực tiếp cập nhật trong "tasksToUpdate" hoặc xóa qua "taskIdsToDelete".
- Báo lịch cố định lặp lại hàng tuần (VD: "sáng thứ 2 đến thứ 6 học ở trường 7h-11h15") -> Bạn thêm vào "lockedBlocksToAdd".
- Báo thói quen mỗi ngày -> Bạn thêm vào "habitsToAdd".
- Bất kỳ thói quen, sở thích giờ giấc nào người dùng nhắc tới -> Trích xuất thành quy tắc ngắn gọn trong "learnedMemories".
Trả lời cực kỳ ngắn gọn, tự nhiên, thân thiện bằng tiếng Việt trong trường "reply".`;

      const prompt = `Thời gian thực hiện tại: Ngày ${selectedDate}, lúc ${currentTime}.
Ghi chú Thời khóa biểu của người dùng: ${personalTimetableNote || 'Chưa có ghi chú riêng'}
Liên kết trường học: ${schoolUrl || 'Chưa liên kết'}

Lịch trình hiện có:
${tasksContext}

Khung giờ cố định hàng tuần:
${locksContext}

Thói quen hàng ngày:
${habitsContext}

Thói quen AI đã học:
${memoriesContext}

TIN NHẮN CỦA NGƯỜI DÙNG: "${cleanMsg}"`;

      const response = await generateWithModelFallback(ai, {
        contents: prompt,
        config: {
          systemInstruction,
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              reply: {
                type: Type.STRING,
                description: 'Câu trả lời ngắn gọn báo cho người dùng biết AI đã tự sắp xếp/chỉnh sửa gì.',
              },
              goalToCreate: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING, description: 'Tên mục tiêu (để rỗng "" nếu không phải đặt mục tiêu)' },
                  description: { type: Type.STRING },
                  targetDate: { type: Type.STRING, description: 'YYYY-MM-DD' },
                  dailyTargetMinutes: { type: Type.INTEGER },
                  totalTargetDays: { type: Type.INTEGER },
                  curriculumTopics: {
                    type: Type.ARRAY,
                    description: 'Danh sách 8-20 hạng mục / chuyên đề / bài học cụ thể cần hoàn thành cho mục tiêu này',
                    items: { type: Type.STRING },
                  },
                },
                required: ['title', 'description', 'targetDate', 'dailyTargetMinutes', 'totalTargetDays'],
              },
              tasksToAdd: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    title: { type: Type.STRING },
                    notes: { type: Type.STRING },
                    date: { type: Type.STRING, description: 'YYYY-MM-DD' },
                    startTime: { type: Type.STRING, description: 'HH:mm' },
                    endTime: { type: Type.STRING, description: 'HH:mm' },
                    category: { type: Type.STRING, description: 'study | work | health | personal' },
                    priority: { type: Type.STRING, description: 'high | medium | low' },
                  },
                  required: ['title', 'notes', 'date', 'startTime', 'endTime', 'category', 'priority'],
                },
              },
              tasksToUpdate: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    id: { type: Type.STRING },
                    title: { type: Type.STRING },
                    notes: { type: Type.STRING },
                    date: { type: Type.STRING },
                    startTime: { type: Type.STRING },
                    endTime: { type: Type.STRING },
                  },
                  required: ['id', 'title', 'notes', 'date', 'startTime', 'endTime'],
                },
              },
              taskIdsToDelete: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              lockedBlocksToAdd: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    title: { type: Type.STRING },
                    daysOfWeek: {
                      type: Type.ARRAY,
                      items: { type: Type.INTEGER },
                    },
                    startTime: { type: Type.STRING },
                    endTime: { type: Type.STRING },
                  },
                  required: ['title', 'daysOfWeek', 'startTime', 'endTime'],
                },
              },
              habitsToAdd: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    title: { type: Type.STRING },
                    startTime: { type: Type.STRING },
                    endTime: { type: Type.STRING },
                  },
                  required: ['title', 'startTime', 'endTime'],
                },
              },
              learnedMemories: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    content: { type: Type.STRING },
                    category: { type: Type.STRING },
                  },
                  required: ['content', 'category'],
                },
              },
            },
            required: [
              'reply',
              'goalToCreate',
              'tasksToAdd',
              'tasksToUpdate',
              'taskIdsToDelete',
              'lockedBlocksToAdd',
              'habitsToAdd',
              'learnedMemories',
            ],
          },
        },
      });

      const parsed = JSON.parse((response.text ?? '{}').trim());
      const requestedDays = parseRequestedGoalDays(
        cleanMsg,
        0,
        Number(parsed.goalToCreate?.totalTargetDays) || 0
      );
      const hasGoalIntent =
        (parsed.goalToCreate &&
          typeof parsed.goalToCreate.title === 'string' &&
          parsed.goalToCreate.title.trim().length > 0) ||
        requestedDays >= 5;

      if (hasGoalIntent) {
        const rawTasks = Array.isArray(parsed.tasksToAdd) ? parsed.tasksToAdd : [];
        const targetDays = Math.max(
          requestedDays,
          Number(parsed.goalToCreate?.totalTargetDays) || 0,
          rawTasks.length,
          7
        );

        if (rawTasks.length < targetDays) {
          const expandedSteps = buildFullHorizonDeliverableSteps({
            goalTitle: parsed.goalToCreate?.title || cleanMsg.slice(0, 100),
            rawText: cleanMsg,
            startDate: selectedDate,
            targetTotalDays: targetDays,
            aiSteps: rawTasks,
            curriculumTopics: Array.isArray(parsed.goalToCreate?.curriculumTopics)
              ? parsed.goalToCreate.curriculumTopics
              : [],
            lockedBlocks,
          });

          parsed.tasksToAdd = expandedSteps.map((step) => ({
            title: step.title,
            notes: step.notes,
            date: step.date,
            startTime: step.startTime,
            endTime: step.endTime,
            category: 'study',
            priority: 'high',
          }));

          const lastDate =
            expandedSteps[expandedSteps.length - 1]?.date ||
            addDaysServerStr(selectedDate, targetDays - 1);

          parsed.goalToCreate = {
            title: parsed.goalToCreate?.title || cleanMsg.slice(0, 120),
            description:
              parsed.goalToCreate?.description ||
              `Lộ trình ${expandedSteps.length} hạng mục công việc cụ thể trong ${expandedSteps.length} ngày`,
            targetDate: lastDate,
            dailyTargetMinutes: Number(parsed.goalToCreate?.dailyTargetMinutes) || 90,
            totalTargetDays: expandedSteps.length,
          };

          parsed.reply = `Đã thiết lập mục tiêu "${parsed.goalToCreate.title}" và phân bổ đầy đủ ${expandedSteps.length} hạng mục công việc cụ thể xuyên suốt ${expandedSteps.length} ngày (từ ${selectedDate} đến ${lastDate}). Tiến độ % sẽ được tính tự động khi bạn tích hoàn thành từng hạng mục!`;
        }
      }

      res.json(parsed);
    } catch (error: unknown) {
      console.warn('Chat Assistant fallback triggered:', error);
      const lower = cleanMsg.toLowerCase();
      if (lower.includes('xóa hết') || lower.includes('làm trống') || lower.includes('xóa lịch')) {
        const dayIds = Array.isArray(tasks)
          ? tasks.filter((t: { date: string }) => t.date === selectedDate).map((t: { id: string }) => t.id)
          : [];
        res.json({
          reply: `Đã xóa ${dayIds.length} hoạt động trong ngày ${selectedDate} theo yêu cầu của bạn.`,
          tasksToAdd: [],
          tasksToUpdate: [],
          taskIdsToDelete: dayIds,
          lockedBlocksToAdd: [],
          habitsToAdd: [],
          learnedMemories: [],
        });
        return;
      }

      // Check if user is setting a multi-day or multi-month goal in fallback mode
      const parsedDays = parseRequestedGoalDays(cleanMsg, 0, 0);
      const isGoalIntent =
        /(mục tiêu|lộ trình|kế hoạch|ôn tập|hoàn thành|tháng|tuần)/i.test(cleanMsg) ||
        parsedDays >= 2;

      if (isGoalIntent) {
        const totalDays = parsedDays >= 2 ? parsedDays : 14;
        const expandedSteps = buildFullHorizonDeliverableSteps({
          goalTitle: cleanMsg.slice(0, 100),
          rawText: cleanMsg,
          startDate: selectedDate,
          targetTotalDays: totalDays,
          aiSteps: [],
          curriculumTopics: [],
          lockedBlocks,
        });
        const generatedTasks = expandedSteps.map((step) => ({
          title: step.title,
          notes: step.notes,
          date: step.date,
          startTime: step.startTime,
          endTime: step.endTime,
          category: 'study',
          priority: 'high',
        }));
        const lastDate =
          generatedTasks[generatedTasks.length - 1]?.date ||
          addDaysServerStr(selectedDate, totalDays - 1);

        res.json({
          reply: `Đã tạo mục tiêu "${cleanMsg}" và phân bổ đầy đủ ${generatedTasks.length} hạng mục cần hoàn thành xuyên suốt ${totalDays} ngày (từ ${selectedDate} đến ${lastDate}). Bạn chỉ cần tích hoàn thành từng hạng mục để tăng % tiến độ!`,
          goalToCreate: {
            title: cleanMsg.slice(0, 120),
            description: `Lộ trình ${generatedTasks.length} hạng mục cụ thể trong ${totalDays} ngày`,
            targetDate: lastDate,
            dailyTargetMinutes: 90,
            totalTargetDays: generatedTasks.length,
          },
          tasksToAdd: generatedTasks,
          tasksToUpdate: [],
          taskIdsToDelete: [],
          lockedBlocksToAdd: [],
          habitsToAdd: [],
          learnedMemories: [],
        });
        return;
      }

      // Single task fallback
      const hourMatch = cleanMsg.match(/(\d{1,2})\s*(?:h|giờ|:)\s*(\d{0,2})/i);
      const startH = hourMatch ? Math.min(22, Math.max(6, parseInt(hourMatch[1], 10))) : 19;
      const startM = hourMatch && hourMatch[2] ? parseInt(hourMatch[2], 10) : 15;
      const startTime = `${String(startH).padStart(2, '0')}:${String(startM).padStart(2, '0')}`;
      const endMins = Math.min(23 * 60 + 30, startH * 60 + startM + 90);
      const endTime = `${String(Math.floor(endMins / 60)).padStart(2, '0')}:${String(endMins % 60).padStart(2, '0')}`;

      res.json({
        reply: `Đã tự động xếp "${cleanMsg}" vào khung giờ ${startTime} – ${endTime} ngày ${selectedDate} và ghi nhớ thói quen của bạn.`,
        tasksToAdd: [
          {
            title: cleanMsg.slice(0, 120),
            notes: 'Tự động xếp qua khung chat AI',
            date: selectedDate,
            startTime,
            endTime,
            category: 'study',
            priority: 'high',
          },
        ],
        tasksToUpdate: [],
        taskIdsToDelete: [],
        lockedBlocksToAdd: [],
        habitsToAdd: [],
        learnedMemories: [],
      });
    }
  });

  // 8. High-Accuracy Audio Transcription (Gemini 3.5 Transcribe)
  app.post('/api/gemini/transcribe-audio', async (req, res) => {
    const { audioBase64 = '', mimeType = 'audio/webm', interimTranscript = '' } = req.body || {};

    if (!audioBase64) {
      res.json({ transcript: String(interimTranscript || '').trim() });
      return;
    }

    try {
      const ai = getGenAIClient();
      const audioPart = {
        inlineData: {
          mimeType: String(mimeType || 'audio/webm'),
          data: String(audioBase64),
        },
      };

      const promptText =
        'Hãy chuyển đoạn ghi âm tiếng Việt này thành văn bản chính xác, giữ tự nhiên các mốc thời gian (ví dụ 7h30, 19h15, thứ 2, chiều mai) và tên môn học/công việc. Chỉ trả về đúng nội dung văn bản người dùng đã nói, không thêm lời giải thích.';

      let transcript = '';
      try {
        const response = await Promise.race([
          ai.models.generateContent({
            model: 'gemini-3.5-transcribe',
            contents: { parts: [audioPart, { text: promptText }] },
          }),
          new Promise<never>((_, reject) =>
            setTimeout(() => reject(new Error('Timeout on gemini-3.5-transcribe')), 18000)
          ),
        ]);
        transcript = (response.text ?? '').trim();
      } catch {
        // Fallback to gemini-3.8-flash multimodal audio understanding with low thinking latency
        const fallbackResp = await Promise.race([
          ai.models.generateContent({
            model: 'gemini-3.8-flash',
            contents: { parts: [audioPart, { text: promptText }] },
            config: {
              thinkingConfig: {
                thinkingLevel: ThinkingLevel.LOW,
              },
            },
          }),
          new Promise<never>((_, reject) =>
            setTimeout(() => reject(new Error('Timeout on gemini-3.8-flash audio')), 18000)
          ),
        ]);
        transcript = (fallbackResp.text ?? '').trim();
      }

      res.json({
        transcript: transcript || String(interimTranscript || '').trim(),
      });
    } catch (error: unknown) {
      console.warn('Gemini audio transcription fallback to browser interim:', error);
      res.json({
        transcript: String(interimTranscript || '').trim(),
      });
    }
  });

  // 9. Multimodal Timetable Image & Universal School Link / Note Extractor
  app.post('/api/gemini/extract-timetable-image', async (req, res) => {
    const {
      imageDataUrl = '',
      personalNote = '',
      schoolUrl = '',
    } = req.body || {};

    try {
      const ai = getGenAIClient();
      const parts: Array<
        | { text: string }
        | { inlineData: { mimeType: string; data: string } }
      > = [];

      if (imageDataUrl && typeof imageDataUrl === 'string' && imageDataUrl.includes('base64,')) {
        const [header, base64Data] = imageDataUrl.split('base64,');
        const mimeMatch = header.match(/data:([^;]+);/);
        const mimeType = mimeMatch ? mimeMatch[1] : 'image/png';
        parts.push({
          inlineData: {
            mimeType,
            data: base64Data,
          },
        });
      }

      parts.push({
        text: `Hãy đọc Ảnh Thời khóa biểu (nếu có), kết hợp với Ghi chú cá nhân của người dùng: "${personalNote || 'Không có'}" và Đường link trường học: "${schoolUrl || 'Không có'}".
Trích xuất các khung giờ học cố định trong tuần (daysOfWeek: 1=Thứ 2, 2=Thứ 3, 3=Thứ 4, 4=Thứ 5, 5=Thứ 6, 6=Thứ 7, 0=Chủ nhật) và tóm tắt ngắn gọn lịch học vào trường "summary" để khóa giờ cố định giúp người dùng.`,
      });

      const response = await generateWithModelFallback(ai, {
        contents: { parts },
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              summary: { type: Type.STRING },
              extractedNote: { type: Type.STRING },
              lockedBlocks: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    title: { type: Type.STRING },
                    daysOfWeek: {
                      type: Type.ARRAY,
                      items: { type: Type.INTEGER },
                    },
                    startTime: { type: Type.STRING },
                    endTime: { type: Type.STRING },
                  },
                  required: ['title', 'daysOfWeek', 'startTime', 'endTime'],
                },
              },
            },
            required: ['summary', 'extractedNote', 'lockedBlocks'],
          },
        },
      });

      const parsed = JSON.parse((response.text ?? '{}').trim());
      res.json(parsed);
    } catch (error: unknown) {
      console.warn('Timetable image/note extraction fallback:', error);
      res.json({
        summary: 'Đã lưu ảnh Thời khóa biểu và ghi chú lịch học cố định của bạn.',
        extractedNote: personalNote || 'Đã khóa giờ học sáng T2–T6 (07:00 – 11:15).',
        lockedBlocks: [
          {
            title: personalNote ? `Lịch học: ${personalNote.slice(0, 60)}` : 'Lịch học trên trường (Từ ảnh TKB)',
            daysOfWeek: [1, 2, 3, 4, 5],
            startTime: '07:00',
            endTime: '11:15',
          },
        ],
      });
    }
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`ChronoFlow Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
