import React, { useState } from 'react';
import {
  Target,
  Trophy,
  Sparkles,
  CheckCircle2,
  Circle,
  Flame,
  Calendar,
  Clock,
  RotateCcw,
  Trash2,
  BookOpen,
  Coffee,
  RefreshCw,
  Check,
  Lock,
  Plus,
  ListChecks,
} from 'lucide-react';
import {
  GoalItem,
  ScheduleTask,
  AIMemoryItem,
  LockedFixedBlock,
  DailyMinimumHabit,
  AIGoalRoadmapResponse,
  AIGoalDailyStep,
  formatDaysOfWeekBadge,
  getTodayStr,
  addDaysStr,
} from '../types';
import { VoiceRecorderTrigger } from './VoiceRecorderTrigger';

interface GoalsStreakViewProps {
  goals: GoalItem[];
  tasks: ScheduleTask[];
  memories: AIMemoryItem[];
  lockedBlocks: LockedFixedBlock[];
  dailyHabits: DailyMinimumHabit[];
  onSaveGoalWithRoadmap: (
    goal: Omit<GoalItem, 'id' | 'userId' | 'createdAt' | 'updatedAt'>,
    dailySteps: AIGoalDailyStep[]
  ) => void;
  onAddDailyHabit: (title: string, startTime: string, endTime: string) => void;
  onDeleteDailyHabit: (habitId: string) => void;
  onToggleTask: (taskId: string) => void;
  onDeleteTask: (taskId: string) => void;
  onAddGoalDeliverable: (
    goalId: string,
    deliverableTitle: string,
    dateStr: string,
    startTime?: string,
    endTime?: string
  ) => void;
  onMarkGoalAchieved: (goalId: string) => void;
  onReopenGoal: (goalId: string) => void;
  onDeleteGoal: (goalId: string) => void;
  onJumpToScheduleDate?: (dateStr: string) => void;
}

const DURATION_PRESETS: { label: string; days: number }[] = [
  { label: 'Tự động theo nội dung', days: 0 },
  { label: '14 ngày (2 tuần)', days: 14 },
  { label: '30 ngày (1 tháng)', days: 30 },
  { label: '45 ngày (Hơn 1 tháng)', days: 45 },
  { label: '60 ngày (2 tháng)', days: 60 },
  { label: '90 ngày (3 tháng)', days: 90 },
];

export const GoalsStreakView: React.FC<GoalsStreakViewProps> = ({
  goals,
  tasks,
  memories,
  lockedBlocks,
  dailyHabits,
  onSaveGoalWithRoadmap,
  onAddDailyHabit,
  onDeleteDailyHabit,
  onToggleTask,
  onDeleteTask,
  onAddGoalDeliverable,
  onMarkGoalAchieved,
  onReopenGoal,
  onDeleteGoal,
  onJumpToScheduleDate,
}) => {
  const [activeTab, setActiveTab] = useState<'roadmap_ai' | 'active' | 'achieved'>(
    goals.some((g) => !g.isAchieved) ? 'active' : 'roadmap_ai'
  );

  const [goalTitleInput, setGoalTitleInput] = useState('');
  const [roadmapText, setRoadmapText] = useState('');
  const [targetDurationDays, setTargetDurationDays] = useState<number>(0);
  const [customDaysInput, setCustomDaysInput] = useState<string>('');

  // Quick Add Daily Habit in Goals & Streak view
  const [habitTitle, setHabitTitle] = useState('');
  const [habitStart, setHabitStart] = useState('16:30');
  const [habitEnd, setHabitEnd] = useState('17:30');

  const [startDate, setStartDate] = useState(getTodayStr());
  const [isGeneratingRoadmap, setIsGeneratingRoadmap] = useState(false);
  const [roadmapError, setRoadmapError] = useState<string | null>(null);
  const [roadmapPreview, setRoadmapPreview] = useState<AIGoalRoadmapResponse | null>(null);

  // Per-goal filter & quick-add deliverable state
  const [goalFilterById, setGoalFilterById] = useState<
    Record<string, 'all' | 'pending' | 'completed'>
  >({});
  const [newDeliverableTitleById, setNewDeliverableTitleById] = useState<Record<string, string>>(
    {}
  );
  const [newDeliverableDateById, setNewDeliverableDateById] = useState<Record<string, string>>({});

  const activeGoals = goals.filter((g) => !g.isAchieved);
  const achievedGoals = goals.filter((g) => g.isAchieved);

  const maxCurrentStreak = dailyHabits.reduce((max, h) => Math.max(max, h.currentStreak), 0);
  const maxBestStreak = dailyHabits.reduce((max, h) => Math.max(max, h.bestStreak), 0);

  const effectiveDurationDays =
    Number(customDaysInput) > 0 ? Math.min(180, Number(customDaysInput)) : targetDurationDays;

  const handleGenerateGoalRoadmap = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!roadmapText.trim()) return;

    setIsGeneratingRoadmap(true);
    setRoadmapError(null);
    setRoadmapPreview(null);

    try {
      const response = await fetch('/api/gemini/goal-roadmap', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          goalTitleInput: goalTitleInput.trim(),
          roadmapText: roadmapText.trim(),
          targetDurationDays: effectiveDurationDays,
          lockedBlocks,
          dailyHabits,
          startDate,
          existingTasks: tasks,
          activeMemories: memories.filter((m) => m.isActive),
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Lỗi khi gọi AI phân bổ lộ trình.');
      }

      setRoadmapPreview(data);
    } catch (err: unknown) {
      setRoadmapError(
        err instanceof Error ? err.message : 'Không thể kết nối tới máy chủ Gemini.'
      );
    } finally {
      setIsGeneratingRoadmap(false);
    }
  };

  const handleConfirmRoadmapAndCreateGoal = () => {
    if (!roadmapPreview) return;

    const totalDeliverables = Math.max(
      1,
      roadmapPreview.dailyPlan.length || roadmapPreview.totalDays || 7
    );
    const lastStepDate =
      roadmapPreview.dailyPlan[roadmapPreview.dailyPlan.length - 1]?.date ||
      addDaysStr(startDate, totalDeliverables - 1);

    onSaveGoalWithRoadmap(
      {
        title: (roadmapPreview.goalTitle || goalTitleInput).slice(0, 200),
        description: roadmapPreview.goalDescription.slice(0, 1500),
        targetDate: lastStepDate,
        dailyActionTitle: `Hoàn thành ${totalDeliverables} hạng mục lộ trình (${roadmapPreview.dailyTargetMinutes || 90} phút/buổi)`,
        dailyTargetMinutes: roadmapPreview.dailyTargetMinutes || 90,
        totalTargetDays: totalDeliverables,
        completedDays: 0,
        progressPercent: 0,
        isAchieved: false,
        achievedDate: '',
      },
      roadmapPreview.dailyPlan
    );

    setRoadmapPreview(null);
    setActiveTab('active');
  };

  const handleQuickAddHabit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!habitTitle.trim()) return;
    onAddDailyHabit(habitTitle.trim(), habitStart, habitEnd);
    setHabitTitle('');
  };

  return (
    <div className="space-y-5">
      {/* Top KPI Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4">
          <span className="text-xs text-slate-500 dark:text-slate-400">Mục tiêu đang chạy</span>
          <p className="text-2xl font-bold font-mono tabular-nums text-slate-900 dark:text-white mt-1">
            {activeGoals.length}
          </p>
        </div>
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4">
          <span className="text-xs text-slate-500 dark:text-slate-400">Mục tiêu đã đạt</span>
          <p className="text-2xl font-bold font-mono tabular-nums text-emerald-600 dark:text-emerald-400 mt-1">
            {achievedGoals.length}
          </p>
        </div>
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4">
          <span className="text-xs text-slate-500 dark:text-slate-400">Chuỗi Việc Hàng Ngày</span>
          <p className="text-2xl font-bold font-mono tabular-nums text-amber-500 mt-1 flex items-center gap-1.5">
            <Flame className="w-5 h-5" />
            {maxCurrentStreak} ngày
          </p>
        </div>
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4">
          <span className="text-xs text-slate-500 dark:text-slate-400">Kỷ lục Streak dài nhất</span>
          <p className="text-2xl font-bold font-mono tabular-nums text-indigo-600 dark:text-indigo-400 mt-1">
            {maxBestStreak} ngày
          </p>
        </div>
      </div>

      {/* Quick Daily Habits Manager (Add or Delete Only) */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
            <Flame className="w-4 h-4 text-amber-500" />
            Việc Hàng Ngày / Việc Tối Thiểu (Chỉ Thêm hoặc Xóa — Tự động lặp lại mỗi ngày)
          </h3>
        </div>

        <form onSubmit={handleQuickAddHabit} className="grid grid-cols-1 sm:grid-cols-12 gap-2">
          <input
            type="text"
            required
            value={habitTitle}
            onChange={(e) => setHabitTitle(e.target.value)}
            placeholder="Nhập tên việc hàng ngày (VD: Học 30 từ vựng / Chạy bộ)..."
            className="sm:col-span-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-xs text-slate-900 dark:text-slate-100"
          />
          <input
            type="time"
            required
            value={habitStart}
            onChange={(e) => setHabitStart(e.target.value)}
            className="sm:col-span-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 px-2.5 py-2 text-xs font-mono tabular-nums text-slate-900 dark:text-slate-100"
          />
          <input
            type="time"
            required
            value={habitEnd}
            onChange={(e) => setHabitEnd(e.target.value)}
            className="sm:col-span-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 px-2.5 py-2 text-xs font-mono tabular-nums text-slate-900 dark:text-slate-100"
          />
          <button
            type="submit"
            className="sm:col-span-2 min-h-[38px] px-3 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold flex items-center justify-center gap-1"
          >
            <Plus className="w-4 h-4" />
            Thêm
          </button>
        </form>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {dailyHabits.map((h) => (
            <div
              key={h.id}
              className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2 text-xs"
            >
              <div className="min-w-0">
                <p className="font-semibold text-slate-900 dark:text-slate-100 truncate">
                  {h.title}
                </p>
                <p className="text-[11px] font-mono tabular-nums text-amber-600 dark:text-amber-400">
                  {h.startTime} – {h.endTime} · Streak {h.currentStreak} ngày
                </p>
              </div>
              <button
                type="button"
                onClick={() => onDeleteDailyHabit(h.id)}
                className="min-h-[34px] px-2.5 py-1 rounded-lg text-xs font-semibold text-rose-600 hover:bg-rose-500/10 flex items-center gap-1 shrink-0"
              >
                <Trash2 className="w-3.5 h-3.5" />
                Xóa
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Navigation Switch */}
      <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-200/70 dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
        <button
          type="button"
          onClick={() => setActiveTab('roadmap_ai')}
          className={`min-h-[40px] flex-1 sm:flex-initial px-4 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 flex items-center justify-center gap-1.5 ${
            activeTab === 'roadmap_ai'
              ? 'bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 shadow-xs'
              : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5" />
          Đưa Mục Tiêu Lớn & Lộ Trình (AI Tự Phân Bố)
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('active')}
          className={`min-h-[40px] flex-1 sm:flex-initial px-4 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 flex items-center justify-center gap-1.5 ${
            activeTab === 'active'
              ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          <Target className="w-3.5 h-3.5" />
          Tiến Độ Hoàn Thành Hạng Mục ({activeGoals.length})
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('achieved')}
          className={`min-h-[40px] flex-1 sm:flex-initial px-4 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 flex items-center justify-center gap-1.5 ${
            activeTab === 'achieved'
              ? 'bg-white dark:bg-slate-800 text-emerald-600 dark:text-emerald-400 shadow-xs'
              : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          <Trophy className="w-3.5 h-3.5" />
          Đã đạt được ({achievedGoals.length})
        </button>
      </div>

      {/* TAB 1: PASTE LARGE GOAL + ROADMAP -> AI AUTO DISTRIBUTES ACROSS WEEKS/MONTHS */}
      {activeTab === 'roadmap_ai' && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 space-y-5">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-indigo-500" />
              Đưa Mục Tiêu Lớn (1–6 Tháng) — AI Tự Động Chia Thành Từng Hạng Mục Cụ Thể
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Hỗ trợ phân bổ lộ trình dài hạn (14 ngày, 30 ngày, 45 ngày, 60–90+ ngày). Hệ thống sẽ chia mục tiêu thành các <strong>hạng mục công việc cụ thể cần hoàn thành</strong> để tính % tiến độ thực chất (thay vì điểm danh ngày suông).
            </p>
          </div>

          {/* Summary of Locked Fixed Blocks */}
          {lockedBlocks.length > 0 && (
            <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-2">
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5 text-indigo-500" />
                Các Việc Chết đang khóa cố định qua mọi tuần & tháng (AI tự động né 100%):
              </span>
              <div className="flex flex-wrap gap-1.5">
                {lockedBlocks.map((b) => (
                  <span
                    key={b.id}
                    className="px-2.5 py-1 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-[11px] font-mono text-slate-700 dark:text-slate-300"
                  >
                    🔒 {b.title} ({b.startTime}–{b.endTime} · {formatDaysOfWeekBadge(b.daysOfWeek)})
                  </span>
                ))}
              </div>
            </div>
          )}

          <form onSubmit={handleGenerateGoalRoadmap} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                1. Tên mục tiêu lớn của bạn:
              </label>
              <input
                type="text"
                required
                value={goalTitleInput}
                onChange={(e) => setGoalTitleInput(e.target.value)}
                placeholder="VD: Ôn thi THPT Quốc gia môn Toán 9+ trong hơn 1 tháng / Đạt IELTS 6.5..."
                className="w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 px-3.5 py-2.5 text-sm text-slate-900 dark:text-slate-100"
              />
            </div>

            {/* Duration Selector for Multi-Week / Multi-Month Goals */}
            <div className="space-y-2">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                2. Thời lượng phân bổ lộ trình (Hỗ trợ mục tiêu dài hạn hơn 1 tháng):
              </label>
              <div className="flex flex-wrap items-center gap-1.5">
                {DURATION_PRESETS.map((preset) => {
                  const isSelected =
                    !customDaysInput && targetDurationDays === preset.days;
                  return (
                    <button
                      key={preset.days}
                      type="button"
                      onClick={() => {
                        setCustomDaysInput('');
                        setTargetDurationDays(preset.days);
                      }}
                      className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-colors ${
                        isSelected
                          ? 'bg-indigo-600 text-white border-indigo-600'
                          : 'bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:border-indigo-400'
                      }`}
                    >
                      {preset.label}
                    </button>
                  );
                })}

                <div className="inline-flex items-center gap-1.5 ml-1">
                  <input
                    type="number"
                    min={1}
                    max={180}
                    value={customDaysInput}
                    onChange={(e) => setCustomDaysInput(e.target.value)}
                    placeholder="Số ngày khác..."
                    className="w-28 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 px-2.5 py-1.5 text-xs font-mono text-slate-900 dark:text-slate-100"
                  />
                  {customDaysInput && (
                    <span className="text-xs font-semibold text-indigo-600 dark:text-indigo-400">
                      ({customDaysInput} ngày)
                    </span>
                  )}
                </div>
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                  3. Nội dung các chuyên đề / hạng mục cần hoàn thành (hoặc bấm Giọng nói):
                </label>
                <VoiceRecorderTrigger
                  compact
                  showAutoSendButton={false}
                  onTranscriptReady={(txt) =>
                    setRoadmapText((prev) => (prev ? `${prev}\n${txt}` : txt))
                  }
                />
              </div>
              <textarea
                rows={4}
                required
                value={roadmapText}
                onChange={(e) => setRoadmapText(e.target.value)}
                placeholder="Nhập các chương, chuyên đề hoặc yêu cầu mục tiêu (VD: Phân bổ trong 45 ngày gồm Chương 1 Hàm số, Chương 2 Mũ Logarit, Chương 3 Nguyên hàm Tích phân, Chương 4 Số phức, Chương 5 Hình Oxyz và 10 đề tổng ôn)..."
                className="w-full rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-3.5 text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Ngày bắt đầu:
                </label>
                <input
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-xs font-mono tabular-nums text-slate-900 dark:text-slate-100"
                />
              </div>

              <button
                type="submit"
                disabled={isGeneratingRoadmap}
                className="min-h-[44px] px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white text-xs font-semibold flex items-center justify-center gap-2 shadow-sm transition-colors"
              >
                {isGeneratingRoadmap ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    AI đang chia hạng mục & phân bổ đủ ngày...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    AI Tự Phân Bố Đủ Toàn Bộ Lộ Trình
                  </>
                )}
              </button>
            </div>
          </form>

          {roadmapError && (
            <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-xs text-rose-600 dark:text-rose-400">
              {roadmapError}
            </div>
          )}

          {roadmapPreview && (
            <div className="space-y-4 pt-4 border-t border-slate-100 dark:border-slate-800">
              <div className="p-4 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 space-y-1.5">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                    🎯 {roadmapPreview.goalTitle}
                  </h4>
                  <span className="px-2.5 py-1 rounded-lg bg-indigo-600 text-white text-xs font-mono tabular-nums font-bold">
                    Đủ {roadmapPreview.dailyPlan.length} hạng mục · {roadmapPreview.dailyPlan.length} ngày
                  </span>
                </div>
                <p className="text-xs text-slate-700 dark:text-slate-300">
                  {roadmapPreview.strategyNote}
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5 max-h-96 overflow-y-auto pr-1">
                {roadmapPreview.dailyPlan.map((step, idx) => (
                  <div
                    key={idx}
                    className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-1.5"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs font-mono tabular-nums font-bold text-indigo-600 dark:text-indigo-400">
                        Ngày {step.dayNumber} ({step.date})
                      </span>
                      <span className="text-xs font-mono tabular-nums font-semibold text-emerald-600 dark:text-emerald-400">
                        {step.startTime} – {step.endTime}
                      </span>
                    </div>

                    <p className="text-xs sm:text-sm font-bold text-slate-900 dark:text-slate-100">
                      {step.title}
                    </p>
                    <p className="text-[11px] text-slate-600 dark:text-slate-300">{step.notes}</p>

                    <div className="pt-1.5 border-t border-slate-200/60 dark:border-slate-800/80 flex items-center gap-1.5 text-[10px] text-teal-600 dark:text-teal-400 font-medium">
                      <Coffee className="w-3 h-3 shrink-0" />
                      <span>{step.freeTimeSummary}</span>
                    </div>
                  </div>
                ))}
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setRoadmapPreview(null)}
                  className="min-h-[44px] px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400"
                >
                  Hủy bản nháp
                </button>
                <button
                  type="button"
                  onClick={handleConfirmRoadmapAndCreateGoal}
                  className="min-h-[44px] px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-2 shadow-sm"
                >
                  <Check className="w-4 h-4" />
                  Xác nhận Lưu {roadmapPreview.dailyPlan.length} Hạng Mục Vào Lịch
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 2: DELIVERABLE-BASED PROGRESS ("HOÀN THÀNH HẠNG MỤC GÌ THAY VÌ ĐIỂM DANH NGÀY") */}
      {activeTab === 'active' && (
        <div className="space-y-4">
          {activeGoals.length === 0 ? (
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-8 text-center space-y-3">
              <p className="text-sm font-bold text-slate-800 dark:text-slate-200">
                Chưa có mục tiêu nào đang chạy
              </p>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Hãy bấm sang mục <strong>“Đưa Mục Tiêu Lớn & Lộ Trình”</strong> hoặc nhắn cho AI (VD: <em>“Đặt mục tiêu ôn Toán trong hơn 1 tháng”</em>) để tạo danh sách các hạng mục cần hoàn thành.
              </p>
              <button
                type="button"
                onClick={() => setActiveTab('roadmap_ai')}
                className="px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-semibold"
              >
                + Đặt mục tiêu mới ngay
              </button>
            </div>
          ) : (
            activeGoals.map((goal) => {
              const linkedTasks = tasks
                .filter((t) => t.goalId === goal.id)
                .sort((a, b) => {
                  if (a.date !== b.date) return a.date.localeCompare(b.date);
                  return a.startTime.localeCompare(b.startTime);
                });

              const completedDeliverables = linkedTasks.filter((t) => t.completed);
              const pendingDeliverables = linkedTasks.filter((t) => !t.completed);
              const totalCount = linkedTasks.length || goal.totalTargetDays || 1;
              const doneCount =
                linkedTasks.length > 0 ? completedDeliverables.length : goal.completedDays;
              const progressPct = Math.min(100, Math.round((doneCount / totalCount) * 100));

              const nextDeliverable = pendingDeliverables[0] || null;
              const lastCompletedDeliverable =
                completedDeliverables[completedDeliverables.length - 1] || null;

              const currentFilter = goalFilterById[goal.id] || 'all';
              const filteredDeliverables =
                currentFilter === 'pending'
                  ? pendingDeliverables
                  : currentFilter === 'completed'
                  ? completedDeliverables
                  : linkedTasks;

              const newDelivTitle = newDeliverableTitleById[goal.id] || '';
              const newDelivDate = newDeliverableDateById[goal.id] || getTodayStr();

              return (
                <div
                  key={goal.id}
                  className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 space-y-4"
                >
                  {/* Goal Header & Deliverable-Based Progress % */}
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                    <div className="space-y-1">
                      <h4 className="text-base font-bold text-slate-900 dark:text-slate-100">
                        🎯 {goal.title}
                      </h4>
                      <p className="text-xs text-slate-600 dark:text-slate-300">
                        {goal.description}
                      </p>
                      <div className="flex flex-wrap items-center gap-2 pt-1 text-xs text-slate-500 dark:text-slate-400">
                        <span className="inline-flex items-center gap-1">
                          <Calendar className="w-3.5 h-3.5 text-indigo-500" />
                          Đích đến:{' '}
                          <strong className="font-mono tabular-nums">{goal.targetDate}</strong>
                        </span>
                        <span aria-hidden="true">·</span>
                        <span className="inline-flex items-center gap-1">
                          <ListChecks className="w-3.5 h-3.5 text-emerald-500" />
                          Tính % theo:{' '}
                          <strong className="text-emerald-600 dark:text-emerald-400">
                            Hạng mục hoàn thành thực tế
                          </strong>
                        </span>
                      </div>
                    </div>

                    <div className="sm:text-right shrink-0 bg-indigo-50/70 dark:bg-indigo-950/40 border border-indigo-200/70 dark:border-indigo-800/60 px-3.5 py-2 rounded-2xl">
                      <span className="text-2xl font-extrabold font-mono tabular-nums text-indigo-600 dark:text-indigo-400">
                        {progressPct}%
                      </span>
                      <span className="block text-[11px] font-mono tabular-nums font-semibold text-slate-600 dark:text-slate-300">
                        Đã xong {doneCount}/{totalCount} hạng mục
                      </span>
                    </div>
                  </div>

                  {/* Progress Bar */}
                  <div className="w-full h-2.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-emerald-500 rounded-full transition-all duration-300"
                      style={{ width: `${progressPct}%` }}
                    />
                  </div>

                  {/* Highlight: What was recently completed & What concrete deliverable is next */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                    <div className="p-3 rounded-xl bg-amber-50/70 dark:bg-amber-950/20 border border-amber-200/70 dark:border-amber-800/50 flex items-center justify-between gap-2">
                      <div className="min-w-0">
                        <span className="text-[10px] font-bold uppercase tracking-wider text-amber-700 dark:text-amber-400">
                          Hạng mục cần hoàn thành tiếp theo:
                        </span>
                        <p className="text-xs font-bold text-slate-900 dark:text-white truncate mt-0.5">
                          {nextDeliverable
                            ? `${nextDeliverable.title} (${nextDeliverable.date})`
                            : 'Tất cả hạng mục đã hoàn thành!'}
                        </p>
                      </div>
                      {nextDeliverable && (
                        <button
                          type="button"
                          onClick={() => onToggleTask(nextDeliverable.id)}
                          className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-bold flex items-center gap-1 shrink-0 transition-colors"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Hoàn thành mục này</span>
                        </button>
                      )}
                    </div>

                    <div className="p-3 rounded-xl bg-emerald-50/60 dark:bg-emerald-950/20 border border-emerald-200/70 dark:border-emerald-800/50 flex items-center justify-between gap-2">
                      <div className="min-w-0">
                        <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700 dark:text-emerald-400">
                          Hạng mục vừa hoàn thành gần nhất:
                        </span>
                        <p className="text-xs font-semibold text-slate-800 dark:text-slate-200 truncate mt-0.5">
                          {lastCompletedDeliverable
                            ? `✓ ${lastCompletedDeliverable.title}`
                            : 'Chưa có hạng mục nào được tích xong'}
                        </p>
                      </div>
                      <span className="text-xs font-mono font-bold text-emerald-600 dark:text-emerald-400 shrink-0">
                        +{totalCount > 0 ? Math.round(100 / totalCount) : 0}%/mục
                      </span>
                    </div>
                  </div>

                  {/* Interactive Deliverable Checklist ("Hoàn thành cái gì") */}
                  <div className="space-y-2.5 pt-1">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="text-xs font-bold text-slate-700 dark:text-slate-200 flex items-center gap-1.5">
                        <ListChecks className="w-4 h-4 text-indigo-500" />
                        <span>
                          Danh sách hạng mục công việc cụ thể (Tích vào mục đã làm xong để tăng %):
                        </span>
                      </div>

                      {/* Filter Tabs */}
                      <div className="inline-flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl text-[11px] font-semibold">
                        <button
                          type="button"
                          onClick={() =>
                            setGoalFilterById((prev) => ({ ...prev, [goal.id]: 'all' }))
                          }
                          className={`px-2.5 py-1 rounded-lg transition-colors ${
                            currentFilter === 'all'
                              ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-2xs'
                              : 'text-slate-500'
                          }`}
                        >
                          Tất cả ({linkedTasks.length})
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            setGoalFilterById((prev) => ({ ...prev, [goal.id]: 'pending' }))
                          }
                          className={`px-2.5 py-1 rounded-lg transition-colors ${
                            currentFilter === 'pending'
                              ? 'bg-white dark:bg-slate-900 text-amber-600 dark:text-amber-400 shadow-2xs'
                              : 'text-slate-500'
                          }`}
                        >
                          Chưa xong ({pendingDeliverables.length})
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            setGoalFilterById((prev) => ({ ...prev, [goal.id]: 'completed' }))
                          }
                          className={`px-2.5 py-1 rounded-lg transition-colors ${
                            currentFilter === 'completed'
                              ? 'bg-white dark:bg-slate-900 text-emerald-600 dark:text-emerald-400 shadow-2xs'
                              : 'text-slate-500'
                          }`}
                        >
                          Đã hoàn thành ({completedDeliverables.length})
                        </button>
                      </div>
                    </div>

                    {filteredDeliverables.length > 0 ? (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-80 overflow-y-auto pr-1">
                        {filteredDeliverables.map((lt) => (
                          <div
                            key={lt.id}
                            className={`p-3 rounded-xl border text-xs flex items-center justify-between gap-2 transition-colors ${
                              lt.completed
                                ? 'bg-emerald-50/40 dark:bg-emerald-950/20 border-emerald-200/70 dark:border-emerald-900/50'
                                : 'bg-slate-50 dark:bg-slate-950 border-slate-200/70 dark:border-slate-800'
                            }`}
                          >
                            <div
                              onClick={() => onToggleTask(lt.id)}
                              className="flex items-start gap-2.5 min-w-0 flex-1 cursor-pointer select-none"
                            >
                              <button
                                type="button"
                                className="mt-0.5 shrink-0 text-slate-400 hover:text-emerald-500"
                              >
                                {lt.completed ? (
                                  <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                                ) : (
                                  <Circle className="w-4 h-4" />
                                )}
                              </button>
                              <div className="min-w-0 flex-1">
                                <div className="flex items-center gap-1.5">
                                  <span className="font-mono font-bold text-[10px] text-indigo-600 dark:text-indigo-400">
                                    {lt.date.slice(8, 10)}/{lt.date.slice(5, 7)}/{lt.date.slice(0, 4)}
                                  </span>
                                  <span className="font-mono tabular-nums text-[10px] text-slate-400">
                                    {lt.startTime}–{lt.endTime}
                                  </span>
                                </div>
                                <p
                                  className={`mt-0.5 leading-snug ${
                                    lt.completed
                                      ? 'line-through text-slate-400 dark:text-slate-500'
                                      : 'text-slate-900 dark:text-slate-100 font-semibold'
                                  }`}
                                >
                                  {lt.title}
                                </p>
                              </div>
                            </div>

                            <div className="flex items-center gap-1 shrink-0">
                              {onJumpToScheduleDate && (
                                <button
                                  type="button"
                                  onClick={() => onJumpToScheduleDate(lt.date)}
                                  className="px-2 py-1 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-[10px] font-semibold text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50"
                                >
                                  Ngày
                                </button>
                              )}
                              <button
                                type="button"
                                onClick={() => onDeleteTask(lt.id)}
                                className="p-1 rounded-lg text-slate-400 hover:text-rose-500"
                                title="Xóa hạng mục này"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-xs text-slate-400 italic py-2">
                        Không có hạng mục nào trong bộ lọc này.
                      </p>
                    )}

                    {/* Quick Add Custom Deliverable to this Goal */}
                    <form
                      onSubmit={(e) => {
                        e.preventDefault();
                        if (!newDelivTitle.trim()) return;
                        onAddGoalDeliverable(goal.id, newDelivTitle, newDelivDate);
                        setNewDeliverableTitleById((prev) => ({ ...prev, [goal.id]: '' }));
                      }}
                      className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-100 dark:border-slate-800/80"
                    >
                      <input
                        type="text"
                        value={newDelivTitle}
                        onChange={(e) =>
                          setNewDeliverableTitleById((prev) => ({
                            ...prev,
                            [goal.id]: e.target.value,
                          }))
                        }
                        placeholder="+ Thêm hạng mục / bài học cần hoàn thành vào mục tiêu này..."
                        className="flex-1 min-w-[200px] rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 px-3 py-1.5 text-xs text-slate-900 dark:text-slate-100"
                      />
                      <input
                        type="date"
                        value={newDelivDate}
                        onChange={(e) =>
                          setNewDeliverableDateById((prev) => ({
                            ...prev,
                            [goal.id]: e.target.value,
                          }))
                        }
                        className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 px-2.5 py-1.5 text-xs font-mono text-slate-900 dark:text-slate-100"
                      />
                      <button
                        type="submit"
                        className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center gap-1"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Thêm hạng mục</span>
                      </button>
                    </form>
                  </div>

                  {/* Footer Actions */}
                  <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                    <button
                      type="button"
                      onClick={() => onMarkGoalAchieved(goal.id)}
                      className="min-h-[38px] px-3.5 py-1.5 rounded-xl bg-emerald-600/10 hover:bg-emerald-600/20 text-emerald-600 dark:text-emerald-400 text-xs font-semibold flex items-center gap-1.5"
                    >
                      <Trophy className="w-4 h-4" />
                      Đánh dấu Hoàn thành 100% Mục tiêu
                    </button>
                    <button
                      type="button"
                      onClick={() => onDeleteGoal(goal.id)}
                      className="min-h-[38px] px-3 py-1.5 flex items-center justify-center gap-1 rounded-xl text-xs font-semibold text-rose-500 hover:bg-rose-500/10"
                    >
                      <Trash2 className="w-4 h-4" />
                      <span>Xóa mục tiêu</span>
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}

      {/* TAB 3: ACHIEVED GOALS ARCHIVE */}
      {activeTab === 'achieved' && (
        <div className="space-y-3.5">
          {achievedGoals.map((goal) => (
            <div
              key={goal.id}
              className="bg-white dark:bg-slate-900 rounded-2xl border border-emerald-500/30 p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2 text-xs text-emerald-600 dark:text-emerald-400 font-semibold">
                  <Trophy className="w-4 h-4" />
                  <span>Đã hoàn thành 100% các hạng mục ({goal.achievedDate || goal.targetDate})</span>
                </div>
                <h4 className="text-base font-bold text-slate-900 dark:text-slate-100">
                  {goal.title}
                </h4>
                <p className="text-xs text-slate-600 dark:text-slate-400">{goal.description}</p>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => onReopenGoal(goal.id)}
                  className="min-h-[40px] px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-medium text-slate-600 dark:text-slate-300 flex items-center gap-1.5"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  Mở lại
                </button>
                <button
                  type="button"
                  onClick={() => onDeleteGoal(goal.id)}
                  className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl text-rose-500 hover:bg-rose-500/10"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
