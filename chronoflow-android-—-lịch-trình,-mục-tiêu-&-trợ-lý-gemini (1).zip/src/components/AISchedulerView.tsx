import React, { useState, useRef, useEffect } from 'react';
import {
  Sparkles,
  Send,
  Brain,
  Trash2,
  ChevronDown,
  ChevronUp,
  RotateCcw,
} from 'lucide-react';
import {
  AIChatMessage,
  AIMemoryItem,
} from '../types';
import { VoiceRecorderTrigger } from './VoiceRecorderTrigger';

interface AISchedulerViewProps {
  messages: AIChatMessage[];
  memories: AIMemoryItem[];
  isSending: boolean;
  onSendMessage: (text: string) => Promise<void>;
  onClearChat: () => void;
  onDeleteMemory: (memoryId: string) => void;
}

const QUICK_PROMPTS = [
  'Mình có mục tiêu học 5 bài Toán và 3 bài Anh trong 4 ngày tới, tự chia lịch giúp mình',
  'Thứ 2 đến thứ 6 mình bận học ở trường từ 7h đến 11h15, khóa cố định lại',
  'Mình thường ăn tối và nghỉ ngơi tới 19h30 mới xong, chỉ xếp bài học sau 19h30 nhé',
  'Lịch hôm nay hơi căng, dời bớt 1 việc sang tối mai giúp mình',
  'Mỗi ngày nhắc mình học từ vựng 25 phút',
];

export const AISchedulerView: React.FC<AISchedulerViewProps> = ({
  messages,
  memories,
  isSending,
  onSendMessage,
  onClearChat,
  onDeleteMemory,
}) => {
  const [input, setInput] = useState('');
  const [showMemories, setShowMemories] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isSending]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isSending) return;
    const text = input.trim();
    setInput('');
    await onSendMessage(text);
  };

  const handleVoiceTranscript = async (text: string, autoSend?: boolean) => {
    if (autoSend) {
      await onSendMessage(text);
    } else {
      setInput((prev) => (prev ? `${prev} ${text}` : text));
    }
  };

  return (
    <div className="w-full max-w-full flex flex-col h-[calc(100dvh-8.5rem)] lg:h-[calc(100dvh-6rem)] bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden">
      {/* Top Chat Header + Collapsible Learned Habits Drawer */}
      <div className="shrink-0 px-4 py-3 border-b border-slate-200/80 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-900">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0">
            <div className="w-8 h-8 rounded-xl bg-indigo-600 text-white flex items-center justify-center shrink-0">
              <Sparkles className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <h2 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white truncate">
                Trợ lý AI Điều phối Lịch trình
              </h2>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                Nhắn tin hoặc ghi âm giọng nói để thêm việc, sửa lịch và dạy AI thói quen
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={() => setShowMemories((prev) => !prev)}
              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200"
            >
              <Brain className="w-3.5 h-3.5 text-emerald-500" />
              <span>Đã học ({memories.length})</span>
              {showMemories ? (
                <ChevronUp className="w-3.5 h-3.5" />
              ) : (
                <ChevronDown className="w-3.5 h-3.5" />
              )}
            </button>

            {messages.length > 0 && (
              <button
                type="button"
                onClick={onClearChat}
                className="p-1.5 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                title="Xóa đoạn hội thoại"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Collapsible Learned Memories Panel */}
        {showMemories && (
          <div className="mt-3 pt-2.5 border-t border-slate-200/70 dark:border-slate-800 max-h-36 overflow-y-auto space-y-1.5">
            {memories.length === 0 ? (
              <p className="text-[11px] text-slate-400">
                AI chưa lưu quy tắc cá nhân nào. Khi bạn trò chuyện hoặc ghi âm (VD: "mình hay ăn tối muộn tới 19h30"), AI sẽ tự động ghi nhớ tại đây để áp dụng cho các lần sau.
              </p>
            ) : (
              memories.map((mem) => (
                <div
                  key={mem.id}
                  className="flex items-center justify-between gap-2 px-2.5 py-1.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200/60 dark:border-slate-700 text-xs"
                >
                  <span className="text-slate-700 dark:text-slate-200 break-words min-w-0 flex-1">
                    {mem.content}
                  </span>
                  <button
                    type="button"
                    onClick={() => onDeleteMemory(mem.id)}
                    className="p-1 text-slate-400 hover:text-rose-500 shrink-0"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))
            )}
          </div>
        )}
      </div>

      {/* Scrollable Chat Messages Area */}
      <div className="flex-1 min-h-0 overflow-y-auto overflow-x-hidden p-4 space-y-3">
        {messages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center max-w-md mx-auto space-y-3 py-4">
            <div className="w-10 h-10 rounded-2xl bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
              <Sparkles className="w-5 h-5" />
            </div>
            <div className="space-y-1">
              <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100">
                Trò chuyện & Ghi âm giọng nói tự nhiên
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                Bấm nút <strong>Giọng nói</strong> ở thanh dưới cùng để nói trực tiếp (có sóng âm thời gian thực và AI chuyển thành chữ chuẩn xác), hoặc chọn nhanh một gợi ý dưới đây:
              </p>
            </div>
            <div className="w-full space-y-1.5 pt-2">
              {QUICK_PROMPTS.map((prompt) => (
                <button
                  key={prompt}
                  type="button"
                  onClick={() => onSendMessage(prompt)}
                  className="w-full text-left px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800/60 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 border border-slate-200/70 dark:border-slate-800 text-xs text-slate-700 dark:text-slate-300 transition-colors"
                >
                  “{prompt}”
                </button>
              ))}
            </div>
          </div>
        ) : (
          messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 text-xs sm:text-sm leading-relaxed break-words ${
                  msg.role === 'user'
                    ? 'bg-indigo-600 text-white'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-100'
                }`}
              >
                <p>{msg.text}</p>
                {msg.appliedChangesSummary && (
                  <div className="mt-1.5 pt-1.5 border-t border-slate-200/40 dark:border-slate-700 text-[11px] text-indigo-600 dark:text-indigo-400 font-semibold">
                    {msg.appliedChangesSummary}
                  </div>
                )}
              </div>
            </div>
          ))
        )}

        {isSending && (
          <div className="flex justify-start">
            <div className="rounded-2xl px-3.5 py-2.5 bg-slate-100 dark:bg-slate-800 text-xs text-slate-500 flex items-center gap-2">
              <Sparkles className="w-3.5 h-3.5 animate-spin text-indigo-500" />
              <span>AI đang sắp xếp lại lịch trình cho bạn...</span>
            </div>
          </div>
        )}
        <div ref={chatEndRef} />
      </div>

      {/* Bottom Docked Input Bar with Gemini/Claude Voice Recorder */}
      <form
        onSubmit={handleSubmit}
        className="shrink-0 p-3 border-t border-slate-200/80 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900 flex flex-wrap items-center gap-2"
      >
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Nhắn hoặc bấm Giọng nói để ra lệnh cho AI..."
          className="flex-1 min-w-[160px] px-3.5 py-2.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs sm:text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
        />

        <VoiceRecorderTrigger
          onTranscriptReady={handleVoiceTranscript}
          showAutoSendButton={true}
        />

        <button
          type="submit"
          disabled={isSending || !input.trim()}
          className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 disabled:opacity-40 text-white text-xs font-semibold flex items-center gap-1.5 shrink-0 transition-all"
        >
          <Send className="w-3.5 h-3.5" />
          <span>Gửi</span>
        </button>
      </form>
    </div>
  );
};
