import React, { useState, useEffect, useRef } from 'react';
import {
  Smartphone,
  Cloud,
  HardDrive,
  Bell,
  Download,
  Upload,
  RefreshCw,
  LogOut,
  Trash2,
  Sliders,
  Puzzle,
  RotateCcw,
  Link2,
  Check,
  Image as ImageIcon,
  ExternalLink,
  ZoomIn,
  ZoomOut,
  X,
  Sparkles,
} from 'lucide-react';
import { User } from 'firebase/auth';
import {
  ScheduleTask,
  GoalItem,
  AIMemoryItem,
  WidgetSize,
  DriveBackupFile,
  AppPreferences,
  ScheduleDisplayFormat,
  ScheduleViewMode,
  SchoolPortalSyncConfig,
  TimetablePhotoItem,
  getTodayStr,
  unwrapSchoolUrl,
} from '../types';
import {
  listDriveBackups,
  uploadBackupToDrive,
  downloadBackupFromDrive,
  deleteBackupFromDrive,
  ChronoFlowBackupPayload,
} from '../services/driveService';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { VoiceRecorderTrigger } from './VoiceRecorderTrigger';

interface WidgetCloudApkViewProps {
  user: User | null;
  accessToken: string | null;
  tasks: ScheduleTask[];
  goals: GoalItem[];
  memories: AIMemoryItem[];
  preferences: AppPreferences;
  onUpdatePreferences: (next: AppPreferences) => void;
  schoolSyncConfig: SchoolPortalSyncConfig;
  onUpdateSchoolSyncConfig: (next: SchoolPortalSyncConfig) => void;
  onExtractTimetableFromImageOrNote: (
    imageDataUrl: string,
    personalNote: string,
    schoolUrl: string
  ) => Promise<void>;
  isExtractingTimetable: boolean;
  pinnedWidgetSize: WidgetSize;
  notificationsEnabled: boolean;
  lastDriveBackupAt: string;
  onChangeWidgetSize: (size: WidgetSize) => void;
  onToggleNotifications: () => void;
  onTestPushNotification: () => void;
  onGoogleLogin: () => Promise<void>;
  onGoogleLogout: () => Promise<void>;
  onRestoreBackupData: (payload: ChronoFlowBackupPayload) => Promise<void>;
  onRecordDriveBackupTime: (timestampStr: string) => void;
  onResetAllDataToBlank: () => void;
}

export const WidgetCloudApkView: React.FC<WidgetCloudApkViewProps> = ({
  user,
  accessToken,
  tasks,
  goals,
  memories,
  preferences,
  onUpdatePreferences,
  schoolSyncConfig,
  onUpdateSchoolSyncConfig,
  onExtractTimetableFromImageOrNote,
  isExtractingTimetable,
  pinnedWidgetSize,
  notificationsEnabled,
  lastDriveBackupAt,
  onToggleNotifications,
  onTestPushNotification,
  onGoogleLogin,
  onGoogleLogout,
  onRestoreBackupData,
  onRecordDriveBackupTime,
  onResetAllDataToBlank,
}) => {
  const { isInstallable, isInstalled, install } = usePWAInstall();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const tkbPhotoInputRef = useRef<HTMLInputElement>(null);

  const [driveFiles, setDriveFiles] = useState<DriveBackupFile[]>([]);
  const [isLoadingDrive, setIsLoadingDrive] = useState(false);
  const [driveStatusMsg, setDriveStatusMsg] = useState<string | null>(null);
  const [driveErrorMsg, setDriveErrorMsg] = useState<string | null>(null);
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [savedStorageLink, setSavedStorageLink] = useState(false);
  const [activePhotoLightbox, setActivePhotoLightbox] = useState<TimetablePhotoItem | null>(null);
  const [zoomScale, setZoomScale] = useState(1);

  const [confirmDialog, setConfirmDialog] = useState<{
    title: string;
    description: string;
    confirmLabel: string;
    onConfirm: () => Promise<void> | void;
  } | null>(null);

  const today = getTodayStr();
  const sharedAppUrl = 'https://ais-pre-xin6pjlwh7p3kub7b6qw2g-16945603543.asia-southeast1.run.app';

  const fetchDriveFileList = async (token: string) => {
    setIsLoadingDrive(true);
    setDriveErrorMsg(null);
    try {
      const files = await listDriveBackups(token);
      setDriveFiles(files);
    } catch (err: unknown) {
      setDriveErrorMsg(
        err instanceof Error ? err.message : 'Không thể tải danh sách file từ Google Drive.'
      );
    } finally {
      setIsLoadingDrive(false);
    }
  };

  useEffect(() => {
    if (accessToken) {
      fetchDriveFileList(accessToken);
    } else {
      setDriveFiles([]);
    }
  }, [accessToken]);

  const buildBackupPayload = (): ChronoFlowBackupPayload => ({
    appVersion: '2.0.0-minimal-realtime',
    exportedAt: new Date().toISOString(),
    tasks,
    goals,
    memories,
    settings: {
      pinnedWidgetSize,
      notificationsEnabled,
      lastDriveBackupAt: new Date().toISOString(),
    },
  });

  const handleCopyAppUrl = () => {
    navigator.clipboard.writeText(sharedAppUrl);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2500);
  };

  const handleBackupToDriveRequest = (existingFile?: DriveBackupFile) => {
    if (!accessToken) return;
    setConfirmDialog({
      title: existingFile
        ? 'Ghi đè bản sao lưu trên Google Drive?'
        : 'Tạo bản sao lưu mới trên Google Drive?',
      description: `Lưu ${tasks.length} hoạt động, ${goals.length} mục tiêu và ${memories.length} ghi nhớ AI lên Google Drive cá nhân của bạn.`,
      confirmLabel: existingFile ? 'Ghi đè' : 'Sao lưu ngay',
      onConfirm: async () => {
        setIsLoadingDrive(true);
        setDriveErrorMsg(null);
        try {
          const uploaded = await uploadBackupToDrive(
            accessToken,
            buildBackupPayload(),
            existingFile?.id
          );
          const nowStr = new Date().toLocaleString('vi-VN');
          onRecordDriveBackupTime(nowStr);
          setDriveStatusMsg(`Đã sao lưu "${uploaded.name}" lên Google Drive.`);
          await fetchDriveFileList(accessToken);
        } catch (err: unknown) {
          setDriveErrorMsg(err instanceof Error ? err.message : 'Lỗi sao lưu Google Drive.');
        } finally {
          setIsLoadingDrive(false);
        }
      },
    });
  };

  const handleRestoreFromDriveRequest = (file: DriveBackupFile) => {
    if (!accessToken) return;
    setConfirmDialog({
      title: 'Khôi phục dữ liệu từ Google Drive?',
      description: `Dữ liệu hiện tại sẽ được thay thế bằng bản sao lưu "${file.name}".`,
      confirmLabel: 'Khôi phục',
      onConfirm: async () => {
        setIsLoadingDrive(true);
        setDriveErrorMsg(null);
        try {
          const payload = await downloadBackupFromDrive(accessToken, file.id);
          await onRestoreBackupData(payload);
          setDriveStatusMsg(`Đã khôi phục dữ liệu từ "${file.name}".`);
        } catch (err: unknown) {
          setDriveErrorMsg(err instanceof Error ? err.message : 'Khôi phục thất bại.');
        } finally {
          setIsLoadingDrive(false);
        }
      },
    });
  };

  const handleDeleteDriveFileRequest = (file: DriveBackupFile) => {
    if (!accessToken) return;
    setConfirmDialog({
      title: 'Xóa bản sao lưu trên Google Drive?',
      description: `Xóa vĩnh viễn tệp "${file.name}" khỏi Google Drive?`,
      confirmLabel: 'Xóa',
      onConfirm: async () => {
        setIsLoadingDrive(true);
        try {
          await deleteBackupFromDrive(accessToken, file.id);
          await fetchDriveFileList(accessToken);
        } finally {
          setIsLoadingDrive(false);
        }
      },
    });
  };

  const handleExportICS = () => {
    const lines = [
      'BEGIN:VCALENDAR',
      'VERSION:2.0',
      'PRODID:-//ChronoFlow//Schedule Export//VI',
      'CALSCALE:GREGORIAN',
      'METHOD:PUBLISH',
    ];
    tasks.forEach((t) => {
      const dateCompact = t.date.replace(/-/g, '');
      const startCompact = t.startTime.replace(':', '') + '00';
      const endCompact = t.endTime.replace(':', '') + '00';
      lines.push(
        'BEGIN:VEVENT',
        `UID:${t.id}@chronoflow.app`,
        `DTSTART:${dateCompact}T${startCompact}`,
        `DTEND:${dateCompact}T${endCompact}`,
        `SUMMARY:${t.title}`,
        `DESCRIPTION:${(t.notes || '').replace(/\n/g, ' ')}`,
        'END:VEVENT'
      );
    });
    lines.push('END:VCALENDAR');
    const blob = new Blob([lines.join('\r\n')], { type: 'text/calendar;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ChronoFlow_Lich_${today}.ics`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleExportCSV = () => {
    const header = ['Ngày', 'Bắt đầu', 'Kết thúc', 'Hoạt động', 'Trạng thái', 'Ghi chú'];
    const rows = tasks.map((t) => [
      t.date,
      t.startTime,
      t.endTime,
      `"${t.title.replace(/"/g, '""')}"`,
      t.completed ? 'Đã xong' : 'Chưa xong',
      `"${(t.notes || '').replace(/"/g, '""')}"`,
    ]);
    const csvContent = '\uFEFF' + [header.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ChronoFlow_Excel_${today}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleExportLocalJson = () => {
    const payload = buildBackupPayload();
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ChronoFlow_Backup_${today}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImportJsonFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async (ev) => {
      try {
        const parsed = JSON.parse(String(ev.target?.result || '{}'));
        await onRestoreBackupData(parsed);
        setDriveStatusMsg('Đã nhập dữ liệu sao lưu thành công!');
      } catch {
        setDriveErrorMsg('File JSON không hợp lệ.');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  return (
    <div className="space-y-4 pb-6">
      {/* 1. CHẾ ĐỘ XEM LỊCH MẶC ĐỊNH (SINGLE ACTIVE VIEW - KHÔNG GHÉP NHIỀU CHẾ ĐỘ GÂY RỐI) */}
      <section className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-4 space-y-3 shadow-xs">
        <div className="flex items-center gap-2">
          <Sliders className="w-4 h-4 text-indigo-500" />
          <h3 className="text-sm font-bold text-slate-900 dark:text-white">
            1. Chế độ hiển thị Lịch trình (Giữ trang chính tối giản)
          </h3>
        </div>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          Trang Lịch trình sẽ chỉ hiển thị duy nhất 1 kiểu bạn chọn dưới đây để không bị rối mắt.
        </p>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {(
            [
              { id: 'timeline', label: 'Dòng thời gian thực', desc: 'Rõ ràng, dễ nhìn nhất' },
              { id: 'gantt', label: 'Biểu đồ Gantt', desc: 'Thanh tiến độ theo giờ' },
              { id: 'list', label: 'Danh sách tối giản', desc: 'Gọn nhẹ, tập trung' },
              { id: 'kanban', label: 'Bảng Kanban', desc: 'Chia cột trạng thái' },
            ] as { id: ScheduleDisplayFormat; label: string; desc: string }[]
          ).map((fmt) => {
            const active = preferences.defaultDisplayFormat === fmt.id;
            return (
              <button
                key={fmt.id}
                type="button"
                onClick={() =>
                  onUpdatePreferences({ ...preferences, defaultDisplayFormat: fmt.id })
                }
                className={`p-3 rounded-xl border text-left transition-all ${
                  active
                    ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                    : 'bg-slate-50 dark:bg-slate-800/50 text-slate-800 dark:text-slate-200 border-slate-200/70 dark:border-slate-700 hover:border-indigo-400'
                }`}
              >
                <div className="text-xs font-bold">{fmt.label}</div>
                <div className={`text-[10px] mt-0.5 ${active ? 'text-indigo-100' : 'text-slate-400'}`}>
                  {fmt.desc}
                </div>
              </button>
            );
          })}
        </div>

        <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
          <span className="text-xs font-medium text-slate-700 dark:text-slate-300">
            Khoảng ngày hiển thị mặc định:
          </span>
          <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-xl">
            {(
              [
                { id: 'day', label: 'Chỉ hôm nay' },
                { id: 'multiday', label: '3 ngày tới' },
                { id: 'week', label: '7 ngày' },
              ] as { id: ScheduleViewMode; label: string }[]
            ).map((m) => (
              <button
                key={m.id}
                type="button"
                onClick={() => onUpdatePreferences({ ...preferences, defaultViewMode: m.id })}
                className={`px-3 py-1 rounded-lg text-xs font-semibold ${
                  preferences.defaultViewMode === m.id
                    ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-2xs'
                    : 'text-slate-500'
                }`}
              >
                {m.label}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* 2. PHẦN MỞ RỘNG (BẬT KHI CẦN DÙNG, TẮT ĐỂ TỐI GIẢN) */}
      <section className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-4 space-y-3 shadow-xs">
        <div className="flex items-center gap-2">
          <Puzzle className="w-4 h-4 text-emerald-500" />
          <h3 className="text-sm font-bold text-slate-900 dark:text-white">
            2. Chế độ Mở rộng (Chỉ bật tính năng khi bạn muốn dùng)
          </h3>
        </div>

        <div className="space-y-2">
          {/* Timetable Note, Universal School Link & Image Viewer */}
          <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/70 dark:border-slate-800 space-y-3">
            <div className="flex items-center justify-between gap-2">
              <div>
                <div className="text-xs font-bold text-slate-800 dark:text-slate-100">
                  Thời khóa biểu: Ghi chú của tôi, Đường link Trường & Xem TKB bằng Ảnh
                </div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400">
                  Nhập ghi chú tự do, dán đường link trường bất kỳ hoặc tải ảnh TKB để xem và khóa giờ học
                </div>
              </div>
              <button
                type="button"
                onClick={() =>
                  onUpdatePreferences({
                    ...preferences,
                    enableSchoolSync: !preferences.enableSchoolSync,
                  })
                }
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold shrink-0 ${
                  preferences.enableSchoolSync
                    ? 'bg-emerald-600 text-white'
                    : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                }`}
              >
                {preferences.enableSchoolSync ? 'Đang mở' : 'Mở cấu hình'}
              </button>
            </div>

            {preferences.enableSchoolSync && (
              <div className="pt-2.5 border-t border-slate-200/60 dark:border-slate-700 space-y-3">
                {/* 1. Personal Timetable Note (replaces class selector) */}
                <div className="space-y-1">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-semibold text-slate-700 dark:text-slate-200">
                      Ghi chú Thời khóa biểu của tôi:
                    </label>
                    <VoiceRecorderTrigger
                      compact
                      showAutoSendButton={false}
                      onTranscriptReady={(txt) =>
                        onUpdateSchoolSyncConfig({
                          ...schoolSyncConfig,
                          personalNote: schoolSyncConfig.personalNote
                            ? `${schoolSyncConfig.personalNote}\n${txt}`
                            : txt,
                        })
                      }
                    />
                  </div>
                  <textarea
                    rows={3}
                    value={schoolSyncConfig.personalNote || ''}
                    onChange={(e) =>
                      onUpdateSchoolSyncConfig({
                        ...schoolSyncConfig,
                        personalNote: e.target.value,
                      })
                    }
                    placeholder="Ghi chú lịch học cố định, phòng học, ca học hoặc lưu ý cá nhân (AI sẽ dựa vào ghi chú này để né giờ bận)..."
                    className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-slate-800 dark:text-slate-100 placeholder:text-slate-400"
                  />
                </div>

                {/* 2. Universal School Link (supports any school) */}
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-1.5">
                    <Link2 className="w-3.5 h-3.5 text-indigo-500" />
                    Đường link liên kết tới trường học của bạn:
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="url"
                      value={schoolSyncConfig.schoolUrl || ''}
                      onChange={(e) =>
                        onUpdateSchoolSyncConfig({
                          ...schoolSyncConfig,
                          schoolUrl: e.target.value,
                        })
                      }
                      placeholder="https://... (Dán link cổng thông tin hoặc trang Thời khóa biểu của bất kỳ trường nào)"
                      className="flex-1 min-w-0 px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-slate-800 dark:text-slate-100 placeholder:text-slate-400"
                    />
                    {schoolSyncConfig.schoolUrl && (
                      <a
                        href={unwrapSchoolUrl(schoolSyncConfig.schoolUrl)}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-3 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold inline-flex items-center gap-1.5 shrink-0"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                        <span>Mở link</span>
                      </a>
                    )}
                  </div>
                </div>

                {/* 3. Timetable Image Upload & Viewer */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-1.5">
                      <ImageIcon className="w-3.5 h-3.5 text-emerald-500" />
                      Xem Thời khóa biểu bằng Ảnh ({(schoolSyncConfig.timetablePhotos || []).length}):
                    </span>
                    <button
                      type="button"
                      onClick={() => tkbPhotoInputRef.current?.click()}
                      className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold inline-flex items-center gap-1.5"
                    >
                      <Upload className="w-3.5 h-3.5" />
                      <span>Thêm ảnh TKB</span>
                    </button>
                    <input
                      ref={tkbPhotoInputRef}
                      type="file"
                      accept="image/*"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (!file) return;
                        const reader = new FileReader();
                        reader.onload = () => {
                          const dataUrl = String(reader.result || '');
                          if (!dataUrl) return;
                          const newPhoto: TimetablePhotoItem = {
                            id: `tkb_img_${Date.now()}`,
                            title: file.name || `Ảnh TKB (${new Date().toLocaleDateString('vi-VN')})`,
                            dataUrl,
                            addedAt: new Date().toLocaleString('vi-VN'),
                          };
                          onUpdateSchoolSyncConfig({
                            ...schoolSyncConfig,
                            timetablePhotos: [newPhoto, ...(schoolSyncConfig.timetablePhotos || [])],
                          });
                        };
                        reader.readAsDataURL(file);
                        e.target.value = '';
                      }}
                      className="hidden"
                    />
                  </div>

                  {(schoolSyncConfig.timetablePhotos || []).length === 0 ? (
                    <div className="p-4 rounded-xl border border-dashed border-slate-300 dark:border-slate-700 text-center text-xs text-slate-400">
                      Chưa có ảnh Thời khóa biểu nào. Bấm "Thêm ảnh TKB" để lưu ảnh và xem trực tiếp trong ứng dụng.
                    </div>
                  ) : (
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                      {(schoolSyncConfig.timetablePhotos || []).map((photo) => (
                        <div
                          key={photo.id}
                          className="group relative rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700 bg-slate-900 h-28"
                        >
                          <img
                            src={photo.dataUrl}
                            alt={photo.title}
                            onClick={() => {
                              setZoomScale(1);
                              setActivePhotoLightbox(photo);
                            }}
                            className="w-full h-full object-cover cursor-pointer group-hover:opacity-90"
                          />
                          <div className="absolute inset-x-0 bottom-0 bg-black/70 px-2 py-1 flex items-center justify-between text-white">
                            <button
                              type="button"
                              onClick={() => {
                                setZoomScale(1);
                                setActivePhotoLightbox(photo);
                              }}
                              className="text-[11px] font-semibold flex items-center gap-1 truncate"
                            >
                              <ZoomIn className="w-3 h-3 shrink-0" />
                              <span className="truncate">Phóng to ảnh</span>
                            </button>
                            <button
                              type="button"
                              onClick={() =>
                                onUpdateSchoolSyncConfig({
                                  ...schoolSyncConfig,
                                  timetablePhotos: (schoolSyncConfig.timetablePhotos || []).filter(
                                    (p) => p.id !== photo.id
                                  ),
                                })
                              }
                              className="p-1 text-rose-400 hover:text-rose-300"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  <button
                    type="button"
                    disabled={
                      isExtractingTimetable ||
                      (!(schoolSyncConfig.timetablePhotos || [])[0]?.dataUrl &&
                        !(schoolSyncConfig.personalNote || '').trim() &&
                        !(schoolSyncConfig.schoolUrl || '').trim())
                    }
                    onClick={() =>
                      onExtractTimetableFromImageOrNote(
                        (schoolSyncConfig.timetablePhotos || [])[0]?.dataUrl || '',
                        schoolSyncConfig.personalNote || '',
                        schoolSyncConfig.schoolUrl || ''
                      )
                    }
                    className="w-full py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-40 text-white text-xs font-bold flex items-center justify-center gap-1.5"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>
                      {isExtractingTimetable
                        ? 'AI đang đọc Ảnh TKB & Ghi chú...'
                        : 'Nhờ AI đọc Ảnh TKB & Ghi chú để tự động khóa giờ học'}
                    </span>
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Toggle Goals Tab */}
          <div className="flex items-center justify-between gap-2 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/70 dark:border-slate-800">
            <div>
              <div className="text-xs font-bold text-slate-800 dark:text-slate-100">
                Hiện mục Quản lý Mục tiêu & Chuỗi Streak trên thanh điều hướng
              </div>
              <div className="text-[11px] text-slate-500 dark:text-slate-400">
                Bật khi bạn muốn theo dõi bảng tiến độ mục tiêu dài hạn riêng biệt
              </div>
            </div>
            <button
              type="button"
              onClick={() =>
                onUpdatePreferences({
                  ...preferences,
                  enableGoalsTab: !preferences.enableGoalsTab,
                })
              }
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold shrink-0 ${
                preferences.enableGoalsTab
                  ? 'bg-indigo-600 text-white'
                  : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
              }`}
            >
              {preferences.enableGoalsTab ? 'Đang bật' : 'Đang tắt'}
            </button>
          </div>

          {/* Toggle Analytics Tab */}
          <div className="flex items-center justify-between gap-2 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/70 dark:border-slate-800">
            <div>
              <div className="text-xs font-bold text-slate-800 dark:text-slate-100">
                Hiện mục Thống kê & Phân tích Hiệu suất trên thanh điều hướng
              </div>
              <div className="text-[11px] text-slate-500 dark:text-slate-400">
                Bật khi bạn muốn xem biểu đồ thống kê tuần và nhận xét từ AI
              </div>
            </div>
            <button
              type="button"
              onClick={() =>
                onUpdatePreferences({
                  ...preferences,
                  enableAnalyticsTab: !preferences.enableAnalyticsTab,
                })
              }
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold shrink-0 ${
                preferences.enableAnalyticsTab
                  ? 'bg-indigo-600 text-white'
                  : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
              }`}
            >
              {preferences.enableAnalyticsTab ? 'Đang bật' : 'Đang tắt'}
            </button>
          </div>
        </div>
      </section>

      {/* 3. LIÊN KẾT LƯU TRỮ, CHẠY RIÊNG & SAO LƯU ĐÁM MÂY */}
      <section className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-4 space-y-3 shadow-xs">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Cloud className="w-4 h-4 text-indigo-500" />
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              3. Liên kết Lưu trữ & Chạy độc lập
            </h3>
          </div>

          {user ? (
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 truncate max-w-[160px]">
                {user.email}
              </span>
              <button
                type="button"
                onClick={onGoogleLogout}
                className="px-2.5 py-1 rounded-lg border border-slate-200 dark:border-slate-700 text-xs text-slate-600 dark:text-slate-300 flex items-center gap-1"
              >
                <LogOut className="w-3 h-3" /> Thoát
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={onGoogleLogin}
              className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold flex items-center gap-1.5"
            >
              <Cloud className="w-3.5 h-3.5" />
              Liên kết Google / Drive
            </button>
          )}
        </div>

        {/* Custom Storage / Standalone Sync Endpoint */}
        <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/70 dark:border-slate-800 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-1.5">
              <Link2 className="w-3.5 h-3.5 text-indigo-500" />
              Liên kết Lưu trữ / Máy chủ riêng (Tùy chọn khi chạy app độc lập):
            </span>
            <span className="text-[11px] text-emerald-600 dark:text-emerald-400 font-medium">
              AI Server: Đã kết nối (/api/gemini)
            </span>
          </div>
          <div className="flex gap-2">
            <input
              type="text"
              value={preferences.customStorageUrl}
              onChange={(e) =>
                onUpdatePreferences({ ...preferences, customStorageUrl: e.target.value })
              }
              placeholder="Nhập URL liên kết lưu trữ đám mây / Webhook đồng bộ riêng (nếu có)..."
              className="flex-1 min-w-0 px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-slate-800 dark:text-slate-200"
            />
            <button
              type="button"
              onClick={() => {
                setSavedStorageLink(true);
                setTimeout(() => setSavedStorageLink(false), 2000);
              }}
              className="px-3 py-1.5 rounded-xl bg-slate-900 dark:bg-slate-700 text-white text-xs font-semibold flex items-center gap-1 shrink-0"
            >
              {savedStorageLink ? <Check className="w-3.5 h-3.5" /> : null}
              {savedStorageLink ? 'Đã lưu' : 'Lưu liên kết'}
            </button>
          </div>
          <p className="text-[11px] text-slate-400">
            Khi chạy riêng mã nguồn trên máy cá nhân, biến môi trường máy chủ được cấu hình trong tệp <code className="font-mono">.env</code> ở thư mục gốc.
          </p>
        </div>

        {/* Export / Import / Google Drive Buttons */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          <button
            type="button"
            onClick={handleExportLocalJson}
            className="px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-800 dark:text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5"
          >
            <Download className="w-3.5 h-3.5" /> Xuất file .JSON
          </button>
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-800 dark:text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5"
          >
            <Upload className="w-3.5 h-3.5" /> Nhập file .JSON
          </button>
          <button
            type="button"
            onClick={handleExportICS}
            className="px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-800 dark:text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5"
          >
            <Download className="w-3.5 h-3.5" /> Xuất Lịch (.ics)
          </button>
          <button
            type="button"
            onClick={handleExportCSV}
            className="px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-800 dark:text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5"
          >
            <Download className="w-3.5 h-3.5" /> Xuất Excel (.csv)
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept=".json,application/json"
            onChange={handleImportJsonFile}
            className="hidden"
          />
        </div>

        {accessToken && (
          <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                <HardDrive className="w-3.5 h-3.5 text-emerald-500" />
                Google Drive ({lastDriveBackupAt || 'Chưa sao lưu'})
              </span>
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  disabled={isLoadingDrive}
                  onClick={() => handleBackupToDriveRequest()}
                  className="px-3 py-1.5 rounded-lg bg-emerald-600 text-white text-xs font-semibold"
                >
                  + Sao lưu lên Drive
                </button>
                <button
                  type="button"
                  disabled={isLoadingDrive}
                  onClick={() => fetchDriveFileList(accessToken)}
                  className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-500"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isLoadingDrive ? 'animate-spin' : ''}`} />
                </button>
              </div>
            </div>

            {driveFiles.map((file) => (
              <div
                key={file.id}
                className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 text-xs"
              >
                <span className="font-medium truncate">{file.name}</span>
                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    type="button"
                    onClick={() => handleRestoreFromDriveRequest(file)}
                    className="px-2.5 py-1 rounded-md bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-semibold"
                  >
                    Khôi phục
                  </button>
                  <button
                    type="button"
                    onClick={() => handleDeleteDriveFileRequest(file)}
                    className="p-1 text-rose-500"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {driveStatusMsg && (
          <p className="text-xs text-emerald-600 dark:text-emerald-400">{driveStatusMsg}</p>
        )}
        {driveErrorMsg && (
          <p className="text-xs text-rose-600 dark:text-rose-400">{driveErrorMsg}</p>
        )}
      </section>

      {/* 4. CÀI ĐẶT APK ANDROID, THÔNG BÁO & LÀM MỚI TRẮNG DỮ LIỆU */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <section className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-4 space-y-2.5">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
              <Smartphone className="w-4 h-4 text-indigo-500" />
              Cài đặt App Android (APK / WebAPK) & Thông báo
            </h3>
            <button
              type="button"
              onClick={onToggleNotifications}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold flex items-center gap-1 ${
                notificationsEnabled
                  ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-500'
              }`}
            >
              <Bell className="w-3 h-3" />
              {notificationsEnabled ? 'Chuông báo: Bật' : 'Chuông báo: Tắt'}
            </button>
          </div>

          <div className="flex items-center gap-1.5">
            <input
              type="text"
              readOnly
              value={sharedAppUrl}
              className="flex-1 min-w-0 px-2.5 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-[11px] font-mono text-slate-600 dark:text-slate-300"
            />
            <button
              type="button"
              onClick={handleCopyAppUrl}
              className="px-3 py-1.5 rounded-lg bg-indigo-600 text-white text-xs font-semibold shrink-0"
            >
              {copiedUrl ? 'Đã chép' : 'Chép link'}
            </button>
          </div>

          <div className="flex flex-wrap gap-2 pt-1">
            {!isInstalled && isInstallable && (
              <button
                type="button"
                onClick={install}
                className="px-3 py-1.5 rounded-xl bg-indigo-600 text-white text-xs font-semibold"
              >
                Cài đặt App ngay
              </button>
            )}
            <a
              href={`https://www.pwabuilder.com/reportcard?site=${encodeURIComponent(sharedAppUrl)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-1.5 rounded-xl bg-emerald-600 text-white text-xs font-semibold inline-flex items-center gap-1"
            >
              <Download className="w-3.5 h-3.5" /> Xuất file .APK (PWABuilder)
            </a>
            <button
              type="button"
              onClick={onTestPushNotification}
              className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-medium"
            >
              Thử chuông báo
            </button>
          </div>
        </section>

        <section className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-4 flex flex-col justify-between space-y-2.5">
          <div>
            <h3 className="text-xs font-bold text-rose-600 dark:text-rose-400 flex items-center gap-1.5">
              <RotateCcw className="w-4 h-4" />
              Đặt lại Ứng dụng Mới hoàn toàn (Xóa trắng dữ liệu)
            </h3>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 leading-relaxed">
              Xóa toàn bộ lịch trình, mục tiêu, thời khóa biểu cố định và bộ nhớ AI để đưa ứng dụng về trạng thái trắng hoàn toàn như lúc mới cài đặt.
            </p>
          </div>

          <button
            type="button"
            onClick={() =>
              setConfirmDialog({
                title: 'Xóa trắng toàn bộ dữ liệu về như mới?',
                description:
                  'Tất cả công việc, mục tiêu, thói quen, lịch cố định và bộ nhớ AI sẽ được xóa sạch hoàn toàn để bạn bắt đầu từ đầu.',
                confirmLabel: 'Xác nhận xóa trắng 100%',
                onConfirm: () => {
                  onResetAllDataToBlank();
                },
              })
            }
            className="w-full py-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-600 dark:text-rose-400 border border-rose-500/30 text-xs font-bold transition-colors"
          >
            Làm mới trắng toàn bộ dữ liệu (Reset 100%)
          </button>
        </section>
      </div>

      {/* Confirmation Modal */}
      {confirmDialog && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 space-y-3 shadow-2xl">
            <h4 className="text-sm font-bold text-slate-900 dark:text-white">
              {confirmDialog.title}
            </h4>
            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              {confirmDialog.description}
            </p>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setConfirmDialog(null)}
                className="px-3.5 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                Hủy
              </button>
              <button
                type="button"
                onClick={async () => {
                  const fn = confirmDialog.onConfirm;
                  setConfirmDialog(null);
                  await fn();
                }}
                className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold"
              >
                {confirmDialog.confirmLabel}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Fullscreen Timetable Image Lightbox Viewer */}
      {activePhotoLightbox && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xs flex flex-col">
          <div className="shrink-0 px-4 py-3 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between gap-3 text-white">
            <div className="min-w-0">
              <h4 className="text-xs sm:text-sm font-bold truncate">
                {activePhotoLightbox.title}
              </h4>
              <p className="text-[10px] text-slate-400">
                Đã thêm: {activePhotoLightbox.addedAt}
              </p>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={() => setZoomScale((s) => Math.max(0.5, Number((s - 0.25).toFixed(2))))}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white"
                title="Thu nhỏ"
              >
                <ZoomOut className="w-4 h-4" />
              </button>
              <span className="text-xs font-mono tabular-nums px-2">
                {Math.round(zoomScale * 100)}%
              </span>
              <button
                type="button"
                onClick={() => setZoomScale((s) => Math.min(3, Number((s + 0.25).toFixed(2))))}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white"
                title="Phóng to"
              >
                <ZoomIn className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => setActivePhotoLightbox(null)}
                className="p-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white ml-2"
                title="Đóng"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="flex-1 overflow-auto flex items-center justify-center p-4">
            <img
              src={activePhotoLightbox.dataUrl}
              alt={activePhotoLightbox.title}
              style={{ transform: `scale(${zoomScale})`, transformOrigin: 'center center' }}
              className="max-w-full max-h-full object-contain rounded-lg transition-transform duration-150"
            />
          </div>
        </div>
      )}
    </div>
  );
};
