import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  CheckCircle2,
  Circle,
  ChevronLeft,
  ChevronRight,
  Trash2,
  Sparkles,
  Lock,
  Send,
  Clock,
  SlidersHorizontal,
  Flame,
  Radio,
  Image as ImageIcon,
  FileText,
  ExternalLink,
  Upload,
  ZoomIn,
  ZoomOut,
  X,
  Calendar as CalendarIcon,
  Link2,
  Target,
  ArrowRight,
} from 'lucide-react';
import {
  ScheduleTask,
  GoalItem,
  ScheduleDisplayFormat,
  ScheduleViewMode,
  LockedFixedBlock,
  DailyMinimumHabit,
  SchoolPortalSyncConfig,
  TimetablePhotoItem,
  formatDaysOfWeekBadge,
  getWeekdayFromDateStr,
  getTodayStr,
  addDaysStr,
  getMondayOfWeekStr,
  formatVietnameseDateFull,
  unwrapSchoolUrl,
} from '../types';
import { VoiceRecorderTrigger } from './VoiceRecorderTrigger';

interface ScheduleViewProps {
  tasks: ScheduleTask[];
  goals: GoalItem[];
  lockedBlocks: LockedFixedBlock[];
  dailyHabits: DailyMinimumHabit[];
  selectedDate: string;
  onSelectDate: (date: string) => void;
  displayFormat: ScheduleDisplayFormat;
  viewMode: ScheduleViewMode;
  schoolSyncConfig: SchoolPortalSyncConfig;
  onUpdateSchoolSyncConfig: (next: SchoolPortalSyncConfig) => void;
  onExtractTimetableFromImageOrNote: (
    imageDataUrl: string,
    personalNote: string,
    schoolUrl: string
  ) => Promise<void>;
  isExtractingTimetable: boolean;
  onToggleTask: (taskId: string) => void;
  onDeleteTask: (taskId: string) => void;
  onToggleDailyHabitForDate: (habitId: string, dateStr: string) => void;
  onDeleteDailyHabit: (habitId: string) => void;
  onDeleteLockedBlock: (blockId: string) => void;
  onSendAIChatCommand: (message: string) => Promise<string>;
  isAIChatLoading: boolean;
  lastAIReply: string | null;
  onOpenSettings: () => void;
  onOpenGoalsTab: () => void;
}

function timeToMinutes(t: string): number {
  const [h, m] = (t || '00:00').split(':').map(Number);
  return (h || 0) * 60 + (m || 0);
}

export const ScheduleView: React.FC<ScheduleViewProps> = ({
  tasks,
  goals,
  lockedBlocks,
  dailyHabits,
  selectedDate,
  onSelectDate,
  displayFormat,
  viewMode,
  schoolSyncConfig,
  onUpdateSchoolSyncConfig,
  onExtractTimetableFromImageOrNote,
  isExtractingTimetable,
  onToggleTask,
  onDeleteTask,
  onToggleDailyHabitForDate,
  onDeleteDailyHabit,
  onDeleteLockedBlock,
  onSendAIChatCommand,
  isAIChatLoading,
  lastAIReply,
  onOpenSettings,
  onOpenGoalsTab,
}) => {
  const [chatInput, setChatInput] = useState('');
  const [now, setNow] = useState<Date>(() => new Date());
  const [showTimetableDrawer, setShowTimetableDrawer] = useState(false);
  const [showGoalSchedulePanel, setShowGoalSchedulePanel] = useState(false);
  const [activePhotoLightbox, setActivePhotoLightbox] = useState<TimetablePhotoItem | null>(null);
  const [zoomScale, setZoomScale] = useState(1);
  const photoInputRef = useRef<HTMLInputElement>(null);
  const datePickerInputRef = useRef<HTMLInputElement>(null);

  // Real-time clock tick every second
  useEffect(() => {
    const timer = setInterval(() => {
      setNow(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Automatically open Goal Schedule panel when a new goal is added
  const prevGoalsCountRef = useRef(goals.length);
  useEffect(() => {
    if (goals.length > prevGoalsCountRef.current) {
      setShowGoalSchedulePanel(true);
    }
    prevGoalsCountRef.current = goals.length;
  }, [goals.length]);

  const todayStr = getTodayStr();
  const isViewingToday = selectedDate === todayStr;
  const nowMinutes = now.getHours() * 60 + now.getMinutes();
  const liveTimeStr = `${String(now.getHours()).padStart(2, '0')}:${String(
    now.getMinutes()
  ).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;
  const shortNowStr = liveTimeStr.slice(0, 5);

  // Fixed Monday-to-Sunday week strip: buttons NEVER shift or jump when clicking days within the week!
  const mondayOfSelectedWeek = useMemo(
    () => getMondayOfWeekStr(selectedDate),
    [selectedDate]
  );

  const weekDays = useMemo(() => {
    const dayLabels = ['T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN'];
    return Array.from({ length: 7 }, (_, idx) => {
      const dStr = addDaysStr(mondayOfSelectedWeek, idx);
      const wd = getWeekdayFromDateStr(dStr);
      const [, m, d] = dStr.split('-').map(Number);
      const hasItems =
        tasks.some((t) => t.date === dStr) ||
        lockedBlocks.some((b) => b.daysOfWeek.includes(wd)) ||
        dailyHabits.length > 0;
      const hasGoalTask = tasks.some((t) => t.date === dStr && Boolean(t.goalId));
      return {
        dateStr: dStr,
        dayName: dayLabels[idx],
        dayNum: d,
        monthNum: m,
        hasItems,
        hasGoalTask,
      };
    });
  }, [mondayOfSelectedWeek, tasks, lockedBlocks, dailyHabits]);

  const activeDates = useMemo(() => {
    if (viewMode === 'day') return [selectedDate];
    if (viewMode === 'multiday') {
      return [selectedDate, addDaysStr(selectedDate, 1), addDaysStr(selectedDate, 2)];
    }
    return Array.from({ length: 7 }, (_, i) => addDaysStr(mondayOfSelectedWeek, i));
  }, [selectedDate, viewMode, mondayOfSelectedWeek]);

  // Unified items for activeDates
  const unifiedItems = useMemo(() => {
    const list: {
      id: string;
      rawId: string;
      type: 'locked' | 'habit' | 'task';
      title: string;
      subtitle: string;
      date: string;
      startTime: string;
      endTime: string;
      completed: boolean;
      goalTitle?: string;
    }[] = [];

    const goalMap = new Map(goals.map((g) => [g.id, g.title]));

    for (const dStr of activeDates) {
      const wd = getWeekdayFromDateStr(dStr);

      lockedBlocks
        .filter((b) => b.daysOfWeek.includes(wd))
        .forEach((b) => {
          list.push({
            id: `lock_${b.id}_${dStr}`,
            rawId: b.id,
            type: 'locked',
            title: b.title,
            subtitle: `Cố định (${formatDaysOfWeekBadge(b.daysOfWeek)})`,
            date: dStr,
            startTime: b.startTime,
            endTime: b.endTime,
            completed: false,
          });
        });

      dailyHabits.forEach((h) => {
        const isDone = h.completedDates.includes(dStr);
        list.push({
          id: `habit_${h.id}_${dStr}`,
          rawId: h.id,
          type: 'habit',
          title: h.title,
          subtitle: `Hàng ngày · Streak ${h.currentStreak} ngày`,
          date: dStr,
          startTime: h.startTime,
          endTime: h.endTime,
          completed: isDone,
        });
      });

      tasks
        .filter((t) => t.date === dStr)
        .forEach((t) => {
          list.push({
            id: t.id,
            rawId: t.id,
            type: 'task',
            title: t.title,
            subtitle: t.notes || '',
            date: dStr,
            startTime: t.startTime,
            endTime: t.endTime,
            completed: t.completed,
            goalTitle: t.goalId ? goalMap.get(t.goalId) : undefined,
          });
        });
    }

    return list.sort((a, b) => {
      if (a.date !== b.date) return a.date.localeCompare(b.date);
      return a.startTime.localeCompare(b.startTime);
    });
  }, [activeDates, lockedBlocks, dailyHabits, tasks, goals]);

  // Multi-day Goal Schedule Roadmap data (for "Xem lịch nếu đặt mục tiêu")
  const goalScheduleGroups = useMemo(() => {
    const activeGoals = goals.filter((g) => !g.isAchieved);
    if (activeGoals.length > 0) {
      return activeGoals.map((goal) => {
        const goalTasks = tasks
          .filter((t) => t.goalId === goal.id)
          .sort((a, b) => {
            if (a.date !== b.date) return a.date.localeCompare(b.date);
            return a.startTime.localeCompare(b.startTime);
          });
        const doneCount = goalTasks.filter((t) => t.completed).length;
        const pct =
          goalTasks.length > 0
            ? Math.round((doneCount / goalTasks.length) * 100)
            : goal.progressPercent;
        return {
          goalId: goal.id,
          title: goal.title,
          description: goal.description,
          targetDate: goal.targetDate,
          progressPct: pct,
          doneCount,
          totalCount: goalTasks.length || goal.totalTargetDays,
          sessions: goalTasks,
        };
      });
    }

    // Even if user hasn't created a formal Goal object yet, if they have tasks across multiple future dates, show them as a multi-day roadmap
    const futureOrTodayTasks = tasks
      .filter((t) => t.date >= todayStr)
      .sort((a, b) => {
        if (a.date !== b.date) return a.date.localeCompare(b.date);
        return a.startTime.localeCompare(b.startTime);
      });
    const uniqueDates = new Set(futureOrTodayTasks.map((t) => t.date));
    if (uniqueDates.size >= 2) {
      const doneCount = futureOrTodayTasks.filter((t) => t.completed).length;
      return [
        {
          goalId: 'auto_multiday',
          title: 'Lộ trình công việc nhiều ngày đã xếp',
          description: `Trải dài trên ${uniqueDates.size} ngày`,
          targetDate: Array.from(uniqueDates).sort().pop() || todayStr,
          progressPct: Math.round((doneCount / futureOrTodayTasks.length) * 100),
          doneCount,
          totalCount: futureOrTodayTasks.length,
          sessions: futureOrTodayTasks,
        },
      ];
    }
    return [];
  }, [goals, tasks, todayStr]);

  // Today's items for real-time tracking
  const todayItems = useMemo(
    () => unifiedItems.filter((i) => i.date === selectedDate),
    [unifiedItems, selectedDate]
  );

  const realtimeStatus = useMemo(() => {
    if (!isViewingToday) return null;
    const currentItem = todayItems.find((item) => {
      const s = timeToMinutes(item.startTime);
      const e = timeToMinutes(item.endTime);
      return nowMinutes >= s && nowMinutes < e;
    });

    if (currentItem) {
      const s = timeToMinutes(currentItem.startTime);
      const e = timeToMinutes(currentItem.endTime);
      const total = Math.max(1, e - s);
      const elapsed = Math.max(0, nowMinutes - s);
      const remaining = Math.max(0, e - nowMinutes);
      const progressPct = Math.min(100, Math.round((elapsed / total) * 100));
      return {
        state: 'active' as const,
        item: currentItem,
        remainingMins: remaining,
        progressPct,
      };
    }

    const nextItem = todayItems.find((item) => timeToMinutes(item.startTime) > nowMinutes);
    if (nextItem) {
      const untilMins = timeToMinutes(nextItem.startTime) - nowMinutes;
      return {
        state: 'upcoming' as const,
        item: nextItem,
        untilMins,
      };
    }

    return { state: 'free' as const };
  }, [isViewingToday, todayItems, nowMinutes]);

  const handleQuickChatSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || isAIChatLoading) return;
    const msg = chatInput.trim();
    setChatInput('');
    await onSendAIChatCommand(msg);
  };

  const handleVoiceTranscript = async (text: string, autoSend?: boolean) => {
    if (autoSend) {
      await onSendAIChatCommand(text);
    } else {
      setChatInput((prev) => (prev ? `${prev} ${text}` : text));
    }
  };

  const handleUploadTimetablePhoto = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = String(reader.result || '');
      if (!dataUrl) return;
      const newPhoto: TimetablePhotoItem = {
        id: `tkb_img_${Date.now()}`,
        title: file.name || `Ảnh TKB (${new Date().toLocaleDateString('vi-VN')})`,
        dataUrl,
        addedAt: new Date().toLocaleString('vi-VN'),
      };
      const existing = schoolSyncConfig.timetablePhotos || [];
      onUpdateSchoolSyncConfig({
        ...schoolSyncConfig,
        timetablePhotos: [newPhoto, ...existing],
      });
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleDeleteTimetablePhoto = (photoId: string) => {
    const existing = schoolSyncConfig.timetablePhotos || [];
    onUpdateSchoolSyncConfig({
      ...schoolSyncConfig,
      timetablePhotos: existing.filter((p) => p.id !== photoId),
    });
    if (activePhotoLightbox?.id === photoId) {
      setActivePhotoLightbox(null);
    }
  };

  const handleToggleItem = (item: (typeof unifiedItems)[number]) => {
    if (item.type === 'locked') return;
    if (item.type === 'habit') {
      onToggleDailyHabitForDate(item.rawId, item.date);
    } else {
      onToggleTask(item.rawId);
    }
  };

  const handleDeleteItem = (item: (typeof unifiedItems)[number]) => {
    if (item.type === 'locked') {
      onDeleteLockedBlock(item.rawId);
    } else if (item.type === 'habit') {
      onDeleteDailyHabit(item.rawId);
    } else {
      onDeleteTask(item.rawId);
    }
  };

  const photosList = schoolSyncConfig.timetablePhotos || [];
  const personalNote = schoolSyncConfig.personalNote || '';

  return (
    <div className="space-y-3 pb-4">
      {/* 1. REAL-TIME LIVE BANNER + SMOOTH NON-JUMPING WEEK DATE PICKER */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-3.5 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-3">
        {/* Top Row: Live Clock + Selected Full Date + Goal Schedule Button + Timetable Photo/Note Button */}
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex flex-wrap items-center gap-2">
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 text-xs font-bold font-mono tabular-nums">
              <Radio className="w-3.5 h-3.5 animate-pulse" />
              {liveTimeStr}
            </span>

            {/* Smooth Week & Calendar Selector */}
            <div className="inline-flex items-center gap-1 bg-slate-100/80 dark:bg-slate-800/80 p-1 rounded-xl">
              <button
                type="button"
                onClick={() => onSelectDate(addDaysStr(selectedDate, -7))}
                title="Tuần trước"
                className="p-1 rounded-lg hover:bg-white dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 transition-colors"
              >
                <ChevronLeft className="w-3.5 h-3.5" />
              </button>

              <button
                type="button"
                onClick={() =>
                  datePickerInputRef.current?.showPicker?.() ||
                  datePickerInputRef.current?.click()
                }
                className="px-2 py-0.5 text-xs font-bold text-slate-800 dark:text-slate-100 hover:text-indigo-600 dark:hover:text-indigo-400 inline-flex items-center gap-1.5 transition-colors"
                title="Chọn ngày bất kỳ từ lịch"
              >
                <CalendarIcon className="w-3.5 h-3.5 text-indigo-500" />
                <span>{formatVietnameseDateFull(selectedDate)}</span>
              </button>
              <input
                ref={datePickerInputRef}
                type="date"
                value={selectedDate}
                onChange={(e) => {
                  if (e.target.value) onSelectDate(e.target.value);
                }}
                className="sr-only"
              />

              <button
                type="button"
                onClick={() => onSelectDate(addDaysStr(selectedDate, 7))}
                title="Tuần kế tiếp"
                className="p-1 rounded-lg hover:bg-white dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 transition-colors"
              >
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {!isViewingToday && (
              <button
                type="button"
                onClick={() => onSelectDate(todayStr)}
                className="px-2.5 py-1 text-xs font-semibold rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-100 transition-colors"
              >
                Về Hôm nay
              </button>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-1.5">
            {/* Button: Xem Lịch Mục Tiêu (Goal Schedule Viewer) */}
            <button
              type="button"
              onClick={() => setShowGoalSchedulePanel((prev) => !prev)}
              className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-semibold border transition-colors ${
                showGoalSchedulePanel || goalScheduleGroups.length > 0
                  ? 'bg-emerald-50/90 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800/70'
                  : 'bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200/70 dark:border-slate-700'
              }`}
            >
              <Target className="w-3.5 h-3.5 text-emerald-500" />
              <span>
                Lịch Mục tiêu
                {goalScheduleGroups.length > 0 ? ` (${goalScheduleGroups.length})` : ''}
              </span>
            </button>

            {/* Button: TKB & Ảnh */}
            <button
              type="button"
              onClick={() => setShowTimetableDrawer((prev) => !prev)}
              className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-semibold border transition-colors ${
                showTimetableDrawer || photosList.length > 0 || personalNote
                  ? 'bg-indigo-50/80 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-300 border-indigo-200 dark:border-indigo-800/70'
                  : 'bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200/70 dark:border-slate-700'
              }`}
            >
              <ImageIcon className="w-3.5 h-3.5" />
              <span>
                TKB & Ảnh{photosList.length > 0 ? ` (${photosList.length})` : ''}
              </span>
            </button>

            <button
              type="button"
              onClick={onOpenSettings}
              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-medium text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">
                {displayFormat === 'timeline'
                  ? 'Thời gian thực'
                  : displayFormat === 'gantt'
                  ? 'Gantt'
                  : displayFormat === 'kanban'
                  ? 'Bảng'
                  : 'Danh sách'}
              </span>
            </button>
          </div>
        </div>

        {/* Fixed Monday-to-Sunday 7-Day Strip (Smooth selection — never jumps or shifts positions!) */}
        <div className="grid grid-cols-7 gap-1.5 bg-slate-100/70 dark:bg-slate-800/50 p-1 rounded-2xl">
          {weekDays.map((item) => {
            const isSelected = item.dateStr === selectedDate;
            const isToday = item.dateStr === todayStr;
            return (
              <button
                key={item.dateStr}
                type="button"
                onClick={() => onSelectDate(item.dateStr)}
                className={`relative flex flex-col items-center py-2 rounded-xl transition-all duration-200 ease-out select-none ${
                  isSelected
                    ? 'bg-indigo-600 text-white shadow-sm scale-[1.01]'
                    : isToday
                    ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 ring-1 ring-indigo-300 dark:ring-indigo-700'
                    : 'text-slate-600 dark:text-slate-400 hover:bg-white/70 dark:hover:bg-slate-800'
                }`}
              >
                <span
                  className={`text-[10px] font-semibold tracking-tight ${
                    isSelected ? 'text-indigo-100' : 'text-slate-400 dark:text-slate-500'
                  }`}
                >
                  {item.dayName}
                </span>
                <span className="text-xs sm:text-sm font-extrabold tabular-nums mt-0.5">
                  {String(item.dayNum).padStart(2, '0')}
                </span>
                <div className="h-1.5 flex items-center justify-center gap-0.5 mt-0.5">
                  {item.hasItems && (
                    <span
                      className={`block w-1.5 h-1.5 rounded-full transition-colors ${
                        isSelected ? 'bg-white' : 'bg-indigo-500'
                      }`}
                    />
                  )}
                  {item.hasGoalTask && (
                    <span
                      className={`block w-1.5 h-1.5 rounded-full transition-colors ${
                        isSelected ? 'bg-emerald-200' : 'bg-emerald-500'
                      }`}
                    />
                  )}
                </div>
              </button>
            );
          })}
        </div>

        {/* Collapsible Goal Schedule Viewer ("Xem lịch nếu đặt mục tiêu") */}
        {showGoalSchedulePanel && (
          <div className="p-3.5 rounded-2xl bg-emerald-50/50 dark:bg-slate-800/70 border border-emerald-200/80 dark:border-emerald-900/50 space-y-3 animate-in fade-in duration-150">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Target className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <h4 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
                  Lịch trình theo Mục tiêu (Toàn bộ các ngày tới khi hoàn thành)
                </h4>
              </div>
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={onOpenGoalsTab}
                  className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-semibold inline-flex items-center gap-1"
                >
                  <span>Quản lý & Đặt mục tiêu</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
                <button
                  type="button"
                  onClick={() => setShowGoalSchedulePanel(false)}
                  className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {goalScheduleGroups.length === 0 ? (
              <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/70 dark:border-slate-800 text-center space-y-2">
                <p className="text-xs text-slate-600 dark:text-slate-300">
                  Bạn chưa đặt mục tiêu dài hạn nào. Hãy nhắn hoặc ghi âm vào thanh AI bên dưới (VD:{' '}
                  <em>“Đặt mục tiêu ôn thi Toán 6 chương phân bổ trong hơn 1 tháng (40 ngày)”</em>) để AI tự chia đủ toàn bộ hạng mục cần hoàn thành!
                </p>
                <div className="flex flex-wrap justify-center gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() =>
                      onSendAIChatCommand(
                        'Đặt mục tiêu ôn thi Toán 12 (Hàm số, Mũ Logarit, Nguyên hàm Tích phân, Số phức, Hình Oxyz, Luyện đề) phân bổ trong hơn 1 tháng (35 ngày)'
                      )
                    }
                    className="px-3 py-1.5 rounded-xl bg-emerald-600 text-white text-xs font-semibold"
                  >
                    + Thử đặt mục tiêu lớn 35 ngày (Hơn 1 tháng)
                  </button>
                  <button
                    type="button"
                    onClick={onOpenGoalsTab}
                    className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs font-semibold"
                  >
                    Mở trang Mục tiêu & Lộ trình
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-3 max-h-72 overflow-y-auto pr-1">
                {goalScheduleGroups.map((grp) => (
                  <div
                    key={grp.goalId}
                    className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 space-y-2.5"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <div className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
                          🎯 {grp.title}
                        </div>
                        <div className="text-[11px] text-slate-500 dark:text-slate-400">
                          {grp.description} · Đích đến:{' '}
                          <span className="font-mono font-semibold">{grp.targetDate}</span>
                        </div>
                      </div>
                      <span className="px-2.5 py-1 rounded-lg bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 text-xs font-mono font-bold tabular-nums">
                        Đã xong {grp.doneCount}/{grp.totalCount} hạng mục ({grp.progressPct}%)
                      </span>
                    </div>

                    <div className="w-full h-1.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-emerald-500 transition-all duration-300 rounded-full"
                        style={{ width: `${Math.min(100, grp.progressPct)}%` }}
                      />
                    </div>

                    {/* Chronological Day-by-Day Schedule of this Goal */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 pt-1">
                      {grp.sessions.map((sess, idx) => {
                        const isSelectedDay = sess.date === selectedDate;
                        return (
                          <div
                            key={sess.id}
                            className={`p-2 rounded-xl border text-xs flex items-center justify-between gap-2 transition-colors ${
                              isSelectedDay
                                ? 'bg-indigo-50/70 dark:bg-indigo-950/40 border-indigo-400 dark:border-indigo-700'
                                : 'bg-slate-50 dark:bg-slate-800/50 border-slate-200/60 dark:border-slate-800'
                            }`}
                          >
                            <div className="flex items-center gap-2 min-w-0 flex-1">
                              <button
                                type="button"
                                onClick={() => onToggleTask(sess.id)}
                                className="shrink-0 text-slate-400 hover:text-emerald-500"
                              >
                                {sess.completed ? (
                                  <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                                ) : (
                                  <Circle className="w-4 h-4" />
                                )}
                              </button>
                              <div
                                onClick={() => onSelectDate(sess.date)}
                                className="min-w-0 flex-1 cursor-pointer"
                              >
                                <div className="flex items-center gap-1.5">
                                  <span className="font-mono text-[10px] font-bold text-indigo-600 dark:text-indigo-400">
                                    Ngày {idx + 1} ({sess.date.slice(8, 10)}/{sess.date.slice(5, 7)})
                                  </span>
                                  <span className="font-mono text-[10px] text-slate-400">
                                    {sess.startTime}–{sess.endTime}
                                  </span>
                                </div>
                                <div
                                  className={`font-semibold truncate ${
                                    sess.completed
                                      ? 'line-through text-slate-400'
                                      : 'text-slate-800 dark:text-slate-100'
                                  }`}
                                >
                                  {sess.title}
                                </div>
                              </div>
                            </div>

                            <button
                              type="button"
                              onClick={() => onSelectDate(sess.date)}
                              className="px-2 py-1 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-[10px] font-semibold text-indigo-600 dark:text-indigo-400 shrink-0"
                            >
                              Xem ngày
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Collapsible Timetable Note, Universal School Link & Image Viewer Drawer */}
        {showTimetableDrawer && (
          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/80 space-y-3 animate-in fade-in duration-150">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-indigo-500" />
                <h4 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
                  Thời khóa biểu: Ghi chú của tôi, Link Trường & Xem Ảnh TKB
                </h4>
              </div>
              <button
                type="button"
                onClick={() => setShowTimetableDrawer(false)}
                className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {/* Left: Personal Timetable Note & Universal School Link */}
              <div className="space-y-2.5">
                <div className="space-y-1">
                  <div className="flex items-center justify-between">
                    <label className="text-[11px] font-semibold text-slate-700 dark:text-slate-300">
                      Ghi chú Thời khóa biểu của tôi:
                    </label>
                    <VoiceRecorderTrigger
                      compact
                      showAutoSendButton={false}
                      onTranscriptReady={(txt) =>
                        onUpdateSchoolSyncConfig({
                          ...schoolSyncConfig,
                          personalNote: schoolSyncConfig.personalNote
                            ? `${schoolSyncConfig.personalNote}\n${txt}`
                            : txt,
                        })
                      }
                    />
                  </div>
                  <textarea
                    rows={3}
                    value={schoolSyncConfig.personalNote || ''}
                    onChange={(e) =>
                      onUpdateSchoolSyncConfig({
                        ...schoolSyncConfig,
                        personalNote: e.target.value,
                      })
                    }
                    placeholder="Nhập ghi chú tự do (VD: Sáng T2-T6 học trên trường 7h-11h15; Chiều T3, T5 học thêm Toán 14h-16h; Phòng học B202...)"
                    className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-slate-800 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                {/* Universal School Link Input */}
                <div className="space-y-1">
                  <label className="text-[11px] font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                    <Link2 className="w-3.5 h-3.5 text-indigo-500" />
                    Đường link liên kết web trường (Hỗ trợ mọi trường):
                  </label>
                  <div className="flex items-center gap-1.5">
                    <input
                      type="url"
                      value={schoolSyncConfig.schoolUrl || ''}
                      onChange={(e) =>
                        onUpdateSchoolSyncConfig({
                          ...schoolSyncConfig,
                          schoolUrl: e.target.value,
                        })
                      }
                      placeholder="https://... (Dán link trang TKB trường của bạn vào đây)"
                      className="flex-1 min-w-0 px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-slate-800 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                    {schoolSyncConfig.schoolUrl && (
                      <a
                        href={unwrapSchoolUrl(schoolSyncConfig.schoolUrl)}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-2.5 py-1.5 rounded-xl bg-slate-200 dark:bg-slate-700 hover:bg-indigo-600 hover:text-white text-slate-700 dark:text-slate-200 text-xs font-semibold inline-flex items-center gap-1 shrink-0 transition-colors"
                        title="Mở đường link trường học"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                        <span>Mở web</span>
                      </a>
                    )}
                  </div>
                </div>
              </div>

              {/* Right: Timetable Image Upload & Instant Viewer */}
              <div className="space-y-2 flex flex-col justify-between">
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-semibold text-slate-700 dark:text-slate-300">
                      Ảnh Thời khóa biểu ({photosList.length}):
                    </span>
                    <button
                      type="button"
                      onClick={() => photoInputRef.current?.click()}
                      className="px-2.5 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-[11px] font-semibold inline-flex items-center gap-1 transition-colors"
                    >
                      <Upload className="w-3 h-3" />
                      <span>Tải ảnh TKB lên</span>
                    </button>
                    <input
                      ref={photoInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleUploadTimetablePhoto}
                      className="hidden"
                    />
                  </div>

                  {photosList.length === 0 ? (
                    <button
                      type="button"
                      onClick={() => photoInputRef.current?.click()}
                      className="w-full h-24 rounded-xl border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-indigo-500 flex flex-col items-center justify-center gap-1 text-slate-400 hover:text-indigo-500 transition-colors"
                    >
                      <ImageIcon className="w-5 h-5" />
                      <span className="text-[11px] font-medium">
                        Bấm để chọn ảnh chụp Thời khóa biểu từ máy
                      </span>
                    </button>
                  ) : (
                    <div className="grid grid-cols-2 gap-2 max-h-32 overflow-y-auto pr-1">
                      {photosList.map((photo) => (
                        <div
                          key={photo.id}
                          className="group relative rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700 bg-slate-900 h-24"
                        >
                          <img
                            src={photo.dataUrl}
                            alt={photo.title}
                            onClick={() => {
                              setZoomScale(1);
                              setActivePhotoLightbox(photo);
                            }}
                            className="w-full h-full object-cover cursor-pointer group-hover:opacity-90 transition-opacity"
                          />
                          <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent p-1.5 flex items-center justify-between">
                            <button
                              type="button"
                              onClick={() => {
                                setZoomScale(1);
                                setActivePhotoLightbox(photo);
                              }}
                              className="text-[10px] font-semibold text-white flex items-center gap-1 truncate"
                            >
                              <ZoomIn className="w-3 h-3 shrink-0" />
                              <span className="truncate">Xem rõ</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => handleDeleteTimetablePhoto(photo.id)}
                              className="p-1 rounded bg-black/50 text-rose-300 hover:text-rose-400"
                              title="Xóa ảnh"
                            >
                              <Trash2 className="w-3 h-3" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <button
                  type="button"
                  disabled={
                    isExtractingTimetable ||
                    (!photosList[0]?.dataUrl &&
                      !personalNote.trim() &&
                      !schoolSyncConfig.schoolUrl.trim())
                  }
                  onClick={() =>
                    onExtractTimetableFromImageOrNote(
                      photosList[0]?.dataUrl || '',
                      personalNote,
                      schoolSyncConfig.schoolUrl
                    )
                  }
                  className="w-full py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-40 text-white text-xs font-bold flex items-center justify-center gap-1.5 transition-colors"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>
                    {isExtractingTimetable
                      ? 'AI đang đọc ảnh TKB & ghi chú...'
                      : 'Nhờ AI đọc Ảnh TKB & Ghi chú để tự khóa giờ học'}
                  </span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Real-time Active / Next Activity Status Bar */}
        {isViewingToday && realtimeStatus && (
          <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-800">
            {realtimeStatus.state === 'active' ? (
              <div className="space-y-1.5">
                <div className="flex items-center justify-between gap-2 text-xs">
                  <span className="font-bold text-indigo-600 dark:text-indigo-400 flex items-center gap-1.5 truncate">
                    <Clock className="w-3.5 h-3.5 shrink-0" />
                    Đang diễn ra: {realtimeStatus.item.title}
                  </span>
                  <span className="font-mono tabular-nums text-[11px] font-semibold text-slate-600 dark:text-slate-300 shrink-0">
                    Còn {realtimeStatus.remainingMins} phút ({realtimeStatus.progressPct}%)
                  </span>
                </div>
                <div className="w-full h-1.5 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-indigo-600 dark:bg-indigo-400 transition-all duration-500 rounded-full"
                    style={{ width: `${realtimeStatus.progressPct}%` }}
                  />
                </div>
              </div>
            ) : realtimeStatus.state === 'upcoming' ? (
              <div className="flex items-center justify-between gap-2 text-xs">
                <span className="text-slate-600 dark:text-slate-300 truncate">
                  Hiện đang rảnh · Tiếp theo:{' '}
                  <strong className="text-slate-900 dark:text-white">
                    {realtimeStatus.item.title}
                  </strong>{' '}
                  ({realtimeStatus.item.startTime})
                </span>
                <span className="font-mono tabular-nums text-[11px] font-semibold text-emerald-600 dark:text-emerald-400 shrink-0">
                  Sau {realtimeStatus.untilMins} phút
                </span>
              </div>
            ) : (
              <div className="text-xs text-slate-500 dark:text-slate-400">
                Hiện tại không có vướng lịch. Nhắn hoặc ghi âm cho AI ở dưới nếu bạn muốn xếp việc mới.
              </div>
            )}
          </div>
        )}
      </div>

      {/* 2. CONVERSATIONAL AI BAR + GEMINI/CLAUDE VOICE RECORDER */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-3 border-2 border-indigo-500/25 dark:border-indigo-500/30 shadow-xs space-y-2">
        <form onSubmit={handleQuickChatSubmit} className="flex flex-wrap items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-indigo-600/10 text-indigo-600 dark:text-indigo-400 flex items-center justify-center shrink-0">
            <Sparkles className="w-4 h-4" />
          </div>
          <input
            type="text"
            value={chatInput}
            onChange={(e) => setChatInput(e.target.value)}
            placeholder="Nói hoặc bấm Giọng nói: thêm việc, đặt mục tiêu nhiều ngày, dời lịch..."
            className="flex-1 min-w-[160px] bg-transparent text-xs sm:text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none"
          />

          <VoiceRecorderTrigger
            onTranscriptReady={handleVoiceTranscript}
            showAutoSendButton={true}
          />

          <button
            type="submit"
            disabled={isAIChatLoading || !chatInput.trim()}
            className="px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 disabled:opacity-40 text-white text-xs font-semibold flex items-center gap-1.5 shrink-0 transition-all"
          >
            <Send className="w-3.5 h-3.5" />
            <span>{isAIChatLoading ? 'Đang xếp...' : 'Gửi AI'}</span>
          </button>
        </form>

        {lastAIReply && (
          <div className="px-3 py-2 rounded-xl bg-indigo-50/70 dark:bg-indigo-950/40 text-xs text-slate-700 dark:text-slate-200 flex items-start justify-between gap-2">
            <div className="flex items-start gap-2">
              <Sparkles className="w-3.5 h-3.5 text-indigo-500 shrink-0 mt-0.5" />
              <span>{lastAIReply}</span>
            </div>
            {goalScheduleGroups.length > 0 && !showGoalSchedulePanel && (
              <button
                type="button"
                onClick={() => setShowGoalSchedulePanel(true)}
                className="px-2.5 py-1 rounded-lg bg-emerald-600 text-white text-[11px] font-semibold shrink-0"
              >
                Xem Lịch Mục Tiêu
              </button>
            )}
          </div>
        )}
      </div>

      {/* 3. SINGLE ACTIVE SCHEDULE VIEW */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200/80 dark:border-slate-800 shadow-xs">
        {unifiedItems.length === 0 ? (
          <div className="py-10 text-center space-y-3 max-w-md mx-auto">
            <p className="text-sm font-bold text-slate-800 dark:text-slate-200">
              Lịch trình ngày này đang trống
            </p>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              Bạn có thể bấm nút <strong>Giọng nói</strong> hoặc nhắn vào thanh AI để thêm việc, bấm <strong>Lịch Mục tiêu</strong> để xem lộ trình dài hạn, hoặc mở <strong>TKB & Ảnh</strong> để xem ảnh thời khóa biểu.
            </p>
            <div className="flex flex-wrap justify-center gap-1.5 pt-1">
              {[
                'Đặt mục tiêu ôn 4 bài Toán và 3 bài Anh trong 4 ngày tới',
                'Thứ 2 đến thứ 6 mình học trên trường 7h-11h15',
                'Mỗi ngày nhắc mình đọc sách 30 phút',
              ].map((suggestion) => (
                <button
                  key={suggestion}
                  type="button"
                  onClick={() => onSendAIChatCommand(suggestion)}
                  className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-indigo-50 dark:hover:bg-indigo-950/50 text-[11px] font-medium text-slate-700 dark:text-slate-300 transition-colors"
                >
                  “{suggestion}”
                </button>
              ))}
            </div>
          </div>
        ) : displayFormat === 'timeline' || displayFormat === 'list' ? (
          <div className="space-y-2">
            {unifiedItems.map((item) => {
              const sMins = timeToMinutes(item.startTime);
              const eMins = timeToMinutes(item.endTime);
              const isNow =
                item.date === todayStr && nowMinutes >= sMins && nowMinutes < eMins;
              const isPast = item.date === todayStr && nowMinutes >= eMins;

              return (
                <div
                  key={item.id}
                  className={`p-3 rounded-xl border transition-all flex items-center justify-between gap-3 ${
                    isNow
                      ? 'bg-indigo-50/70 dark:bg-indigo-950/30 border-indigo-500 shadow-xs'
                      : item.completed || isPast
                      ? 'bg-slate-50/60 dark:bg-slate-800/30 border-slate-200/60 dark:border-slate-800 opacity-65'
                      : 'bg-slate-50 dark:bg-slate-800/50 border-slate-200/70 dark:border-slate-800'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0 flex-1">
                    {item.type === 'locked' ? (
                      <Lock className="w-4 h-4 text-slate-400 shrink-0" />
                    ) : item.type === 'habit' ? (
                      <button
                        type="button"
                        onClick={() => handleToggleItem(item)}
                        className="shrink-0 text-amber-500"
                      >
                        {item.completed ? (
                          <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                        ) : (
                          <Flame className="w-4 h-4" />
                        )}
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => handleToggleItem(item)}
                        className="shrink-0 text-slate-400 hover:text-indigo-600"
                      >
                        {item.completed ? (
                          <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                        ) : (
                          <Circle className="w-4 h-4" />
                        )}
                      </button>
                    )}

                    <div className="w-24 shrink-0">
                      <span className="block text-xs font-bold font-mono tabular-nums text-slate-700 dark:text-slate-200">
                        {item.startTime} – {item.endTime}
                      </span>
                      {viewMode !== 'day' && (
                        <span className="block text-[10px] font-mono text-slate-400">
                          {item.date.slice(8, 10)}/{item.date.slice(5, 7)}
                        </span>
                      )}
                    </div>

                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span
                          className={`text-xs sm:text-sm font-semibold truncate ${
                            item.completed
                              ? 'line-through text-slate-400'
                              : 'text-slate-900 dark:text-white'
                          }`}
                        >
                          {item.title}
                        </span>
                        {item.goalTitle && (
                          <span className="px-2 py-0.5 rounded-md bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 text-[10px] font-semibold shrink-0">
                            🎯 {item.goalTitle}
                          </span>
                        )}
                        {isNow && (
                          <span className="px-2 py-0.5 rounded-md bg-indigo-600 text-white text-[10px] font-bold shrink-0">
                            Đang diễn ra
                          </span>
                        )}
                      </div>
                      {item.subtitle && (
                        <p className="text-[11px] text-slate-400 dark:text-slate-500 truncate mt-0.5">
                          {item.subtitle}
                        </p>
                      )}
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleDeleteItem(item)}
                    className="p-1.5 text-slate-400 hover:text-rose-500 rounded-lg shrink-0"
                    title="Xóa"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              );
            })}
          </div>
        ) : displayFormat === 'gantt' ? (
          <div className="overflow-x-auto">
            <div className="min-w-[580px]">
              <div className="grid grid-cols-[170px_1fr] border-b border-slate-200 dark:border-slate-800 pb-2 mb-2">
                <div className="text-[11px] font-semibold text-slate-400 uppercase">Hoạt động</div>
                <div className="grid grid-cols-17 text-[10px] font-mono text-slate-400 tabular-nums">
                  {Array.from({ length: 17 }, (_, i) => i + 6).map((h) => (
                    <div key={h} className="text-center">
                      {String(h).padStart(2, '0')}h
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-1.5 relative">
                {isViewingToday && nowMinutes >= 6 * 60 && nowMinutes <= 23 * 60 && (
                  <div
                    style={{
                      left: `calc(170px + (100% - 170px) * ${
                        (nowMinutes - 6 * 60) / (17 * 60)
                      })`,
                    }}
                    className="absolute top-0 bottom-0 w-0.5 bg-rose-500 z-10 pointer-events-none"
                    title={`Bây giờ: ${shortNowStr}`}
                  />
                )}

                {unifiedItems.map((item) => {
                  const minHour = 6;
                  const spanMins = 17 * 60;
                  const sMins = Math.max(0, timeToMinutes(item.startTime) - minHour * 60);
                  const eMins = Math.min(spanMins, timeToMinutes(item.endTime) - minHour * 60);
                  const leftPct = Math.max(0, Math.min(95, (sMins / spanMins) * 100));
                  const widthPct = Math.max(
                    5,
                    Math.min(100 - leftPct, ((eMins - sMins) / spanMins) * 100)
                  );

                  const barColor =
                    item.type === 'locked'
                      ? 'bg-slate-600 dark:bg-slate-700'
                      : item.type === 'habit'
                      ? 'bg-amber-500'
                      : 'bg-indigo-600';

                  return (
                    <div
                      key={item.id}
                      className="grid grid-cols-[170px_1fr] items-center gap-2 py-1 border-b border-slate-100 dark:border-slate-800/50 last:border-none"
                    >
                      <div className="flex items-center gap-1.5 pr-2 truncate">
                        <button
                          type="button"
                          onClick={() => handleToggleItem(item)}
                          className="text-slate-400 hover:text-indigo-600 shrink-0"
                        >
                          {item.type === 'locked' ? (
                            <Lock className="w-3.5 h-3.5 text-slate-400" />
                          ) : item.completed ? (
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                          ) : (
                            <Circle className="w-3.5 h-3.5" />
                          )}
                        </button>
                        <span
                          className={`text-xs font-medium truncate ${
                            item.completed
                              ? 'line-through text-slate-400'
                              : 'text-slate-800 dark:text-slate-200'
                          }`}
                        >
                          {item.title}
                        </span>
                      </div>

                      <div className="relative h-7 bg-slate-100/70 dark:bg-slate-800/50 rounded-lg overflow-hidden">
                        <div
                          style={{ left: `${leftPct}%`, width: `${widthPct}%` }}
                          className={`absolute top-1 bottom-1 rounded-md ${barColor} ${
                            item.completed ? 'opacity-45' : 'opacity-95'
                          } flex items-center px-2 text-[10px] font-semibold text-white whitespace-nowrap overflow-hidden tabular-nums`}
                        >
                          {item.startTime}–{item.endTime}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {[
              {
                title: 'Chưa xong',
                items: unifiedItems.filter((i) => i.type !== 'locked' && !i.completed),
              },
              {
                title: 'Giờ cố định',
                items: unifiedItems.filter((i) => i.type === 'locked'),
              },
              {
                title: 'Đã hoàn thành',
                items: unifiedItems.filter((i) => i.completed),
              },
            ].map((col, idx) => (
              <div
                key={idx}
                className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200/70 dark:border-slate-800 space-y-2"
              >
                <div className="flex items-center justify-between text-xs font-bold text-slate-700 dark:text-slate-200">
                  <span>{col.title}</span>
                  <span className="text-slate-400 tabular-nums">{col.items.length}</span>
                </div>
                <div className="space-y-1.5">
                  {col.items.map((item) => (
                    <div
                      key={item.id}
                      className="p-2.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200/60 dark:border-slate-800 flex items-center justify-between gap-2"
                    >
                      <div className="min-w-0">
                        <div className="text-xs font-semibold text-slate-800 dark:text-slate-100 truncate">
                          {item.title}
                        </div>
                        <div className="text-[11px] font-mono text-slate-400 tabular-nums">
                          {item.startTime} – {item.endTime}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Fullscreen Timetable Image Lightbox Viewer with Zoom In / Zoom Out */}
      {activePhotoLightbox && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xs flex flex-col">
          <div className="shrink-0 px-4 py-3 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between gap-3 text-white">
            <div className="min-w-0">
              <h4 className="text-xs sm:text-sm font-bold truncate">
                {activePhotoLightbox.title}
              </h4>
              <p className="text-[10px] text-slate-400">
                Đã thêm: {activePhotoLightbox.addedAt}
              </p>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={() => setZoomScale((s) => Math.max(0.5, Number((s - 0.25).toFixed(2))))}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white"
                title="Thu nhỏ"
              >
                <ZoomOut className="w-4 h-4" />
              </button>
              <span className="text-xs font-mono tabular-nums px-2">
                {Math.round(zoomScale * 100)}%
              </span>
              <button
                type="button"
                onClick={() => setZoomScale((s) => Math.min(3, Number((s + 0.25).toFixed(2))))}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white"
                title="Phóng to"
              >
                <ZoomIn className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => setActivePhotoLightbox(null)}
                className="p-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white ml-2"
                title="Đóng"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="flex-1 overflow-auto flex items-center justify-center p-4">
            <img
              src={activePhotoLightbox.dataUrl}
              alt={activePhotoLightbox.title}
              style={{ transform: `scale(${zoomScale})`, transformOrigin: 'center center' }}
              className="max-w-full max-h-full object-contain rounded-lg transition-transform duration-150"
            />
          </div>
        </div>
      )}
    </div>
  );
};
