import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  Mic,
  Square,
  Pause,
  Play,
  X,
  Check,
  Send,
  Sparkles,
  Loader2,
} from 'lucide-react';

interface VoiceRecorderTriggerProps {
  onTranscriptReady: (text: string, autoSend?: boolean) => void;
  showAutoSendButton?: boolean;
  compact?: boolean;
  placeholderHint?: string;
}

interface SpeechRecognitionEventLike {
  resultIndex: number;
  results: {
    length: number;
    [index: number]: {
      isFinal: boolean;
      0: { transcript: string };
    };
  };
}

interface SpeechRecognitionLike {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  onresult: ((event: SpeechRecognitionEventLike) => void) | null;
  onerror: ((event: unknown) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
}

export const VoiceRecorderTrigger: React.FC<VoiceRecorderTriggerProps> = ({
  onTranscriptReady,
  showAutoSendButton = true,
  compact = false,
}) => {
  const [isRecording, setIsRecording] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [isTranscribingServer, setIsTranscribingServer] = useState(false);
  const [durationSec, setDurationSec] = useState(0);
  const [liveTranscript, setLiveTranscript] = useState('');
  const [interimText, setInterimText] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [waveBars, setWaveBars] = useState<number[]>(() => Array(24).fill(14));

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const animFrameRef = useRef<number | null>(null);
  const speechRecRef = useRef<SpeechRecognitionLike | null>(null);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const finalTranscriptRef = useRef<string>('');
  const interimTranscriptRef = useRef<string>('');

  const cleanupAudioResources = useCallback(() => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
    if (animFrameRef.current) {
      cancelAnimationFrame(animFrameRef.current);
      animFrameRef.current = null;
    }
    if (speechRecRef.current) {
      try {
        speechRecRef.current.onend = null;
        speechRecRef.current.stop();
      } catch {
        // ignore
      }
      speechRecRef.current = null;
    }
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      try {
        mediaRecorderRef.current.stop();
      } catch {
        // ignore
      }
    }
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((t) => t.stop());
      mediaStreamRef.current = null;
    }
    if (audioContextRef.current) {
      audioContextRef.current.close().catch(() => {});
      audioContextRef.current = null;
    }
    analyserRef.current = null;
  }, []);

  useEffect(() => {
    return () => {
      cleanupAudioResources();
    };
  }, [cleanupAudioResources]);

  const startWaveformLoop = useCallback(() => {
    const updateWave = () => {
      const analyser = analyserRef.current;
      if (!analyser) return;
      const dataArray = new Uint8Array(analyser.frequencyBinCount);
      analyser.getByteFrequencyData(dataArray);

      const barsCount = 24;
      const step = Math.max(1, Math.floor(dataArray.length / barsCount));
      const nextBars: number[] = [];
      for (let i = 0; i < barsCount; i++) {
        const val = dataArray[i * step] || 0;
        // Normalize to height percentage 12% -> 100%
        const normalized = Math.min(100, Math.max(12, Math.round((val / 255) * 95) + 12));
        nextBars.push(normalized);
      }
      setWaveBars(nextBars);
      animFrameRef.current = requestAnimationFrame(updateWave);
    };
    animFrameRef.current = requestAnimationFrame(updateWave);
  }, []);

  const startRecording = async () => {
    setErrorMsg(null);
    setLiveTranscript('');
    setInterimText('');
    finalTranscriptRef.current = '';
    interimTranscriptRef.current = '';
    audioChunksRef.current = [];
    setDurationSec(0);

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });
      mediaStreamRef.current = stream;

      // 1. Setup Web Audio API Analyser for Gemini/Claude-like live waveform
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const audioCtx = new AudioCtx();
      audioContextRef.current = audioCtx;
      const source = audioCtx.createMediaStreamSource(stream);
      const analyser = audioCtx.createAnalyser();
      analyser.fftSize = 128;
      analyser.smoothingTimeConstant = 0.78;
      source.connect(analyser);
      analyserRef.current = analyser;
      startWaveformLoop();

      // 2. Setup MediaRecorder to capture audio for Gemini 3.5 Transcribe
      const preferredMime = MediaRecorder.isTypeSupported('audio/webm;codecs=opus')
        ? 'audio/webm;codecs=opus'
        : MediaRecorder.isTypeSupported('audio/mp4')
        ? 'audio/mp4'
        : '';
      const recorder = preferredMime
        ? new MediaRecorder(stream, { mimeType: preferredMime })
        : new MediaRecorder(stream);

      recorder.ondataavailable = (ev) => {
        if (ev.data && ev.data.size > 0) {
          audioChunksRef.current.push(ev.data);
        }
      };
      recorder.start(250);
      mediaRecorderRef.current = recorder;

      // 3. Setup Browser Live SpeechRecognition for instant real-time streaming words
      const SpeechRecConstructor =
        (window as unknown as { SpeechRecognition?: new () => SpeechRecognitionLike })
          .SpeechRecognition ||
        (window as unknown as { webkitSpeechRecognition?: new () => SpeechRecognitionLike })
          .webkitSpeechRecognition;

      if (SpeechRecConstructor) {
        const recognition = new SpeechRecConstructor();
        recognition.lang = 'vi-VN';
        recognition.continuous = true;
        recognition.interimResults = true;

        recognition.onresult = (event: SpeechRecognitionEventLike) => {
          let finalChunk = '';
          let interimChunk = '';
          for (let i = event.resultIndex; i < event.results.length; i++) {
            const res = event.results[i];
            if (res.isFinal) {
              finalChunk += res[0].transcript + ' ';
            } else {
              interimChunk += res[0].transcript;
            }
          }
          if (finalChunk) {
            finalTranscriptRef.current = (finalTranscriptRef.current + ' ' + finalChunk).trim();
            setLiveTranscript(finalTranscriptRef.current);
          }
          interimTranscriptRef.current = interimChunk;
          setInterimText(interimChunk);
        };

        recognition.onerror = () => {
          // Silently continue; MediaRecorder + Gemini server transcription will handle it
        };

        try {
          recognition.start();
          speechRecRef.current = recognition;
        } catch {
          // ignore
        }
      }

      setIsRecording(true);
      setIsPaused(false);
      timerRef.current = setInterval(() => {
        setDurationSec((prev) => prev + 1);
      }, 1000);
    } catch {
      setErrorMsg('Không thể mở micro. Vui lòng cấp quyền Micro cho trình duyệt/ứng dụng.');
      cleanupAudioResources();
    }
  };

  const togglePauseRecording = () => {
    const rec = mediaRecorderRef.current;
    if (!rec) return;

    if (isPaused) {
      if (rec.state === 'paused') rec.resume();
      if (speechRecRef.current) {
        try {
          speechRecRef.current.start();
        } catch {
          // ignore
        }
      }
      startWaveformLoop();
      timerRef.current = setInterval(() => {
        setDurationSec((prev) => prev + 1);
      }, 1000);
      setIsPaused(false);
    } else {
      if (rec.state === 'recording') rec.pause();
      if (speechRecRef.current) {
        try {
          speechRecRef.current.stop();
        } catch {
          // ignore
        }
      }
      if (animFrameRef.current) {
        cancelAnimationFrame(animFrameRef.current);
        animFrameRef.current = null;
      }
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
      setWaveBars(Array(24).fill(14));
      setIsPaused(true);
    }
  };

  const cancelRecording = () => {
    cleanupAudioResources();
    setIsRecording(false);
    setIsPaused(false);
    setLiveTranscript('');
    setInterimText('');
    setDurationSec(0);
  };

  const finishAndTranscribe = async (autoSend: boolean) => {
    const combinedBrowserText = `${finalTranscriptRef.current} ${interimTranscriptRef.current}`.trim();

    // Stop recorder & collect final blob
    const rec = mediaRecorderRef.current;
    const mimeType = rec?.mimeType || 'audio/webm';

    const getBlobPromise = new Promise<Blob | null>((resolve) => {
      if (!rec || rec.state === 'inactive') {
        resolve(
          audioChunksRef.current.length > 0
            ? new Blob(audioChunksRef.current, { type: mimeType })
            : null
        );
        return;
      }
      rec.onstop = () => {
        const blob =
          audioChunksRef.current.length > 0
            ? new Blob(audioChunksRef.current, { type: mimeType })
            : null;
        resolve(blob);
      };
      try {
        rec.stop();
      } catch {
        resolve(null);
      }
    });

    const audioBlob = await getBlobPromise;
    cleanupAudioResources();
    setIsRecording(false);
    setIsPaused(false);

    // Convert audio blob to base64 and send to Gemini 3.5 Transcribe endpoint for AI-grade accuracy
    if (audioBlob && audioBlob.size > 500) {
      setIsTranscribingServer(true);
      try {
        const base64Audio = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onloadend = () => {
            const res = String(reader.result || '');
            const commaIdx = res.indexOf(',');
            resolve(commaIdx >= 0 ? res.slice(commaIdx + 1) : res);
          };
          reader.onerror = reject;
          reader.readAsDataURL(audioBlob);
        });

        const resp = await fetch('/api/gemini/transcribe-audio', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            audioBase64: base64Audio,
            mimeType: mimeType.split(';')[0] || 'audio/webm',
            interimTranscript: combinedBrowserText,
          }),
        });

        if (resp.ok) {
          const data = await resp.json();
          const finalText = String(data.transcript || combinedBrowserText || '').trim();
          if (finalText) {
            onTranscriptReady(finalText, autoSend);
          } else {
            setErrorMsg('Không nhận diện được giọng nói, bạn thử nói rõ hơn nhé.');
          }
        } else if (combinedBrowserText) {
          onTranscriptReady(combinedBrowserText, autoSend);
        }
      } catch {
        if (combinedBrowserText) {
          onTranscriptReady(combinedBrowserText, autoSend);
        }
      } finally {
        setIsTranscribingServer(false);
        setLiveTranscript('');
        setInterimText('');
      }
    } else if (combinedBrowserText) {
      onTranscriptReady(combinedBrowserText, autoSend);
      setLiveTranscript('');
      setInterimText('');
    }
  };

  const formatTimer = (sec: number) => {
    const m = String(Math.floor(sec / 60)).padStart(2, '0');
    const s = String(sec % 60).padStart(2, '0');
    return `${m}:${s}`;
  };

  const displayedLiveText = `${liveTranscript} ${interimText}`.trim();

  if (isTranscribingServer) {
    return (
      <div className="inline-flex items-center gap-2 px-3 py-2 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-200 dark:border-indigo-800 text-xs font-semibold text-indigo-600 dark:text-indigo-300">
        <Loader2 className="w-3.5 h-3.5 animate-spin" />
        <span>Gemini Audio đang chuẩn hóa văn bản...</span>
      </div>
    );
  }

  if (!isRecording) {
    return (
      <div className="inline-flex flex-col items-end">
        <button
          type="button"
          onClick={startRecording}
          title="Ghi âm giọng nói thông minh (Gemini / Claude Voice)"
          className={`inline-flex items-center justify-center gap-1.5 rounded-xl transition-all ${
            compact
              ? 'p-2 bg-slate-100 dark:bg-slate-800 hover:bg-indigo-50 dark:hover:bg-indigo-950/60 text-slate-700 dark:text-slate-200 hover:text-indigo-600 dark:hover:text-indigo-400'
              : 'px-3 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-indigo-50 dark:hover:bg-indigo-950/60 text-slate-700 dark:text-slate-200 hover:text-indigo-600 dark:hover:text-indigo-400 text-xs font-semibold'
          }`}
        >
          <Mic className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
          {!compact && <span className="hidden sm:inline">Giọng nói</span>}
        </button>
        {errorMsg && (
          <span className="text-[10px] text-rose-500 mt-1 max-w-[220px] text-right">
            {errorMsg}
          </span>
        )}
      </div>
    );
  }

  return (
    <div className="w-full rounded-2xl bg-slate-900 dark:bg-slate-950 text-white p-3.5 border border-indigo-500/40 shadow-lg space-y-2.5 animate-in fade-in duration-150">
      {/* Top Row: Live Status Badge + Waveform + Timer */}
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2 shrink-0">
          <span className="relative flex h-2.5 w-2.5">
            {!isPaused && (
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75" />
            )}
            <span
              className={`relative inline-flex rounded-full h-2.5 w-2.5 ${
                isPaused ? 'bg-amber-400' : 'bg-rose-500'
              }`}
            />
          </span>
          <span className="text-[11px] font-bold tracking-wide uppercase text-indigo-300 flex items-center gap-1">
            <Sparkles className="w-3 h-3" />
            {isPaused ? 'Đã tạm dừng' : 'Đang nghe...'}
          </span>
        </div>

        {/* Live Multi-bar Audio Spectrum (Gemini / Claude style) */}
        <div className="flex-1 flex items-center justify-center gap-[3px] h-7 px-2 overflow-hidden">
          {waveBars.map((heightPct, idx) => (
            <div
              key={idx}
              style={{ height: `${isPaused ? 15 : heightPct}%` }}
              className="w-1 rounded-full bg-gradient-to-t from-indigo-500 via-violet-400 to-emerald-300 transition-all duration-75"
            />
          ))}
        </div>

        <span className="font-mono tabular-nums text-xs font-bold text-slate-300 bg-slate-800 px-2.5 py-1 rounded-lg shrink-0">
          {formatTimer(durationSec)}
        </span>
      </div>

      {/* Real-time Streaming Transcript Preview */}
      <div className="min-h-[36px] max-h-24 overflow-y-auto px-3 py-2 rounded-xl bg-slate-800/90 border border-slate-700/80 text-xs leading-relaxed">
        {displayedLiveText ? (
          <p className="text-slate-100">
            <span>{liveTranscript}</span>{' '}
            {interimText && <span className="text-indigo-300 italic">{interimText}</span>}
          </p>
        ) : (
          <p className="text-slate-400 italic">
            Hãy nói tự nhiên (VD: “Chiều nay 4 giờ nhắc mình đi học nhóm, tối 8 giờ ôn Toán”)...
          </p>
        )}
      </div>

      {/* Bottom Controls: Cancel, Pause/Resume, Insert Text, Auto-Send to AI */}
      <div className="flex flex-wrap items-center justify-between gap-2 pt-0.5">
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={cancelRecording}
            className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-rose-500/20 text-slate-300 hover:text-rose-300 text-xs font-medium inline-flex items-center gap-1 transition-colors"
          >
            <X className="w-3.5 h-3.5" />
            <span>Hủy</span>
          </button>

          <button
            type="button"
            onClick={togglePauseRecording}
            className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium inline-flex items-center gap-1 transition-colors"
          >
            {isPaused ? (
              <>
                <Play className="w-3.5 h-3.5 text-emerald-400" />
                <span>Tiếp tục</span>
              </>
            ) : (
              <>
                <Pause className="w-3.5 h-3.5 text-amber-400" />
                <span>Tạm dừng</span>
              </>
            )}
          </button>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => finishAndTranscribe(false)}
            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-600 text-white text-xs font-semibold inline-flex items-center gap-1.5 transition-colors"
          >
            {showAutoSendButton ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span>Chèn văn bản</span>
              </>
            ) : (
              <>
                <Square className="w-3.5 h-3.5 text-emerald-400" />
                <span>Hoàn tất chuyển chữ</span>
              </>
            )}
          </button>

          {showAutoSendButton && (
            <button
              type="button"
              onClick={() => finishAndTranscribe(true)}
              className="px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold inline-flex items-center gap-1.5 shadow-sm transition-colors"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Gửi AI ngay</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
