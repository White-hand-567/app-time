import {
  THPT_BENCAT_EXCEL_FILES,
} from './data/thptBenCatExcelRaw';
import {
  parseClassTimetableFromBenCatExcel,
} from './data/thptBenCatExcelParser';

export type TaskCategory = 'study' | 'work' | 'health' | 'personal' | 'commute';
export type TaskPriority = 'high' | 'medium' | 'low';
export type ScheduleViewMode = 'day' | 'multiday' | 'week' | 'month';
export type ScheduleDisplayFormat = 'timeline' | 'gantt' | 'list' | 'kanban';
export type AIMemoryCategory = 'commute' | 'routine' | 'energy' | 'constraint';
export type WidgetSize = '2x2' | '4x2' | '4x4';

export interface AIChatMessage {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  timestamp: string;
  appliedChangesSummary?: string;
}

export interface AppPreferences {
  defaultDisplayFormat: ScheduleDisplayFormat;
  defaultViewMode: ScheduleViewMode;
  enableGoalsTab: boolean;
  enableAnalyticsTab: boolean;
  enableSchoolSync: boolean;
  customStorageUrl: string;
  autoBackupLocal: boolean;
}

export function getDefaultAppPreferences(): AppPreferences {
  return {
    defaultDisplayFormat: 'timeline',
    defaultViewMode: 'day',
    enableGoalsTab: true,
    enableAnalyticsTab: false,
    enableSchoolSync: false,
    customStorageUrl: '',
    autoBackupLocal: true,
  };
}

export function buildApiUrl(apiPath: string, customBaseUrl?: string): string {
  const base = (customBaseUrl || '').trim().replace(/\/+$/, '');
  if (!base) return apiPath;
  if (/^https?:\/\//i.test(base)) {
    return `${base}${apiPath.startsWith('/') ? apiPath : `/${apiPath}`}`;
  }
  return apiPath;
}

/**
 * VIỆC 3: VIỆC CHẾT (Chỉ khóa các lịch bắt buộc bên ngoài như học ở trường, đi học thêm — Mặc định tự động tiếp diễn qua tuần sau, tháng sau)
 */
export interface LockedFixedBlock {
  id: string;
  title: string;
  daysOfWeek: number[]; // 0 = CN, 1 = T2, 2 = T3, 3 = T4, 4 = T5, 5 = T6, 6 = T7
  startTime: string; // HH:mm
  endTime: string; // HH:mm
  source?: 'manual' | 'school_web';
}

/**
 * Chi tiết từng tiết học cụ thể của từng Lớp trên Thời khóa biểu trường
 */
export interface SchoolClassPeriodItem {
  periodNumber: number; // Tiết 1..5
  session: 'morning' | 'afternoon'; // Sáng | Chiều
  startTime: string; // HH:mm
  endTime: string; // HH:mm
  subject: string; // VD: Toán, Vật Lý, Hóa Học, Ngữ Văn, Tiếng Anh...
  roomOrTeacher?: string; // VD: P.A201 · Cô Lan
}

/**
 * Lịch học cụ thể của 1 Lớp trong 1 Thứ (Thứ 2 -> Thứ 7)
 */
export interface SchoolClassDaySchedule {
  dayOfWeek: number; // 1 = T2 .. 6 = T7
  dayLabel: string; // Thứ 2 .. Thứ 7
  morningSummary: string; // VD: "Tiết 1-5: Chào cờ, Toán, Toán, Văn, Anh (07:00–11:15)"
  afternoonSummary: string; // VD: "Tiết 1-3: Bồi dưỡng Lý & Hóa (13:30–15:55)" hoặc "Trống lịch chiều"
  periods: SchoolClassPeriodItem[];
}

/**
 * Thông tin phiên bản Thời khóa biểu trên cổng trường (để phát hiện và loại bỏ TKB cũ)
 */
export interface TimetableVersionItem {
  id: string;
  versionLabel: string;
  effectiveDate: string;
  isLatest: boolean;
  isDeprecatedOld: boolean;
  sourceNote: string;
}

export interface TimetablePhotoItem {
  id: string;
  title: string;
  dataUrl: string;
  addedAt: string;
}

/**
 * Cấu hình Thời khóa biểu: Ghi chú cá nhân, Đường link liên kết trường bất kỳ & Ảnh Thời khóa biểu
 */
export interface SchoolPortalSyncConfig {
  schoolUrl: string;
  personalNote: string;
  timetablePhotos: TimetablePhotoItem[];
  selectedClassName: string;
  availableClasses: string[];
  activeVersionId?: string;
  activeVersionLabel?: string;
  availableVersions?: TimetableVersionItem[];
  diffFromOldVersion?: string[];
  classCodeOrNote: string;
  autoSyncOnStartup: boolean;
  lastSyncedAt: string;
  lastChangeSummary: string;
  classTimetable: SchoolClassDaySchedule[];
}

/**
 * Kết quả khi AI truy cập Web Trường (hoặc đọc ảnh/bảng TKB) để trích xuất Thời khóa biểu cụ thể của từng Lớp
 */
export interface AISchoolWebSyncResponse {
  schoolNameOrPageTitle: string;
  detectedClassName: string;
  availableClassesOnPortal: string[];
  activeVersionId?: string;
  activeVersionLabel?: string;
  availableVersions?: TimetableVersionItem[];
  diffFromOldVersion?: string[];
  changeSummary: string;
  detectedChanges: string[];
  classTimetable: SchoolClassDaySchedule[];
  extractedLockedBlocks: {
    title: string;
    daysOfWeek: number[];
    startTime: string;
    endTime: string;
  }[];
}

/**
 * VIỆC 2: VIỆC HÀNG NGÀY / VIỆC TỐI THIỂU (Chỉ Thêm hoặc Xóa — Tự động lặp lại mỗi ngày & ghi chuỗi Streak)
 */
export interface DailyMinimumHabit {
  id: string;
  title: string;
  startTime: string; // HH:mm
  endTime: string; // HH:mm
  currentStreak: number;
  bestStreak: number;
  completedDates: string[]; // Danh sách ngày YYYY-MM-DD đã hoàn thành
}

export interface ScheduleTask {
  id: string;
  userId: string;
  title: string;
  notes: string;
  date: string; // YYYY-MM-DD
  startTime: string; // HH:mm
  endTime: string; // HH:mm
  category: TaskCategory;
  priority: TaskPriority;
  completed: boolean;
  isMinimumDaily: boolean;
  currentStreak: number;
  bestStreak: number;
  lastCompletedDate: string;
  reminderEnabled: boolean;
  reminderMinutesBefore: number;
  goalId: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface GoalItem {
  id: string;
  userId: string;
  title: string;
  description: string;
  targetDate: string; // YYYY-MM-DD
  dailyActionTitle: string;
  dailyTargetMinutes: number;
  totalTargetDays: number;
  completedDays: number;
  progressPercent: number;
  isAchieved: boolean;
  achievedDate: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface AIMemoryItem {
  id: string;
  userId: string;
  content: string;
  category: AIMemoryCategory;
  isActive: boolean;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface UserSettings {
  userId: string;
  theme: 'dark' | 'light';
  notificationsEnabled: boolean;
  pinnedWidgetSize: WidgetSize;
  lastDriveBackupAt: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface ProposedTaskDraft {
  title: string;
  notes: string;
  date: string;
  startTime: string;
  endTime: string;
  category: TaskCategory;
  priority: TaskPriority;
  isMinimumDaily: boolean;
}

export interface AIGoalDailyStep {
  dayNumber: number;
  date: string;
  title: string;
  notes: string;
  startTime: string;
  endTime: string;
  freeTimeSummary: string;
  isMinimumDaily: boolean;
}

export interface AIGoalRoadmapResponse {
  goalTitle: string;
  goalDescription: string;
  dailyTargetMinutes: number;
  totalDays: number;
  strategyNote: string;
  dailyPlan: AIGoalDailyStep[];
}

export interface AIPlanResponse {
  summary: string;
  appliedMemoryNotes: string[];
  proposedTasks: ProposedTaskDraft[];
  extractedNewMemories: {
    content: string;
    category: AIMemoryCategory;
  }[];
}

export interface AIAdjustmentItem {
  taskId: string;
  actionType: 'move' | 'shorten' | 'split';
  title: string;
  oldDate: string;
  oldStartTime: string;
  oldEndTime: string;
  newDate: string;
  newStartTime: string;
  newEndTime: string;
  updatedNotes: string;
  reason: string;
}

export interface AIRescheduleResponse {
  empathyAndAnalysis: string;
  appliedMemoryNotes: string[];
  adjustments: AIAdjustmentItem[];
  extractedNewMemories: {
    content: string;
    category: AIMemoryCategory;
  }[];
}

export interface AIFeedbackAdjustResponse {
  aiUnderstanding: string;
  learnedHabitRule: string;
  learnedCategory: AIMemoryCategory;
  predictedBestWindows: {
    label: string;
    startTime: string;
    endTime: string;
    confidencePct: number;
    reason: string;
  }[];
  updatedDayTasks: {
    taskId: string;
    title: string;
    date: string;
    startTime: string;
    endTime: string;
    notes: string;
  }[];
}

export interface AIAnalyticsReviewResponse {
  overallComment: string;
  strengthsAnalysis: string;
  habitAndBufferDetection: string;
  predictedPeakWindow: string;
  recommendations: {
    title: string;
    detail: string;
    memoryRuleToSave: string;
    impactLabel: string;
  }[];
}

export interface DriveBackupFile {
  id: string;
  name: string;
  modifiedTime: string;
  size?: string;
}

export const CATEGORY_LABELS: Record<TaskCategory, string> = {
  study: 'Học tập / Mục tiêu',
  work: 'Thực hành',
  health: 'Thói quen',
  personal: 'Cá nhân',
  commute: 'Cố định',
};

export const PRIORITY_LABELS: Record<TaskPriority, string> = {
  high: 'Ưu tiên cao',
  medium: 'Trung bình',
  low: 'Thấp',
};

export const MEMORY_CATEGORY_LABELS: Record<AIMemoryCategory, string> = {
  routine: 'Lịch cố định',
  commute: 'Sinh hoạt linh hoạt',
  energy: 'Khung giờ hiệu quả',
  constraint: 'Thói quen đã học',
};

export const WEEKDAY_LABELS: { day: number; short: string; full: string }[] = [
  { day: 1, short: 'T2', full: 'Thứ 2' },
  { day: 2, short: 'T3', full: 'Thứ 3' },
  { day: 3, short: 'T4', full: 'Thứ 4' },
  { day: 4, short: 'T5', full: 'Thứ 5' },
  { day: 5, short: 'T6', full: 'Thứ 6' },
  { day: 6, short: 'T7', full: 'Thứ 7' },
  { day: 0, short: 'CN', full: 'Chủ nhật' },
];

export function getTodayStr(): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function addDaysStr(dateStr: string, offset: number): string {
  const [y, m, d] = dateStr.split('-').map(Number);
  const dt = new Date(y, m - 1, d);
  dt.setDate(dt.getDate() + offset);
  const ny = dt.getFullYear();
  const nm = String(dt.getMonth() + 1).padStart(2, '0');
  const nd = String(dt.getDate()).padStart(2, '0');
  return `${ny}-${nm}-${nd}`;
}

export function getWeekdayFromDateStr(dateStr: string): number {
  const [y, m, d] = dateStr.split('-').map(Number);
  return new Date(y, m - 1, d).getDay();
}

export function getMondayOfWeekStr(dateStr: string): string {
  const wd = getWeekdayFromDateStr(dateStr); // 0 = CN, 1 = T2 ... 6 = T7
  const diffToMonday = wd === 0 ? -6 : 1 - wd;
  return addDaysStr(dateStr, diffToMonday);
}

export function formatVietnameseDateFull(dateStr: string): string {
  const [y, m, d] = dateStr.split('-').map(Number);
  const wd = getWeekdayFromDateStr(dateStr);
  const dayNames = ['Chủ nhật', 'Thứ 2', 'Thứ 3', 'Thứ 4', 'Thứ 5', 'Thứ 6', 'Thứ 7'];
  return `${dayNames[wd]}, ${String(d).padStart(2, '0')}/${String(m).padStart(2, '0')}/${y}`;
}

export function formatDaysOfWeekBadge(days: number[]): string {
  if (days.length === 7) return 'Mỗi ngày';
  const weekdays = [1, 2, 3, 4, 5];
  if (days.length === 5 && weekdays.every((d) => days.includes(d))) {
    return 'T2 – T6';
  }
  const map: Record<number, string> = {
    1: 'T2',
    2: 'T3',
    3: 'T4',
    4: 'T5',
    5: 'T6',
    6: 'T7',
    0: 'CN',
  };
  return days
    .slice()
    .sort((a, b) => (a === 0 ? 7 : a) - (b === 0 ? 7 : b))
    .map((d) => map[d])
    .join(', ');
}

export function unwrapSchoolUrl(rawInput: string): string {
  const trimmed = (rawInput || '').trim();
  if (!trimmed) return '';
  try {
    const withProto = /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
    const parsed = new URL(withProto);
    if (
      parsed.hostname.includes('google.') &&
      (parsed.pathname === '/url' || parsed.searchParams.has('q') || parsed.searchParams.has('url'))
    ) {
      const target = parsed.searchParams.get('q') || parsed.searchParams.get('url');
      if (target) return target.trim();
    }
    return withProto;
  } catch {
    const match = trimmed.match(/[?&](?:q|url)=([^&]+)/i);
    if (match && match[1]) {
      try {
        return decodeURIComponent(match[1]);
      } catch {
        return match[1];
      }
    }
    return trimmed;
  }
}

export function getDefaultTimetableVersions(): TimetableVersionItem[] {
  return THPT_BENCAT_EXCEL_FILES;
}

export function getDefaultClassTimetable(className = '12C1'): SchoolClassDaySchedule[] {
  return parseClassTimetableFromBenCatExcel(className).classTimetable;
}

export function deriveLockedBlocksFromClassTimetable(
  className: string,
  _versionBadge: string,
  timetable: SchoolClassDaySchedule[]
): LockedFixedBlock[] {
  const fivePeriodDays: number[] = [];
  const fourPeriodDays: number[] = [];
  const afternoonBlocksByRange: Record<
    string,
    { days: number[]; start: string; end: string; subjects: string[] }
  > = {};

  for (const day of timetable) {
    const mPeriods = day.periods.filter((p) => p.session === 'morning');
    const aPeriods = day.periods.filter((p) => p.session === 'afternoon');
    const maxM =
      mPeriods.length > 0 ? Math.max(...mPeriods.map((p) => p.periodNumber)) : 0;

    if (maxM >= 5) {
      fivePeriodDays.push(day.dayOfWeek);
    } else if (maxM > 0) {
      fourPeriodDays.push(day.dayOfWeek);
    }

    if (aPeriods.length > 0) {
      const start = aPeriods[0].startTime;
      const end = aPeriods[aPeriods.length - 1].endTime;
      const key = `${start}_${end}`;
      if (!afternoonBlocksByRange[key]) {
        afternoonBlocksByRange[key] = { days: [], start, end, subjects: [] };
      }
      afternoonBlocksByRange[key].days.push(day.dayOfWeek);
      for (const ap of aPeriods) {
        if (!afternoonBlocksByRange[key].subjects.includes(ap.subject)) {
          afternoonBlocksByRange[key].subjects.push(ap.subject);
        }
      }
    }
  }

  const blocks: LockedFixedBlock[] = [];

  if (fivePeriodDays.length > 0) {
    blocks.push({
      id: `lock_${className.toLowerCase()}_5p_morning`,
      title: `Học sáng Lớp ${className} (5 tiết)`,
      daysOfWeek: fivePeriodDays,
      startTime: '07:00',
      endTime: '11:15',
      source: 'school_web',
    });
  }
  if (fourPeriodDays.length > 0) {
    blocks.push({
      id: `lock_${className.toLowerCase()}_4p_morning`,
      title: `Học sáng Lớp ${className} (4 tiết · Tan 10:30)`,
      daysOfWeek: fourPeriodDays,
      startTime: '07:00',
      endTime: '10:30',
      source: 'school_web',
    });
  }
  Object.entries(afternoonBlocksByRange).forEach(([key, grp], idx) => {
    blocks.push({
      id: `lock_${className.toLowerCase()}_aft_${idx}_${key}`,
      title: `Học chiều Lớp ${className}: ${grp.subjects.slice(0, 2).join(', ')}`,
      daysOfWeek: grp.days,
      startTime: grp.start,
      endTime: grp.end,
      source: 'school_web',
    });
  });

  return blocks;
}

/**
 * MẶC ĐỊNH MỚI HOÀN TOÀN (TRỐNG 100% NHƯ LÚC MỚI CÀI ĐẶT)
 */
export function getDefaultSchoolSyncConfig(): SchoolPortalSyncConfig {
  const parsed = parseClassTimetableFromBenCatExcel('12C1');
  return {
    schoolUrl: '',
    personalNote: '',
    timetablePhotos: [],
    selectedClassName: '',
    availableClasses: parsed.availableClasses,
    activeVersionId: '',
    activeVersionLabel: '',
    availableVersions: getDefaultTimetableVersions(),
    diffFromOldVersion: [],
    classCodeOrNote: '',
    autoSyncOnStartup: false,
    lastSyncedAt: 'Chưa đồng bộ',
    lastChangeSummary: '',
    classTimetable: [],
  };
}

export function getDefaultLockedBlocks(): LockedFixedBlock[] {
  return [];
}

export function getDefaultDailyHabits(): DailyMinimumHabit[] {
  return [];
}

export function getDefaultMemories(_userId = 'local-user'): AIMemoryItem[] {
  return [];
}

export function getDefaultTasks(_userId = 'local-user'): ScheduleTask[] {
  return [];
}

export function getDefaultGoals(_userId = 'local-user'): GoalItem[] {
  return [];
}

