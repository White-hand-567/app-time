/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  Calendar,
  Target,
  Sparkles,
  BarChart3,
  Settings,
  Moon,
  Sun,
  Bell,
} from 'lucide-react';
import { User } from 'firebase/auth';
import {
  collection,
  doc,
  onSnapshot,
  query,
  where,
  setDoc,
  updateDoc,
  deleteDoc,
  serverTimestamp,
} from 'firebase/firestore';
import {
  db,
  initAuth,
  googleSignIn,
  logout,
  handleFirestoreError,
  OperationType,
} from './firebase';
import {
  ScheduleTask,
  GoalItem,
  AIMemoryItem,
  AIMemoryCategory,
  LockedFixedBlock,
  DailyMinimumHabit,
  WidgetSize,
  AIGoalDailyStep,
  SchoolPortalSyncConfig,
  AppPreferences,
  AIChatMessage,
  getDefaultAppPreferences,
  getTodayStr,
  getDefaultTasks,
  getDefaultGoals,
  getDefaultMemories,
  getDefaultLockedBlocks,
  getDefaultDailyHabits,
  getDefaultSchoolSyncConfig,
  buildApiUrl,
} from './types';
import { parseClassTimetableFromBenCatExcel } from './data/thptBenCatExcelParser';
import { ScheduleView } from './components/ScheduleView';
import { GoalsStreakView } from './components/GoalsStreakView';
import { AISchedulerView } from './components/AISchedulerView';
import { AnalyticsView } from './components/AnalyticsView';
import { WidgetCloudApkView } from './components/WidgetCloudApkView';
import { ChronoFlowBackupPayload } from './services/driveService';

type NavTab = 'schedule' | 'ai' | 'goals' | 'analytics' | 'settings';

const STORAGE_KEYS = {
  TASKS: 'chronoflow_tasks_v8_blank',
  GOALS: 'chronoflow_goals_v8_blank',
  MEMORIES: 'chronoflow_memories_v8_blank',
  LOCKED_BLOCKS: 'chronoflow_locked_blocks_v8_blank',
  DAILY_HABITS: 'chronoflow_daily_habits_v8_blank',
  SCHOOL_SYNC: 'chronoflow_school_sync_v8_blank',
  PREFS: 'chronoflow_prefs_v8_blank',
  CHAT_HISTORY: 'chronoflow_chat_v8_blank',
  THEME: 'chronoflow_theme_v1',
  WIDGET: 'chronoflow_widget_v1',
  NOTIF: 'chronoflow_notif_v1',
  DRIVE_BACKUP: 'chronoflow_drive_backup_v1',
};

export default function App() {
  const [activeTab, setActiveTab] = useState<NavTab>('schedule');
  const [selectedDate, setSelectedDate] = useState<string>(getTodayStr());

  // Theme state
  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.THEME);
    return saved === 'light' ? 'light' : 'dark';
  });

  // Preferences (Single View Mode + Optional Extensions)
  const [preferences, setPreferences] = useState<AppPreferences>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.PREFS);
      return raw ? { ...getDefaultAppPreferences(), ...JSON.parse(raw) } : getDefaultAppPreferences();
    } catch {
      return getDefaultAppPreferences();
    }
  });

  // Auth & Cloud Sync states
  const [user, setUser] = useState<User | null>(null);
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [isAuthReady, setIsAuthReady] = useState(false);

  // Core data stores (100% Blank by default)
  const [tasks, setTasks] = useState<ScheduleTask[]>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.TASKS);
      return raw ? JSON.parse(raw) : getDefaultTasks();
    } catch {
      return getDefaultTasks();
    }
  });

  const [goals, setGoals] = useState<GoalItem[]>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.GOALS);
      return raw ? JSON.parse(raw) : getDefaultGoals();
    } catch {
      return getDefaultGoals();
    }
  });

  const [memories, setMemories] = useState<AIMemoryItem[]>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.MEMORIES);
      return raw ? JSON.parse(raw) : getDefaultMemories();
    } catch {
      return getDefaultMemories();
    }
  });

  const [lockedBlocks, setLockedBlocks] = useState<LockedFixedBlock[]>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.LOCKED_BLOCKS);
      return raw ? JSON.parse(raw) : getDefaultLockedBlocks();
    } catch {
      return getDefaultLockedBlocks();
    }
  });

  const [dailyHabits, setDailyHabits] = useState<DailyMinimumHabit[]>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.DAILY_HABITS);
      return raw ? JSON.parse(raw) : getDefaultDailyHabits();
    } catch {
      return getDefaultDailyHabits();
    }
  });

  const [schoolSyncConfig, setSchoolSyncConfig] = useState<SchoolPortalSyncConfig>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.SCHOOL_SYNC);
      return raw ? JSON.parse(raw) : getDefaultSchoolSyncConfig();
    } catch {
      return getDefaultSchoolSyncConfig();
    }
  });

  const [chatMessages, setChatMessages] = useState<AIChatMessage[]>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.CHAT_HISTORY);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  });

  const [isAIChatLoading, setIsAIChatLoading] = useState(false);
  const [isExtractingTimetable, setIsExtractingTimetable] = useState(false);
  const [lastAIReply, setLastAIReply] = useState<string | null>(null);

  const [pinnedWidgetSize, setPinnedWidgetSize] = useState<WidgetSize>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.WIDGET);
    return saved === '2x2' || saved === '4x2' || saved === '4x4' ? saved : '4x2';
  });

  const [notificationsEnabled, setNotificationsEnabled] = useState<boolean>(() => {
    return localStorage.getItem(STORAGE_KEYS.NOTIF) !== 'false';
  });

  const [lastDriveBackupAt, setLastDriveBackupAt] = useState<string>(() => {
    return localStorage.getItem(STORAGE_KEYS.DRIVE_BACKUP) || '';
  });

  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const notifiedTasksRef = useRef<Set<string>>(new Set());

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 3500);
  };

  // Sync Dark / Light class on <html>
  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    localStorage.setItem(STORAGE_KEYS.THEME, theme);
  }, [theme]);

  // Persist to localStorage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.TASKS, JSON.stringify(tasks));
  }, [tasks]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.GOALS, JSON.stringify(goals));
  }, [goals]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.MEMORIES, JSON.stringify(memories));
  }, [memories]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.LOCKED_BLOCKS, JSON.stringify(lockedBlocks));
  }, [lockedBlocks]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.DAILY_HABITS, JSON.stringify(dailyHabits));
  }, [dailyHabits]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SCHOOL_SYNC, JSON.stringify(schoolSyncConfig));
  }, [schoolSyncConfig]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PREFS, JSON.stringify(preferences));
  }, [preferences]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CHAT_HISTORY, JSON.stringify(chatMessages));
  }, [chatMessages]);

  // Initialize Firebase Authentication
  useEffect(() => {
    const unsub = initAuth((authUser, token) => {
      setUser(authUser);
      if (token) setAccessToken(token);
      setIsAuthReady(true);
    });
    return () => unsub();
  }, []);

  // Attach Firestore Real-Time Listeners when authenticated
  useEffect(() => {
    if (!isAuthReady || !user) return;
    const uid = user.uid;

    const tasksQuery = query(collection(db, 'tasks'), where('userId', '==', uid));
    const unsubTasks = onSnapshot(
      tasksQuery,
      (snap) => {
        if (!snap.empty) {
          const loaded: ScheduleTask[] = snap.docs.map((d) => d.data() as ScheduleTask);
          setTasks(loaded);
        }
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'tasks')
    );

    const goalsQuery = query(collection(db, 'goals'), where('userId', '==', uid));
    const unsubGoals = onSnapshot(
      goalsQuery,
      (snap) => {
        if (!snap.empty) {
          const loaded: GoalItem[] = snap.docs.map((d) => d.data() as GoalItem);
          setGoals(loaded);
        }
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'goals')
    );

    const memoriesQuery = query(collection(db, 'ai_memories'), where('userId', '==', uid));
    const unsubMemories = onSnapshot(
      memoriesQuery,
      (snap) => {
        if (!snap.empty) {
          const loaded: AIMemoryItem[] = snap.docs.map((d) => d.data() as AIMemoryItem);
          setMemories(loaded);
        }
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'ai_memories')
    );

    return () => {
      unsubTasks();
      unsubGoals();
      unsubMemories();
    };
  }, [isAuthReady, user]);

  // Push Notification Reminder Scheduler
  useEffect(() => {
    if (!notificationsEnabled) return;

    const checkReminders = () => {
      const now = new Date();
      const todayStr = getTodayStr();
      const nowMinutes = now.getHours() * 60 + now.getMinutes();

      tasks.forEach((task) => {
        if (task.date !== todayStr || task.completed || !task.reminderEnabled) return;
        const [sh, sm] = task.startTime.split(':').map(Number);
        const startMins = sh * 60 + sm;
        const diff = startMins - nowMinutes;

        const key = `${task.id}_${todayStr}`;
        if (diff >= 0 && diff <= task.reminderMinutesBefore && !notifiedTasksRef.current.has(key)) {
          notifiedTasksRef.current.add(key);
          const msg = `Nhắc việc (${task.startTime}): ${task.title}`;
          showToast(msg);

          if ('Notification' in window && Notification.permission === 'granted') {
            new Notification('ChronoFlow Nhắc Việc', {
              body: `${task.startTime} - ${task.endTime}: ${task.title}`,
              icon: '/icon.svg',
            });
          }
        }
      });
    };

    const timer = setInterval(checkReminders, 30000);
    return () => clearInterval(timer);
  }, [tasks, notificationsEnabled]);

  const syncTaskToFirestore = async (task: ScheduleTask, isNew: boolean) => {
    if (!user) return;
    const safeId = task.id.replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 128);
    const payload = {
      id: safeId,
      userId: user.uid,
      title: task.title.slice(0, 200),
      notes: (task.notes || '').slice(0, 2000),
      date: task.date.slice(0, 10),
      startTime: task.startTime.slice(0, 5),
      endTime: task.endTime.slice(0, 5),
      category: task.category,
      priority: task.priority,
      completed: Boolean(task.completed),
      isMinimumDaily: Boolean(task.isMinimumDaily),
      currentStreak: Math.max(0, Math.floor(task.currentStreak || 0)),
      bestStreak: Math.max(0, Math.floor(task.bestStreak || 0)),
      lastCompletedDate: (task.lastCompletedDate || '').slice(0, 10),
      reminderEnabled: Boolean(task.reminderEnabled),
      reminderMinutesBefore: Math.max(0, Math.floor(task.reminderMinutesBefore || 10)),
      goalId: (task.goalId || '').slice(0, 128),
      ...(isNew ? { createdAt: serverTimestamp() } : {}),
      updatedAt: serverTimestamp(),
    };

    try {
      if (isNew) {
        await setDoc(doc(db, 'tasks', safeId), payload);
      } else {
        await updateDoc(doc(db, 'tasks', safeId), payload);
      }
    } catch (err) {
      handleFirestoreError(err, isNew ? OperationType.CREATE : OperationType.UPDATE, `tasks/${safeId}`);
    }
  };

  // --- CONVERSATIONAL AI COMMAND HANDLER (NO FORMS NEEDED) ---
  const handleSendAIChatCommand = async (messageText: string): Promise<string> => {
    const cleanText = messageText.trim();
    if (!cleanText) return '';

    const now = new Date();
    const currentTimeStr = `${String(now.getHours()).padStart(2, '0')}:${String(
      now.getMinutes()
    ).padStart(2, '0')}`;

    const userMsg: AIChatMessage = {
      id: `msg_u_${Date.now()}`,
      role: 'user',
      text: cleanText,
      timestamp: currentTimeStr,
    };

    setChatMessages((prev) => [...prev, userMsg]);
    setIsAIChatLoading(true);

    try {
      const res = await fetch(buildApiUrl('/api/gemini/chat-assistant', preferences.customStorageUrl), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: cleanText,
          selectedDate,
          currentTime: currentTimeStr,
          tasks,
          lockedBlocks,
          dailyHabits,
          memories: memories.filter((m) => m.isActive),
          personalTimetableNote: schoolSyncConfig.personalNote || '',
          schoolUrl: schoolSyncConfig.schoolUrl || '',
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Không thể kết nối tới AI.');
      }

      const uid = user?.uid || 'local-user';
      const summaryParts: string[] = [];

      // 1. Delete requested tasks
      let nextTasks = [...tasks];
      if (Array.isArray(data.taskIdsToDelete) && data.taskIdsToDelete.length > 0) {
        const delSet = new Set(data.taskIdsToDelete);
        nextTasks = nextTasks.filter((t) => !delSet.has(t.id));
        summaryParts.push(`Đã xóa ${data.taskIdsToDelete.length} việc`);
      }

      // 2. Update modified tasks
      if (Array.isArray(data.tasksToUpdate) && data.tasksToUpdate.length > 0) {
        for (const upd of data.tasksToUpdate) {
          nextTasks = nextTasks.map((t) =>
            t.id === upd.id
              ? {
                  ...t,
                  title: upd.title || t.title,
                  notes: upd.notes ?? t.notes,
                  date: upd.date || t.date,
                  startTime: upd.startTime || t.startTime,
                  endTime: upd.endTime || t.endTime,
                }
              : t
          );
        }
        summaryParts.push(`Đã sửa ${data.tasksToUpdate.length} việc`);
      }

      // 3. Add new tasks & link to Goal if setting a Goal / multi-day roadmap
      let createdForFirestore: ScheduleTask[] = [];
      if (Array.isArray(data.tasksToAdd) && data.tasksToAdd.length > 0) {
        const uniqueDates = new Set(
          data.tasksToAdd.map((item: { date?: string }) => item.date || selectedDate)
        );
        const hasExplicitGoal =
          data.goalToCreate &&
          typeof data.goalToCreate.title === 'string' &&
          data.goalToCreate.title.trim().length > 0;

        let linkedGoalId = '';
        if (hasExplicitGoal || uniqueDates.size >= 2) {
          linkedGoalId = `goal_chat_${Date.now()}`;
          const sortedDates = Array.from(uniqueDates).sort() as string[];
          const lastDateStr = sortedDates[sortedDates.length - 1] || selectedDate;
          const totalDeliverables = data.tasksToAdd.length;
          const newGoal: GoalItem = {
            id: linkedGoalId,
            userId: uid,
            title: (hasExplicitGoal ? data.goalToCreate.title : cleanText).slice(0, 200),
            description: (
              data.goalToCreate?.description ||
              `Lộ trình ${totalDeliverables} hạng mục cần hoàn thành trên ${uniqueDates.size} ngày`
            ).slice(0, 1000),
            targetDate: data.goalToCreate?.targetDate || lastDateStr,
            dailyActionTitle: 'Hoàn thành theo từng hạng mục cụ thể',
            dailyTargetMinutes: Number(data.goalToCreate?.dailyTargetMinutes) || 90,
            totalTargetDays: totalDeliverables,
            completedDays: 0,
            progressPercent: 0,
            isAchieved: false,
            achievedDate: '',
          };
          setGoals((prev) => [newGoal, ...prev]);
          summaryParts.push(`+Tạo Mục Tiêu (${totalDeliverables} hạng mục · ${uniqueDates.size} ngày)`);
        }

        const created: ScheduleTask[] = data.tasksToAdd.map(
          (
            item: {
              title: string;
              notes?: string;
              date?: string;
              startTime?: string;
              endTime?: string;
              category?: ScheduleTask['category'];
              priority?: ScheduleTask['priority'];
            },
            idx: number
          ) => ({
            id: `task_chat_${Date.now()}_${idx}`,
            userId: uid,
            title: (item.title || 'Hạng mục công việc').slice(0, 200),
            notes: (item.notes || '').slice(0, 1000),
            date: item.date || selectedDate,
            startTime: item.startTime || '19:30',
            endTime: item.endTime || '21:00',
            category:
              item.category && ['study', 'work', 'health', 'personal', 'commute'].includes(item.category)
                ? item.category
                : 'study',
            priority:
              item.priority && ['high', 'medium', 'low'].includes(item.priority)
                ? item.priority
                : 'high',
            completed: false,
            isMinimumDaily: false,
            currentStreak: 0,
            bestStreak: 0,
            lastCompletedDate: '',
            reminderEnabled: true,
            reminderMinutesBefore: 15,
            goalId: linkedGoalId,
          })
        );
        nextTasks = [...nextTasks, ...created];
        createdForFirestore = created;
        summaryParts.push(`+Xếp ${created.length} hạng mục vào lịch`);
      }

      setTasks(nextTasks);
      if (createdForFirestore.length > 0 && user) {
        void Promise.all(createdForFirestore.map((c) => syncTaskToFirestore(c, true)));
      }

      // 4. Add new recurring locked blocks
      if (Array.isArray(data.lockedBlocksToAdd) && data.lockedBlocksToAdd.length > 0) {
        const newLocks: LockedFixedBlock[] = data.lockedBlocksToAdd.map(
          (
            b: { title: string; daysOfWeek?: number[]; startTime?: string; endTime?: string },
            idx: number
          ) => ({
            id: `lock_chat_${Date.now()}_${idx}`,
            title: (b.title || 'Giờ cố định').slice(0, 150),
            daysOfWeek:
              Array.isArray(b.daysOfWeek) && b.daysOfWeek.length > 0
                ? b.daysOfWeek
                : [1, 2, 3, 4, 5],
            startTime: b.startTime || '07:00',
            endTime: b.endTime || '11:15',
            source: data.syncedClassName ? 'school_web' : 'manual',
          })
        );
        setLockedBlocks((prev) =>
          data.syncedClassName
            ? [...prev.filter((x) => x.source !== 'school_web'), ...newLocks]
            : [...prev, ...newLocks]
        );
        summaryParts.push(`+Khóa ${newLocks.length} khung giờ cố định`);
      }

      if (data.syncedClassName) {
        const parsed = parseClassTimetableFromBenCatExcel(data.syncedClassName);
        setSchoolSyncConfig((prev) => ({
          ...prev,
          selectedClassName: parsed.resolvedClassName,
          classTimetable: parsed.classTimetable,
          lastSyncedAt: 'Vừa đồng bộ qua AI',
        }));
      }

      // 5. Add new daily habits
      if (Array.isArray(data.habitsToAdd) && data.habitsToAdd.length > 0) {
        const newHabits: DailyMinimumHabit[] = data.habitsToAdd.map(
          (h: { title: string; startTime?: string; endTime?: string }, idx: number) => ({
            id: `habit_chat_${Date.now()}_${idx}`,
            title: (h.title || 'Thói quen hàng ngày').slice(0, 150),
            startTime: h.startTime || '21:00',
            endTime: h.endTime || '21:30',
            currentStreak: 1,
            bestStreak: 1,
            completedDates: [],
          })
        );
        setDailyHabits((prev) => [...prev, ...newHabits]);
        summaryParts.push(`+Thêm ${newHabits.length} việc hàng ngày`);
      }

      // 6. Save learned personal habits/memories
      if (Array.isArray(data.learnedMemories) && data.learnedMemories.length > 0) {
        const createdMems: AIMemoryItem[] = data.learnedMemories.map(
          (m: { content: string; category?: string }, idx: number) => ({
            id: `mem_chat_${Date.now()}_${idx}`,
            userId: uid,
            content: m.content.slice(0, 400),
            category: (['commute', 'routine', 'energy', 'constraint'].includes(m.category || '')
              ? m.category
              : 'constraint') as AIMemoryCategory,
            isActive: true,
          })
        );
        setMemories((prev) => [...createdMems, ...prev]);
        summaryParts.push(`Đã ghi nhớ ${createdMems.length} thói quen mới`);
      }

      const replyText =
        data.reply || 'Đã tự động cập nhật lịch trình theo yêu cầu của bạn.';
      const aiMsg: AIChatMessage = {
        id: `msg_a_${Date.now()}`,
        role: 'assistant',
        text: replyText,
        timestamp: currentTimeStr,
        appliedChangesSummary: summaryParts.length > 0 ? summaryParts.join(' · ') : undefined,
      };

      setChatMessages((prev) => [...prev, aiMsg]);
      setLastAIReply(replyText);
      return replyText;
    } catch (err: unknown) {
      const errMsg =
        err instanceof Error ? err.message : 'Có lỗi xảy ra khi xử lý yêu cầu.';
      const aiErr: AIChatMessage = {
        id: `msg_err_${Date.now()}`,
        role: 'assistant',
        text: errMsg,
        timestamp: currentTimeStr,
      };
      setChatMessages((prev) => [...prev, aiErr]);
      return errMsg;
    } finally {
      setIsAIChatLoading(false);
    }
  };

  // Extract Locked Schedule Blocks from Timetable Image / Personal Note / Universal School Link
  const handleExtractTimetableFromImageOrNote = async (
    imageDataUrl: string,
    personalNote: string,
    schoolUrl: string
  ) => {
    setIsExtractingTimetable(true);
    try {
      const res = await fetch('/api/gemini/extract-timetable-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageDataUrl,
          personalNote,
          schoolUrl,
        }),
      });
      const data = await res.json();
      if (Array.isArray(data.lockedBlocks) && data.lockedBlocks.length > 0) {
        const extractedLocks: LockedFixedBlock[] = data.lockedBlocks.map(
          (
            b: { title: string; daysOfWeek?: number[]; startTime?: string; endTime?: string },
            idx: number
          ) => ({
            id: `lock_tkb_${Date.now()}_${idx}`,
            title: (b.title || 'Lịch học cố định').slice(0, 150),
            daysOfWeek:
              Array.isArray(b.daysOfWeek) && b.daysOfWeek.length > 0
                ? b.daysOfWeek
                : [1, 2, 3, 4, 5],
            startTime: b.startTime || '07:00',
            endTime: b.endTime || '11:15',
            source: 'school_web',
          })
        );
        setLockedBlocks((prev) => [
          ...prev.filter((b) => b.source !== 'school_web'),
          ...extractedLocks,
        ]);
      }

      if (personalNote.trim()) {
        const noteMemory: AIMemoryItem = {
          id: `mem_tkb_${Date.now()}`,
          userId: user?.uid || 'local-user',
          content: `Ghi chú Thời khóa biểu: ${personalNote.trim().slice(0, 350)}`,
          category: 'routine',
          isActive: true,
        };
        setMemories((prev) => [noteMemory, ...prev]);
      }

      const summaryMsg =
        data.summary || 'Đã đọc ảnh Thời khóa biểu & ghi chú để tự động khóa giờ học cố định!';
      setLastAIReply(summaryMsg);
      showToast(summaryMsg);
    } catch {
      showToast('Đã lưu ảnh Thời khóa biểu và ghi chú của bạn.');
    } finally {
      setIsExtractingTimetable(false);
    }
  };

  // Wipe all data to 100% blank state
  const handleResetAllDataToBlank = () => {
    setTasks([]);
    setGoals([]);
    setMemories([]);
    setLockedBlocks([]);
    setDailyHabits([]);
    setChatMessages([]);
    setLastAIReply(null);
    setSchoolSyncConfig(getDefaultSchoolSyncConfig());
    Object.values(STORAGE_KEYS).forEach((k) => {
      if (k !== STORAGE_KEYS.THEME) localStorage.removeItem(k);
    });
    showToast('Đã xóa trắng toàn bộ dữ liệu về như lúc mới cài đặt!');
    setActiveTab('schedule');
  };

  // Automatically keep GoalItem progressPercent & completedDays (used as completed deliverables count) synced with actual completed tasks!
  useEffect(() => {
    setGoals((prevGoals) => {
      let changed = false;
      const nextGoals = prevGoals.map((g) => {
        const linked = tasks.filter((t) => t.goalId === g.id);
        if (linked.length === 0) return g;
        const doneCount = linked.filter((t) => t.completed).length;
        const totalCount = linked.length;
        const pct = Math.min(100, Math.round((doneCount / totalCount) * 100));
        const achievedNow = pct >= 100;
        if (
          g.completedDays !== doneCount ||
          g.totalTargetDays !== totalCount ||
          g.progressPercent !== pct ||
          (achievedNow && !g.isAchieved)
        ) {
          changed = true;
          return {
            ...g,
            completedDays: doneCount,
            totalTargetDays: totalCount,
            progressPercent: pct,
            isAchieved: achievedNow ? true : g.isAchieved,
            achievedDate: achievedNow && !g.achievedDate ? getTodayStr() : g.achievedDate,
          };
        }
        return g;
      });
      return changed ? nextGoals : prevGoals;
    });
  }, [tasks]);

  // Task & Habit Handlers
  const handleToggleTask = async (taskId: string) => {
    const target = tasks.find((t) => t.id === taskId);
    if (!target) return;
    const updated: ScheduleTask = {
      ...target,
      completed: !target.completed,
      lastCompletedDate: !target.completed ? getTodayStr() : target.lastCompletedDate,
    };
    setTasks((prev) => prev.map((t) => (t.id === taskId ? updated : t)));
    if (user) {
      try {
        await updateDoc(doc(db, 'tasks', taskId), {
          completed: updated.completed,
          lastCompletedDate: updated.lastCompletedDate,
          updatedAt: serverTimestamp(),
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, `tasks/${taskId}`);
      }
    }
  };

  const handleDeleteTask = async (taskId: string) => {
    setTasks((prev) => prev.filter((t) => t.id !== taskId));
    if (user) {
      try {
        await deleteDoc(doc(db, 'tasks', taskId));
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, `tasks/${taskId}`);
      }
    }
  };

  const handleAddDailyHabit = (title: string, startTime: string, endTime: string) => {
    const newHabit: DailyMinimumHabit = {
      id: `habit_${Date.now()}`,
      title: title.slice(0, 150),
      startTime,
      endTime,
      currentStreak: 1,
      bestStreak: 1,
      completedDates: [],
    };
    setDailyHabits((prev) => [...prev, newHabit]);
  };

  const handleDeleteDailyHabit = (habitId: string) => {
    setDailyHabits((prev) => prev.filter((h) => h.id !== habitId));
  };

  const handleToggleDailyHabitForDate = (habitId: string, dateStr: string) => {
    setDailyHabits((prev) =>
      prev.map((h) => {
        if (h.id !== habitId) return h;
        const alreadyDone = h.completedDates.includes(dateStr);
        const nextDates = alreadyDone
          ? h.completedDates.filter((d) => d !== dateStr)
          : [...h.completedDates, dateStr];
        const nextStreak = alreadyDone ? Math.max(0, h.currentStreak - 1) : h.currentStreak + 1;
        return {
          ...h,
          completedDates: nextDates,
          currentStreak: nextStreak,
          bestStreak: Math.max(h.bestStreak, nextStreak),
        };
      })
    );
  };

  const handleDeleteLockedBlock = (blockId: string) => {
    setLockedBlocks((prev) => prev.filter((b) => b.id !== blockId));
  };

  const handleSaveGoalWithRoadmap = async (
    goalData: Omit<GoalItem, 'id' | 'userId' | 'createdAt' | 'updatedAt'>,
    dailySteps: AIGoalDailyStep[]
  ) => {
    const goalId = `goal_${Date.now()}`;
    const newGoal: GoalItem = {
      ...goalData,
      id: goalId,
      userId: user?.uid || 'local-user',
      totalTargetDays: dailySteps.length || goalData.totalTargetDays,
      completedDays: 0,
      progressPercent: 0,
    };
    const createdTasks: ScheduleTask[] = dailySteps.map((step, idx) => ({
      id: `task_goal_${Date.now()}_${idx}`,
      userId: user?.uid || 'local-user',
      title: step.title.slice(0, 200),
      notes: step.notes.slice(0, 1000),
      date: step.date,
      startTime: step.startTime,
      endTime: step.endTime,
      category: 'study',
      priority: 'high',
      completed: false,
      isMinimumDaily: false,
      currentStreak: 0,
      bestStreak: 0,
      lastCompletedDate: '',
      reminderEnabled: true,
      reminderMinutesBefore: 15,
      goalId,
    }));
    setGoals((prev) => [newGoal, ...prev]);
    setTasks((prev) => [...prev, ...createdTasks]);
    showToast(`Đã tạo lộ trình mục tiêu gồm ${createdTasks.length} hạng mục cần hoàn thành!`);
  };

  const handleAddGoalDeliverable = (
    goalId: string,
    deliverableTitle: string,
    dateStr: string,
    startTime = '19:30',
    endTime = '21:00'
  ) => {
    const clean = deliverableTitle.trim();
    if (!clean) return;
    const newTask: ScheduleTask = {
      id: `task_deliv_${Date.now()}`,
      userId: user?.uid || 'local-user',
      title: clean.slice(0, 200),
      notes: 'Hạng mục cần hoàn thành thuộc mục tiêu',
      date: dateStr || getTodayStr(),
      startTime,
      endTime,
      category: 'study',
      priority: 'high',
      completed: false,
      isMinimumDaily: false,
      currentStreak: 0,
      bestStreak: 0,
      lastCompletedDate: '',
      reminderEnabled: true,
      reminderMinutesBefore: 15,
      goalId,
    };
    setTasks((prev) => [...prev, newTask]);
    void syncTaskToFirestore(newTask, true);
    showToast(`Đã thêm hạng mục "${clean}" vào mục tiêu!`);
  };

  const handleMarkGoalAchieved = (goalId: string) => {
    setTasks((prev) =>
      prev.map((t) => (t.goalId === goalId ? { ...t, completed: true } : t))
    );
    setGoals((prev) =>
      prev.map((g) =>
        g.id === goalId
          ? {
              ...g,
              completedDays: g.totalTargetDays,
              progressPercent: 100,
              isAchieved: true,
              achievedDate: getTodayStr(),
            }
          : g
      )
    );
  };

  const handleReopenGoal = (goalId: string) => {
    setGoals((prev) =>
      prev.map((g) => (g.id === goalId ? { ...g, isAchieved: false, achievedDate: '' } : g))
    );
  };

  const handleDeleteGoal = (goalId: string) => {
    setGoals((prev) => prev.filter((g) => g.id !== goalId));
    setTasks((prev) => prev.filter((t) => t.goalId !== goalId));
  };

  const handleSaveMemory = (content: string, category: AIMemoryCategory) => {
    const mem: AIMemoryItem = {
      id: `mem_${Date.now()}`,
      userId: user?.uid || 'local-user',
      content: content.slice(0, 400),
      category,
      isActive: true,
    };
    setMemories((prev) => [mem, ...prev]);
  };

  const handleDeleteMemory = (memoryId: string) => {
    setMemories((prev) => prev.filter((m) => m.id !== memoryId));
  };

  const handleGoogleLogin = async () => {
    try {
      const result = await googleSignIn();
      setUser(result.user);
      setAccessToken(result.accessToken);
      showToast(`Đã liên kết tài khoản ${result.user.email}`);
    } catch {
      showToast('Đăng nhập Google đã bị hủy.');
    }
  };

  const handleGoogleLogout = async () => {
    await logout();
    setUser(null);
    setAccessToken(null);
    showToast('Đã ngắt kết nối tài khoản đám mây.');
  };

  const handleToggleNotifications = async () => {
    if (!notificationsEnabled && 'Notification' in window) {
      await Notification.requestPermission();
    }
    const next = !notificationsEnabled;
    setNotificationsEnabled(next);
    localStorage.setItem(STORAGE_KEYS.NOTIF, String(next));
    showToast(next ? 'Đã bật chuông báo nhắc việc' : 'Đã tắt chuông báo');
  };

  const handleTestPushNotification = async () => {
    if ('Notification' in window && Notification.permission !== 'granted') {
      await Notification.requestPermission();
    }
    if ('Notification' in window && Notification.permission === 'granted') {
      new Notification('ChronoFlow — Chuông báo hoạt động tốt', {
        body: 'Ứng dụng sẽ tự động nhắc bạn khi đến giờ trong lịch trình.',
        icon: '/icon.svg',
      });
    }
    showToast('Đã gửi thông báo thử nghiệm!');
  };

  const handleRestoreBackupData = async (payload: ChronoFlowBackupPayload) => {
    if (Array.isArray(payload.tasks)) setTasks(payload.tasks);
    if (Array.isArray(payload.goals)) setGoals(payload.goals);
    if (Array.isArray(payload.memories)) setMemories(payload.memories);
    showToast('Đã khôi phục dữ liệu thành công!');
  };

  // Minimal dynamic navigation: Only 3 core tabs unless user enables extensions in Settings
  const NAV_ITEMS: {
    id: NavTab;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
  }[] = [
    { id: 'schedule', label: 'Lịch trình', icon: Calendar },
    { id: 'ai', label: 'Trò chuyện AI', icon: Sparkles },
    ...(preferences.enableGoalsTab
      ? [{ id: 'goals' as NavTab, label: 'Mục tiêu', icon: Target }]
      : []),
    ...(preferences.enableAnalyticsTab
      ? [{ id: 'analytics' as NavTab, label: 'Phân tích', icon: BarChart3 }]
      : []),
    { id: 'settings', label: 'Cài đặt', icon: Settings },
  ];

  return (
    /* Locked 100dvh flex-col container: prevents any child page from overflowing or hiding the bottom navigation bar on mobile/APK! */
    <div className="h-[100dvh] w-full max-w-full overflow-hidden flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100">
      {/* Top Bar Contract: 3 Zones */}
      <header className="shrink-0 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 px-4 sm:px-6 h-13 flex items-center justify-between gap-4">
        {/* Zone 1: Brand */}
        <a
          href="#top"
          onClick={(e) => {
            e.preventDefault();
            setActiveTab('schedule');
          }}
          className="text-base font-extrabold tracking-tight text-slate-900 dark:text-white whitespace-nowrap shrink-0"
        >
          ChronoFlow
        </a>

        {/* Zone 2: Desktop Navigation */}
        <nav className="hidden lg:flex items-center gap-6 text-sm font-medium text-slate-600 dark:text-slate-400">
          {NAV_ITEMS.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setActiveTab(item.id)}
              className={`py-1 transition-colors whitespace-nowrap shrink-0 border-b-2 ${
                activeTab === item.id
                  ? 'border-indigo-600 dark:border-indigo-400 text-slate-900 dark:text-white font-semibold'
                  : 'border-transparent hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              {item.label}
            </button>
          ))}
        </nav>

        {/* Zone 3: Theme Toggle */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'))}
            className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-xs font-semibold text-slate-800 dark:text-slate-200 flex items-center gap-1.5 transition-colors"
          >
            {theme === 'dark' ? (
              <>
                <Moon className="w-3.5 h-3.5 text-indigo-400" />
                <span>Tối</span>
              </>
            ) : (
              <>
                <Sun className="w-3.5 h-3.5 text-amber-500" />
                <span>Sáng</span>
              </>
            )}
          </button>
        </div>
      </header>

      {/* Scrollable Main Area (flex-1 min-h-0 guarantees bottom nav is NEVER pushed off screen) */}
      <main className="flex-1 min-h-0 overflow-y-auto overflow-x-hidden">
        <div className="max-w-4xl mx-auto px-3 sm:px-6 py-3">
          {activeTab === 'schedule' && (
            <ScheduleView
              tasks={tasks}
              goals={goals}
              lockedBlocks={lockedBlocks}
              dailyHabits={dailyHabits}
              selectedDate={selectedDate}
              onSelectDate={setSelectedDate}
              displayFormat={preferences.defaultDisplayFormat}
              viewMode={preferences.defaultViewMode}
              schoolSyncConfig={schoolSyncConfig}
              onUpdateSchoolSyncConfig={setSchoolSyncConfig}
              onExtractTimetableFromImageOrNote={handleExtractTimetableFromImageOrNote}
              isExtractingTimetable={isExtractingTimetable}
              onToggleTask={handleToggleTask}
              onDeleteTask={handleDeleteTask}
              onToggleDailyHabitForDate={handleToggleDailyHabitForDate}
              onDeleteDailyHabit={handleDeleteDailyHabit}
              onDeleteLockedBlock={handleDeleteLockedBlock}
              onSendAIChatCommand={handleSendAIChatCommand}
              isAIChatLoading={isAIChatLoading}
              lastAIReply={lastAIReply}
              onOpenSettings={() => setActiveTab('settings')}
              onOpenGoalsTab={() => setActiveTab('goals')}
            />
          )}

          {activeTab === 'ai' && (
            <AISchedulerView
              messages={chatMessages}
              memories={memories}
              isSending={isAIChatLoading}
              onSendMessage={async (text) => {
                await handleSendAIChatCommand(text);
              }}
              onClearChat={() => {
                setChatMessages([]);
                setLastAIReply(null);
              }}
              onDeleteMemory={handleDeleteMemory}
            />
          )}

          {activeTab === 'goals' && (
            <GoalsStreakView
              goals={goals}
              tasks={tasks}
              memories={memories}
              lockedBlocks={lockedBlocks}
              dailyHabits={dailyHabits}
              onSaveGoalWithRoadmap={handleSaveGoalWithRoadmap}
              onAddDailyHabit={handleAddDailyHabit}
              onDeleteDailyHabit={handleDeleteDailyHabit}
              onToggleTask={handleToggleTask}
              onDeleteTask={handleDeleteTask}
              onAddGoalDeliverable={handleAddGoalDeliverable}
              onMarkGoalAchieved={handleMarkGoalAchieved}
              onReopenGoal={handleReopenGoal}
              onDeleteGoal={handleDeleteGoal}
              onJumpToScheduleDate={(dStr) => {
                setSelectedDate(dStr);
                setActiveTab('schedule');
              }}
            />
          )}

          {activeTab === 'analytics' && (
            <AnalyticsView
              tasks={tasks}
              goals={goals}
              dailyHabits={dailyHabits}
              lockedBlocks={lockedBlocks}
              memories={memories}
              onSaveMemory={(content, cat) => handleSaveMemory(content, cat)}
            />
          )}

          {activeTab === 'settings' && (
            <WidgetCloudApkView
              user={user}
              accessToken={accessToken}
              tasks={tasks}
              goals={goals}
              memories={memories}
              preferences={preferences}
              onUpdatePreferences={setPreferences}
              schoolSyncConfig={schoolSyncConfig}
              onUpdateSchoolSyncConfig={setSchoolSyncConfig}
              onExtractTimetableFromImageOrNote={handleExtractTimetableFromImageOrNote}
              isExtractingTimetable={isExtractingTimetable}
              pinnedWidgetSize={pinnedWidgetSize}
              notificationsEnabled={notificationsEnabled}
              lastDriveBackupAt={lastDriveBackupAt}
              onChangeWidgetSize={(sz) => {
                setPinnedWidgetSize(sz);
                localStorage.setItem(STORAGE_KEYS.WIDGET, sz);
              }}
              onToggleNotifications={handleToggleNotifications}
              onTestPushNotification={handleTestPushNotification}
              onGoogleLogin={handleGoogleLogin}
              onGoogleLogout={handleGoogleLogout}
              onRestoreBackupData={handleRestoreBackupData}
              onRecordDriveBackupTime={(ts: string) => {
                setLastDriveBackupAt(ts);
                localStorage.setItem(STORAGE_KEYS.DRIVE_BACKUP, ts);
              }}
              onResetAllDataToBlank={handleResetAllDataToBlank}
            />
          )}
        </div>
      </main>

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-16 lg:bottom-6 right-4 left-4 sm:left-auto sm:max-w-sm z-50 bg-slate-900 dark:bg-indigo-600 text-white px-4 py-2.5 rounded-2xl shadow-xl flex items-center gap-2 text-xs font-medium">
          <Bell className="w-4 h-4 text-amber-400 dark:text-white shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Pinned Mobile / APK Bottom Navigation Bar (shrink-0 inside 100dvh flex-col -> NEVER disappears!) */}
      <nav
        style={{
          gridTemplateColumns: `repeat(${NAV_ITEMS.length}, minmax(0, 1fr))`,
        }}
        className="lg:hidden shrink-0 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 px-2 py-1 grid gap-1"
      >
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          const active = activeTab === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => setActiveTab(item.id)}
              className={`min-h-[46px] rounded-xl flex flex-col items-center justify-center gap-0.5 transition-colors ${
                active
                  ? 'text-indigo-600 dark:text-indigo-400 bg-indigo-500/10 font-semibold'
                  : 'text-slate-500 dark:text-slate-400'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span className="text-[11px] truncate max-w-full px-1">{item.label}</span>
            </button>
          );
        })}
      </nav>
    </div>
  );
}
